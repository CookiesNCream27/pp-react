import React, { Component } from 'react';
import axios from 'axios';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import Grid from '@material-ui/core/Grid';
import { AuthConsumer } from '../AuthContext';
import { PostAxios } from '../../Utils/Services';
import { Logger } from '../../Utils/SharedFunctions';
import styles from './LoginContainer.module.css';
import LoginFailed from '../../assets/images/login_failed.png';
import LoginWelcome from '../../assets/images/login_welcome.png';

class Login extends Component {
  state = {
    username: '',
    password: '',
    disabled: true,
    popupshown: false,
  };

  signal = axios.CancelToken.source();

  componentDidMount() {
    this.handleChange('username');
    this.handleChange('password');
    setTimeout(this.checkValidInput, 50);
  }

  componentWillUnmount() {
    this.signal.cancel('Login Api has been canceled');
  }

  submitLogin = (payload, login) => async () => {
    try {
      const { data } = await PostAxios(
        'https://dev.homecredit.co.id/partner-zone/user-management/login',
        payload,
        this.signal.token,
      );
      await login(data);
      if (data.auth === null) {
        this.setState({
          popupshown: true,
        });
      }
      Logger(() => console.log(data));
    } catch (error) {
      if (axios.isCancel(error)) {
        Logger(() => console.log('Error: ', error.message));
      }
    }
  };

  handleChange = str => event => {
    Logger(() => console.log(this.state));
    this.setState({
      [str]: event.target.value,
    });
    this.checkValidInput();
  };

  checkValidInput = () => {
    const { username, password } = this.state;
    if (username && password) {
      this.setState({ disabled: false });
    }
  };

  handleClose = () => {
    this.setState({
      popupshown: false,
    });
  };

  render() {
    const { username, password } = this.state;
    const { disabled, popupshown } = this.state;

    return (
      <AuthConsumer>
        {({ isAuth, login }) => {
          Logger(() => console.log(this.state));
          Logger(() => console.log(isAuth));
          return (
            <div className={styles['login-container']}>
              <div className={styles['login-left-item']}>
                <img src={LoginWelcome} alt="Login Welcome" />
              </div>
              <br />
              <div className={styles['login-right-item']}>
                <div className={styles['login-box']}>
                  <div>
                    <TextField
                      id="outlined-name"
                      className="login-field"
                      label="Email atau Nomor Telepon"
                      type="text"
                      onChange={this.handleChange('username')}
                      placeholder="Isi Email atau Nomor Telepon"
                      margin="normal"
                      variant="outlined"
                    />
                  </div>
                  <div>
                    <TextField
                      id="outlined-password-input"
                      className="login-field"
                      label="Kata Sandi"
                      type="password"
                      autoComplete="current-password"
                      onChange={this.handleChange('password')}
                      placeholder="Isi Kata Sandi"
                      margin="normal"
                      variant="outlined"
                    />
                  </div>
                  <div>
                    <Button
                      disabled={disabled}
                      color="primary"
                      variant="contained"
                      onClick={this.submitLogin({ username, password }, login)}
                    >
                      Masuk
                    </Button>
                  </div>
                </div>
                <Dialog open={popupshown} onClose={this.handleClose}>
                  <div className={styles['popup-container']}>
                    <Grid
                      container
                      direction="column"
                      justify="center"
                      alignItems="center"
                    >
                      <Grid item md={8}>
                        <img src={LoginFailed} alt="Login Failed" />
                      </Grid>
                      <Grid item md={8}>
                        <h2 className={styles['popup-title']}>LOGIN GAGAL</h2>
                      </Grid>
                      <Grid item md={8}>
                        <p className={styles['popup-description']}>
                          Email/telepon atau password yang anda masukkan salah
                        </p>
                      </Grid>
                      <Grid item md={8}>
                        <Button
                          className={styles['popup-button']}
                          onClick={this.handleClose}
                        >
                          Coba Lagi
                        </Button>
                      </Grid>
                    </Grid>
                  </div>
                </Dialog>
              </div>
            </div>
          );
        }}
      </AuthConsumer>
    );
  }
}

export default Login;
