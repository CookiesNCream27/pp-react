import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import { Logger } from '../../Utils/SharedFunctions';

class Home extends Component {
  constructor() {
    super();
    this.state = { firstName: 'Hairy', lastName: 'Potter' };

    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(e) {
    e.preventDefault();
    this.setState({ firstName: 'Hairy', lastName: 'Plopper' });
  }

  render() {
    const { firstName, lastName } = this.state;
    const combinedName = `${firstName} ${lastName}`;
    Logger(() => console.log(this.props));

    return (
      <div className="App-header">
        <Button color="primary" variant="contained" onClick={this.handleClick}>
          {combinedName}
        </Button>
      </div>
    );
  }
}

export default Home;
