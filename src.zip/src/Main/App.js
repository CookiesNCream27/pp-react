import React from 'react';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import blue from '@material-ui/core/colors/blue';
import { AuthProvider } from './AuthContext';
import AppRouter from './AppRouter';

import './App.css';

const theme = createMuiTheme({
  palette: {
    primary: {
      main: '#e11931',
    },
    secondary: blue,
  },
  typography: {
    useNextVariants: true,
    fontSize: 16,
    fontWeightMedium: 700,
  },
});

const App = () => (
  <AuthProvider>
    <MuiThemeProvider theme={theme}>
      <AppRouter />
    </MuiThemeProvider>
  </AuthProvider>
);

export default App;
