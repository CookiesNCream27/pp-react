import React from 'react';
import PropTypes from 'prop-types';

let appsObject = localStorage.getItem('appsObject');

if (appsObject) {
  appsObject = JSON.parse(appsObject);
}

const ApplicationContext = React.createContext();

class ApplicationProvider extends React.Component {
  state = { apps: !!appsObject };

  constructor() {
    super();
    this.setter = this.setter.bind(this);
    this.remover = this.remover.bind(this);
  }

  setter(data) {
    this.setState(prevState => ({
      value: {
        ...prevState.value,
        apps: data,
      },
    }));
  }

  remover(data) {
    this.setState(prevState => ({
      value: {
        ...prevState.value,
        apps: data,
      },
    }));
  }

  render() {
    const { apps } = this.state;
    const { children } = this.props;

    return (
      <ApplicationContext.Provider value={{ ...apps }}>
        {children}
      </ApplicationContext.Provider>
    );
  }
}

ApplicationProvider.propTypes = {
  children: PropTypes.element.isRequired,
};

const ApplicationConsumer = ApplicationContext.Consumer;

export { ApplicationProvider, ApplicationConsumer, ApplicationContext };
