import React, { Suspense } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Header from '../Common/Header/HeaderComponent';
import Footer from '../Common/Footer/FooterComponent';
import LoadingContainer from './Loading/LoadingContainer';
import ProtectedRoutes from '../Utils/ProtectedRoutes';
import DefaultRoute from '../Utils/DefaultRoute';

const Home = React.lazy(() => import('./Home/HomeContainer'));
const Login = React.lazy(() => import('./Login/LoginContainer'));
const StepOne = React.lazy(() =>
  import('./CreateApplication/StepOne/StepOneContainer'),
);
const StepTwo = React.lazy(() =>
  import('./CreateApplication/StepTwo/StepTwoContainer'),
);
const StepThree = React.lazy(() =>
  import('./CreateApplication/StepThree/StepThreeContainer'),
);
const StepFour = React.lazy(() =>
  import('./CreateApplication/StepFour/StepFourContainer'),
);

let AppRouter;

const AppRouterDesktop = () => (
  <Router basename="/partnerportal">
    <Suspense fallback={<LoadingContainer />}>
      <Header />
      <div id="application-page-wrapper">
        <Switch>
          <ProtectedRoutes
            exact
            path="/"
            component={props => <Home {...props} />}
          />
          <DefaultRoute
            exact
            path="/login"
            defaultRoute="true"
            component={props => <Login {...props} />}
          />
          {/*  IGNORE THIS */}
          <Route
            path="/testing-component"
            component={() => <LoadingContainer />}
          />
          {/* CONTAINER COMPONENT TESTING PURPOSES */}
        </Switch>
      </div>
      <Footer />
    </Suspense>
  </Router>
);

const AppRouterMobile = () => (
  <Router basename="/partnerportal">
    <Suspense fallback={<LoadingContainer />}>
      <Switch>
        <ProtectedRoutes
          exact
          path="/m/create-application/step-one"
          component={props => <StepOne {...props} />}
        />
        <ProtectedRoutes
          exact
          path="/m/create-application/step-two"
          component={props => <StepTwo {...props} />}
        />
        <ProtectedRoutes
          exact
          path="/m/create-application/step-three"
          component={props => <StepThree {...props} />}
        />
        <ProtectedRoutes
          exact
          path="/m/create-application/step-four"
          component={props => <StepFour {...props} />}
        />
        <DefaultRoute
          exact
          path="/login"
          defaultRoute="true"
          component={props => <Login {...props} />}
        />
        {/*  IGNORE THIS */}
        <Route
          path="/testing-component"
          component={() => <LoadingContainer />}
        />
        {/* CONTAINER COMPONENT TESTING PURPOSES */}
      </Switch>
    </Suspense>
  </Router>
);

if (window.innerWidth < 481) {
  AppRouter = AppRouterMobile;
} else {
  AppRouter = AppRouterDesktop;
}

export default AppRouter;
