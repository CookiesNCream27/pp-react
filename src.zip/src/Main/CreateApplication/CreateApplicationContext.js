import React from 'react';

export default React.createContext({
  nikNumberValue: null,
  deliveryMethodValue: null,
});
