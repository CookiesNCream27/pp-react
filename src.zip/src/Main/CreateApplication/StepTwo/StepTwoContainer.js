import React, { Component } from 'react';
import axios from 'axios';
import { Redirect } from 'react-router-dom';
import NumberFormat from 'react-number-format';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import InputBase from '@material-ui/core/InputBase';
import InputAdornment from '@material-ui/core/InputAdornment';
import Dialog from '@material-ui/core/Dialog';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import { Logger } from '../../../Utils/SharedFunctions';
import { PostAxios, GetAxios } from '../../../Utils/Services';
import styles from './StepTwoContainer.module.css';
import CreateApplication from '../CreateApplicationContainer';
import LoadingContainer from '../../Loading/LoadingContainer';
import LoginFailed from '../../../assets/images/login_failed.png';
import Exit from '../../../assets/images/exit.png';
import PlusSign from '../../../assets/images/plus_sign.png';
import PlusSignEnable from '../../../assets/images/plus_sign_enable.png';

const theme = createMuiTheme({
  // Name of the component ⚛️
  typography: {
    // The properties to apply
    useNextVariants: true,
    // Use the system font instead of the default Roboto font.
    htmlFontSize: 15,
    fontWeight: 'bold',
  },
});

let totalEmptyField = 999;
let totalEmptyFieldForContinue = 999;

class StepTwo extends Component {
  signal = axios.CancelToken.source();

  constructor(props) {
    super(props);
    this.state = {
      dataProduct: [
        {
          id: 1,
          commodityCategory: 'NONE',
          commodityType: 'NONE',
          manufacturer: 'NONE',
          model: '',
          price: '',
        },
      ],
      commodityCategory: [
        {
          code: 'NONE',
          name: {
            localizedString: [
              { locale: 'IN', text: 'Pilih Jenis Produk' },
              { locale: 'EN', text: 'Choose Commodity Category' },
            ],
          },
          sortOrder: 0,
        },
      ],
      commodityType: [
        {
          code: 'NONE',
          name: {
            localizedString: [
              { locale: 'IN', text: 'Pilih Tipe Barang' },
              { locale: 'EN', text: 'Choose Commodity Type' },
            ],
          },
          sortOrder: 0,
          categoryCode: 'NONE',
        },
      ],
      manufacturer: [
        {
          code: 'NONE',
          productType: '',
          currency: '',
          manufacturer: ['Pilih Merk'],
          productVariant: [],
          tariffItem: [],
        },
      ],
      commodityTypeCollection: [
        {
          id: 1,
          commodityTypeList: [
            {
              code: 'NONE',
              name: {
                localizedString: [
                  { locale: 'IN', text: 'Pilih Tipe Barang' },
                  { locale: 'EN', text: 'Choose Commodity Type' },
                ],
              },
              sortOrder: 0,
              categoryCode: 'NONE',
            },
          ],
        },
      ],
      manufacturerCollection: [
        {
          id: 1,
          manufacturerList: {
            code: 'NONE',
            productType: '',
            currency: '',
            manufacturer: ['Pilih Merk'],
            productVariant: [],
            tariffItem: [],
          },
        },
      ],
      total: '',
      popupShown: false,
      popupInfo: '',
      isValid: false,
      isBack: false,
      isLoading: false,
    };
    this.addProduct = this.addProduct.bind(this);
    this.enableAddProduct = this.enableAddProduct.bind(this);
    this.enableContinue = this.enableContinue.bind(this);
    this.getCommodityCategory();
  }

  componentWillUnmount() {
    this.signal.cancel('Login Api has been canceled');
  }

  getCommodityCategory = async () => {
    try {
      const { data } = await GetAxios(
        'https://dev.homecredit.co.id/partner-zone/api/v1/bsl/get-code-list',
        this.signal.token,
      );
      if (data === null) {
        this.setState({
          popupShown: true,
          popupInfo: '',
        });
      } else {
        this.setState(
          prevState => ({
            commodityCategory: [
              ...prevState.commodityCategory,
              ...data.commodityCategory,
            ],
          }),
          () => console.log(this.state),
        );
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        Logger(() => console.log('Error: ', error.message));
      }
    }
  };

  getCommodityType = async commodityCategoryValue => {
    this.triggerLoading(true);
    try {
      const value = commodityCategoryValue;
      const { data } = await GetAxios(
        `https://dev.homecredit.co.id/partner-zone/api/v1/bsl/get-code-list/${value}`,
        this.signal.token,
      );
      if (data === null) {
        this.setState({ popupShown: true, popupInfo: '' });
      } else {
        this.setState({
          commodityType: [
            {
              code: 'NONE',
              name: {
                localizedString: [
                  { locale: 'IN', text: 'Pilih Tipe Barang' },
                  { locale: 'EN', text: 'Choose Commodity Type' },
                ],
              },
              sortOrder: 0,
              categoryCode: 'NONE',
            },
            ...data,
          ],
        });
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        Logger(() => console.log('Error: ', error.message));
      }
    }
    this.triggerLoading(false);
  };

  getCommodityTypeCollection = async commodityCategoryValue => {
    this.triggerLoading(true);
    try {
      const value = commodityCategoryValue;
      const { data } = await GetAxios(
        `https://dev.homecredit.co.id/partner-zone/api/v1/bsl/get-code-list/${value}`,
        this.signal.token,
      );
      if (data === null) {
        this.setState({ popupShown: true, popupInfo: '' });
      } else {
        this.setState({
          commodityTypeCollection: [
            {
              id: 1,
              commodityTypeList: [
                {
                  code: 'NONE',
                  name: {
                    localizedString: [
                      { locale: 'IN', text: 'Pilih Tipe Barang' },
                      { locale: 'EN', text: 'Choose Commodity Type' },
                    ],
                  },
                  sortOrder: 0,
                  categoryCode: 'NONE',
                },
                ...data,
              ],
            },
          ],
        });
      }
      console.log('testing', this.state.commodityTypeCollection);
    } catch (error) {
      if (axios.isCancel(error)) {
        Logger(() => console.log('Error: ', error.message));
      }
    }
    this.triggerLoading(false);
  };

  getManufacturer = async manufacturerValue => {
    this.triggerLoading(true);
    try {
      const value = manufacturerValue;
      const body = {
        productProfile: ['PP_UNSEC'],
        commodityType: [value],
        salesroomCode: '0047909OP',
      };
      const { data } = await PostAxios(
        'https://dev.homecredit.co.id/partner-zone/api/v1/bsl/get-product-for-commodity',
        body,
        this.signal.token,
      );
      console.log(data.infoForCommodityType[0].product);
      if (data === null) {
        this.setState({ popupShown: true, popupInfo: '' });
      } else {
        this.setState({
          manufacturer: [
            {
              code: 'NONE',
              productType: '',
              currency: '',
              manufacturer: ['Pilih Merk'],
              productVariant: [],
              tariffItem: [],
            },
            ...data.infoForCommodityType[0].product,
          ],
        });
      }
      console.log(this.state);
    } catch (error) {
      if (axios.isCancel(error)) {
        Logger(() => console.log('Error: ', error.message));
      }
    }
    this.triggerLoading(false);
  };

  handleChangeCommodityCategory = (name, id) => event => {
    Logger(() => console.log(name, id));
    const index = this.state.dataProduct.findIndex(x => x.id === id);
    this.state.dataProduct[index].commodityCategory = event.target.value;
    this.state.dataProduct[index].commodityType = 'NONE';
    this.state.dataProduct[index].manufacturer = 'NONE';
    this.forceUpdate();
    this.getCommodityType(event.target.value);
    this.getCommodityTypeCollection(event.target.value);
    this.enableAddProduct();
    this.enableContinue();
    console.log(this.state);
  };

  handleChangeCommodityType = (name, id) => event => {
    Logger(() => console.log('testing'));
    Logger(() => console.log(name, id));
    const index = this.state.dataProduct.findIndex(x => x.id === id);
    this.state.dataProduct[index].commodityType = event.target.value;
    this.forceUpdate();
    this.getManufacturer(event.target.value);
    this.enableAddProduct();
    this.enableContinue();
    console.log(this.state);
  };

  handleChangeManufacturer = (name, id) => event => {
    Logger(() => console.log(name, id));
    const index = this.state.dataProduct.findIndex(x => x.id === id);
    this.state.dataProduct[index].manufacturer = event.target.value;
    this.forceUpdate();
    console.log(this.state);
  };

  handleChangeModel = (name, id) => event => {
    Logger(() => console.log(name, id));
    const index = this.state.dataProduct.findIndex(x => x.id === id);
    this.state.dataProduct[index].model = event.target.value;
    this.forceUpdate();
    this.enableContinue();
  };

  handleChangeTotal = values => {
    Logger(() => console.log(values.value));
    this.setState({ total: values.value });
    console.log(this.state);
    this.enableContinue();
  };

  priceValidation = () => {
    let price = 0;
    const dataProduct = this.state.dataProduct;
    const total = this.state.total;

    for (let index = 0; index < dataProduct.length; index += 1) {
      price += parseInt(dataProduct[index].price, 10);
    }

    if (total >= price) {
      Logger(() => console.log('gagal', price, total));
      this.setState({
        popupShown: true,
        popupInfo:
          'Total Pembayaran Tunai tidak boleh lebih besar dari harga barang',
      });
    } else {
      Logger(() => console.log('berhasil', price, total));
      this.setState({
        popupShown: false,
        popupInfo: '',
        isValid: true,
      });
    }
  };

  addProduct = () => {
    console.log(totalEmptyField);
    const oldDataProduct = this.state.dataProduct;
    const arrayLength = oldDataProduct.length;
    const newId = oldDataProduct[arrayLength - 1].id + 1;
    const newDataProduct = {
      id: newId,
      commodityCategory: 'NONE',
      commodityType: 'NONE',
      manufacturer: 'NONE',
      model: '',
      price: '',
    };
    this.state.dataProduct.push(newDataProduct);
    this.forceUpdate();
    this.enableAddProduct();
    Logger(() => console.log(this.state.dataProduct, newDataProduct));
  };

  removeProduct = id => {
    const arrayIndex = this.state.dataProduct.findIndex(x => x.id === id);
    this.state.dataProduct.splice(arrayIndex, 1);
    this.forceUpdate();
    this.enableAddProduct();
  };

  enableAddProduct = () => {
    totalEmptyField = 0;
    const dataProduct = this.state.dataProduct;
    if (
      dataProduct[0].commodityCategory === 'NONE' ||
      dataProduct[0].commodityType === 'NONE'
    ) {
      totalEmptyField += 1;
    }
    console.log(totalEmptyField);
  };

  enableContinue = () => {
    totalEmptyFieldForContinue = 0;
    const dataProduct = this.state.dataProduct;
    const total = this.state.total;
    for (let index = 0; index < dataProduct.length; index += 1) {
      if (
        dataProduct[index].commodityCategory === 'NONE' ||
        dataProduct[index].commodityType === 'NONE' ||
        dataProduct[index].model === '' ||
        dataProduct[index].price === '' ||
        total === ''
      ) {
        totalEmptyFieldForContinue += 1;
      }
    }
    console.log(totalEmptyFieldForContinue);
  };

  handlePopupClose = () => {
    this.setState({
      popupShown: false,
      popupInfo: '',
    });
  };

  handleBack = () => {
    this.setState({
      isBack: true,
    });
  };

  triggerLoading = loadingShown => {
    const isShown = loadingShown;
    if (isShown) {
      this.setState({
        isLoading: true,
      });
    } else {
      this.setState({ isLoading: false });
    }
  };

  render() {
    const {
      total,
      popupShown,
      popupInfo,
      isValid,
      isBack,
      isLoading,
    } = this.state;

    if (isValid) return <Redirect to="/m/create-application/step-three" />;

    if (isBack) return <Redirect to="/m/create-application/step-one" />;

    return (
      <div>
        <div
          className={
            isLoading
              ? styles['loading-animation-shown']
              : styles['loading-animation-hidden']
          }
        >
          <LoadingContainer />
        </div>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>
                    Data Pengajuan <br />& Kontrak
                  </div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Langkah 2</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Informasi Pengajuan</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>Masukan Informasi Barang yang Anda inginkan</p>
                </div>
                {this.state.dataProduct.map(data => {
                  return (
                    <div
                      className={styles['textfield-container']}
                      key={data.id}
                    >
                      <div
                        className={
                          data.id === 1
                            ? styles['exit-picture-hidden']
                            : styles['exit-picture']
                        }
                        onClick={() => {
                          const id = data.id;
                          const arrayIndex = this.state.dataProduct.findIndex(
                            x => x.id === id,
                          );
                          this.state.dataProduct.splice(arrayIndex, 1);
                          this.forceUpdate();
                        }}
                        onKeyPress={() => {
                          const id = data.id;
                          const arrayIndex = this.state.dataProduct.findIndex(
                            x => x.id === id,
                          );
                          this.state.dataProduct.splice(arrayIndex, 1);
                          this.forceUpdate();
                        }}
                        role="button"
                        tabIndex="0"
                      >
                        <img src={Exit} alt="Exit" />
                      </div>
                      <div className={styles['first-description']}>
                        Data Produk
                      </div>
                      <div className={styles['first-field']}>
                        <MuiThemeProvider theme={theme}>
                          <TextField
                            id="commodityCategory"
                            select
                            value={data.commodityCategory}
                            onChange={this.handleChangeCommodityCategory(
                              'commodityCategory',
                              data.id,
                            )}
                            fullWidth
                          >
                            {this.state.commodityCategory.map(option => (
                              <MenuItem
                                key={option.code}
                                value={option.code}
                                disabled={option.code === 'NONE'}
                              >
                                {option.name.localizedString[0].text}
                              </MenuItem>
                            ))}
                          </TextField>
                        </MuiThemeProvider>
                      </div>
                      <div className={styles['first-description']} />
                      <div className={styles['first-field']}>
                        <MuiThemeProvider theme={theme}>
                          <TextField
                            id="commodityType"
                            select
                            value={data.commodityType}
                            onChange={this.handleChangeCommodityType(
                              'commodityType',
                              data.id,
                            )}
                            fullWidth
                            disabled={data.commodityCategory === 'NONE'}
                          >
                            {this.state.commodityType.map(option => (
                              <MenuItem
                                key={option.code}
                                value={option.code}
                                disabled={option.code === 'NONE'}
                              >
                                {option.name.localizedString[0].text}
                              </MenuItem>
                            ))}
                          </TextField>
                        </MuiThemeProvider>
                      </div>
                      <div className={styles['first-description']} />
                      <div className={styles['first-field']}>
                        <MuiThemeProvider theme={theme}>
                          <TextField
                            id="manufacturer"
                            select
                            value={data.manufacturer}
                            onChange={this.handleChangeManufacturer(
                              'manufacturer',
                              data.id,
                            )}
                            fullWidth
                          >
                            {this.state.manufacturer.map(option => (
                              <MenuItem
                                key={option.code}
                                value={option.code}
                                disabled={option.code === 'NONE'}
                              >
                                {option.manufacturer[0]}
                              </MenuItem>
                            ))}
                          </TextField>
                        </MuiThemeProvider>
                      </div>
                      <div className={styles['model-description']} />
                      <div className={styles['second-field']}>
                        <MuiThemeProvider theme={theme}>
                          <InputBase
                            id="model"
                            placeholder="Isi Model Barang"
                            fullWidth
                            onChange={this.handleChangeModel('model', data.id)}
                            onKeyUp={this.handleChangeModel('model', data.id)}
                          />
                        </MuiThemeProvider>
                      </div>
                      <div className={styles['second-description']}>
                        Harga Barang
                      </div>
                      <div className={styles['second-field']}>
                        <MuiThemeProvider theme={theme}>
                          <NumberFormat
                            customInput={InputBase}
                            thousandSeparator
                            fullWidth
                            placeholder="Isi Harga Barang"
                            startAdornment={
                              <InputAdornment position="start">
                                Rp
                              </InputAdornment>
                            }
                            onValueChange={values => {
                              const id = data.id;
                              const { value } = values;
                              const index = this.state.dataProduct.findIndex(
                                x => x.id === id,
                              );
                              this.state.dataProduct[index].price = value;
                              this.forceUpdate();
                              console.log(this.state.dataProduct);
                            }}
                            isNumericString
                            value={data.price}
                          />
                        </MuiThemeProvider>
                      </div>
                    </div>
                  );
                })}
                <div
                  className={
                    totalEmptyField === 0
                      ? styles['add-item-button-container']
                      : styles['add-item-button-container-disabled']
                  }
                  onClick={
                    totalEmptyField === 0
                      ? this.addProduct
                      : Logger(() => console.log('add product button disabled'))
                  }
                  onKeyPress={
                    totalEmptyField === 0
                      ? this.addProduct
                      : Logger(() => console.log('add product button disabled'))
                  }
                  role="button"
                  tabIndex="0"
                >
                  <div className={styles['add-button-description']}>
                    <img
                      src={totalEmptyField === 0 ? PlusSignEnable : PlusSign}
                      alt="PlusSign"
                    />
                    <p>Tambah Barang</p>
                  </div>
                </div>
                <div className={styles['textfield-container']}>
                  <div className={styles['total-description']}>
                    Uang Muka + Biaya Admin
                  </div>
                  <div className={styles['total-field']}>
                    <MuiThemeProvider theme={theme}>
                      <NumberFormat
                        customInput={InputBase}
                        thousandSeparator
                        fullWidth
                        placeholder="Isi Total Pembayaran Tunai"
                        startAdornment={
                          <InputAdornment position="start">Rp</InputAdornment>
                        }
                        onValueChange={this.handleChangeTotal}
                        isNumericString
                        value={total}
                      />
                    </MuiThemeProvider>
                  </div>
                </div>
                <div
                  className={
                    totalEmptyFieldForContinue === 0
                      ? styles['submit-button-container']
                      : styles['submit-button-container-disabled']
                  }
                  onClick={
                    totalEmptyFieldForContinue === 0
                      ? this.priceValidation
                      : Logger(() => console.log('continue button disabled'))
                  }
                  onKeyPress={
                    totalEmptyFieldForContinue === 0
                      ? this.priceValidation
                      : Logger(() => console.log('continue button disabled'))
                  }
                  role="button"
                  tabIndex="0"
                >
                  <p>Lanjut</p>
                </div>
                <div
                  className={styles['back-button-container']}
                  onClick={this.handleBack}
                  onKeyPress={this.handleBack}
                  role="button"
                  tabIndex="0"
                >
                  <p>Kembali</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <CreateApplication />
        <Dialog open={popupShown} onClose={this.handlePopupClose} fullWidth>
          <div className={styles['popup-container']}>
            <div>
              <img src={LoginFailed} alt="Login Failed" />
            </div>
            <div>
              <h2 className={styles['popup-title']}>GAGAL</h2>
            </div>
            <div>
              <p className={styles['popup-description']}>{popupInfo}</p>
            </div>
            <div
              className={styles['popup-button']}
              onClick={this.handlePopupClose}
              onKeyPress={this.handlePopupClose}
              role="button"
              tabIndex="0"
            >
              <p>Coba Lagi</p>
            </div>
          </div>
        </Dialog>
      </div>
    );
  }
}

export default StepTwo;
