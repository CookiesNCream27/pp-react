import React, { Component } from 'react';
import NumberFormat from 'react-number-format';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import InputBase from '@material-ui/core/InputBase';
import InputAdornment from '@material-ui/core/InputAdornment';
import { Logger } from '../../../../Utils/SharedFunctions';
import styles from './ProductComponent.module.css';

const theme = createMuiTheme({
  props: {
    // Name of the component ⚛️
    MuiTypography: {
      // The properties to apply
      useNextVariants: true,
      // Use the system font instead of the default Roboto font.
      htmlFontSize: 15,
      fontWeight: '500',
    },
  },
});

const dataCommodityCategory = [
  {
    value: 'NONE',
    label: 'Pilih Jenis Produk',
    disabled: true,
  },
  // {
  //   value: 'ELEKTRONIK',
  //   label: 'Barang Elektronik',
  // },
  // {
  //   value: 'FASHION',
  //   label: 'Fashion',
  // },
  // {
  //   value: 'FURNITURE',
  //   label: 'Furniture/Mebel',
  // },
  // {
  //   value: 'GADGET',
  //   label: 'Gadget',
  // },
  // {
  //   value: 'TV',
  //   label: 'LCD TV / LED TV / Plasma TV',
  // },
  // {
  //   value: 'LAPTOP',
  //   label: 'Laptop / Komputer',
  // },
  {
    value: 'HANDPHONE',
    label: 'Handphone / Smartphone',
    disabled: false,
  },
  // {
  //   value: 'HP2',
  //   label: 'Handphone / Smartphone / Tablet',
  // },
];

const dataCommodityType = [
  {
    value: 'NONE',
    label: 'Pilih Tipe Barang',
    disabled: true,
  },
  {
    value: 'HPPROMO',
    label: 'Smartphone Promo',
  },
];

const dataBrand = [
  {
    value: 'NONE',
    label: 'Pilih Merk',
    disabled: true,
  },
  {
    value: 'LENOVO',
    label: 'LENOVO',
  },
];

class ProductComponent extends Component {
  constructor(props) {
    super(props);
  }

  handleChangeCommodityCategory = () => event => {
    console.log('testing');
    const { value } = event.target.value;
    this.props.handleChangeCommodityCategory(value);
  };

  handleChangeCommodityType = (name, id) => event => {
    Logger(() => console.log(name));
    // this.setState({
    //   commodityType: event.target.value,
    // });
  };

  handleChangeBrand = (name, id) => event => {
    Logger(() => console.log(name));
    // this.setState({
    //   brand: event.target.value,
    // });
  };

  handleChangeModel = (name, id) => event => {
    Logger(() => console.log(name));
    // this.setState({
    //   model: event.target.value,
    // });
  };

  handleValueChangePrice = values => {
    Logger(() => console.log(values.value));
    this.setState({
      price: values.value,
    });
  };

  render() {
    return (
      <div className={styles['textfield-container']}>
        <div className={styles['first-description']}>Data Produk</div>
        <div className={styles['first-field']}>
          <MuiThemeProvider theme={theme}>
            <TextField
              id="commodityCategory"
              select
              value={this.props.commodityCategory}
              onChange={this.handleChangeCommodityCategory.bind(this)}
              fullWidth
            >
              {dataCommodityCategory.map(option => (
                <MenuItem
                  key={option.value}
                  value={option.value}
                  disabled={option.disabled}
                >
                  {option.label}
                </MenuItem>
              ))}
            </TextField>
          </MuiThemeProvider>
        </div>
        <div className={styles['first-description']} />
        <div className={styles['first-field']}>
          <MuiThemeProvider theme={theme}>
            <TextField
              id="commodityType"
              select
              value={this.props.commodityType}
              // onChange={this.handleChangeCommodityType.bind(this)}
              fullWidth
              // disabled={commodityCategory === 'NONE'}
            >
              {dataCommodityType.map(option => (
                <MenuItem
                  key={option.value}
                  value={option.value}
                  disabled={option.disabled}
                >
                  {option.label}
                </MenuItem>
              ))}
            </TextField>
          </MuiThemeProvider>
        </div>
        <div className={styles['first-description']} />
        <div className={styles['first-field']}>
          <MuiThemeProvider theme={theme}>
            <TextField
              id="brand"
              select
              value={this.props.brand}
              // onChange={handleChangeBrand('brand')}
              fullWidth
            >
              {dataBrand.map(option => (
                <MenuItem
                  key={option.value}
                  value={option.value}
                  disabled={option.disabled}
                >
                  {option.label}
                </MenuItem>
              ))}
            </TextField>
          </MuiThemeProvider>
        </div>
        <div className={styles['model-description']} />
        <div className={styles['second-field']}>
          <MuiThemeProvider theme={theme}>
            <InputBase
              id="model"
              placeholder="Isi Model Barang"
              fullWidth
              // onChange={handleChangeModel('model')}
              // onKeyUp={handleChangeModel('model')}
              value={this.props.model}
            />
          </MuiThemeProvider>
        </div>
        <div className={styles['second-description']}>Harga Barang</div>
        <div className={styles['second-field']}>
          <MuiThemeProvider theme={theme}>
            <NumberFormat
              customInput={InputBase}
              thousandSeparator
              fullWidth
              placeholder="Isi Harga Barang"
              startAdornment={
                <InputAdornment position="start">Rp</InputAdornment>
              }
              // onValueChange={handleValueChangePrice}
              value={this.props.price}
              isNumericString
            />
          </MuiThemeProvider>
        </div>
      </div>
    );
  }
}

export default ProductComponent;
