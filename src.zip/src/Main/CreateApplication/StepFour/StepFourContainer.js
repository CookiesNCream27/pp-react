import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import styles from './StepFourContainer.module.css';
import CreateApplication from '../CreateApplicationContainer';
import CheckedBig from '../../../assets/images/checked_big.svg';

class StepOne extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isValid: false,
      isBack: false,
    };
  }

  render() {
    const { isValid, isBack } = this.state;

    if (isValid) return <Redirect to="/m/create-application/step-five" />;

    if (isBack) return <Redirect to="/m/create-application/step-three" />;

    return (
      <div>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>
                    Data Pengajuan <br />& Kontrak
                  </div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Langkah 4</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Rangkuman Pengajuan</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>Pastikan Informasi Transaksi Anda Sudah Benar</p>
                </div>
                <div className={styles['summary-outer-container']}>
                  <div className={styles['summary-inner-container']}>
                    <div className={styles['summary-checked-container']}>
                      <img src={CheckedBig} alt="CheckedBig" />
                    </div>
                    <div className={styles['summary-detail-container']}>
                      <div className={styles['summary-title']}>testing</div>
                    </div>
                  </div>
                </div>
                <div
                  className={styles['submit-button-container']}
                  onClick={this.nikLengthValidation}
                  onKeyPress={this.nikLengthValidation}
                  role="button"
                  tabIndex="0"
                >
                  <p>Lanjut</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <CreateApplication />
      </div>
    );
  }
}

export default StepOne;
