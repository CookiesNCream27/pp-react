import React, { Component } from 'react';
import styles from './LoadingContainer.module.css';
import homeCreditLoader from '../../assets/gif/loading.gif';

class LoadingContainer extends Component {
  render() {
    return (
      <div className={styles['loading-container']}>
        <div className={styles['loading-content']}>
          <img
            className={styles['loading-gif']}
            src={homeCreditLoader}
            alt="Home Credit Loader"
          />
        </div>
      </div>
    );
  }
}

export default LoadingContainer;
