import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import styles from './ProfileContainer.module.css';
import { AuthContext } from '../../AuthContext';

class MobileHome extends Component {
  static contextType = AuthContext;

  render() {
    const { logout } = this.context;
    const partnerPortalLoginObject = JSON.parse(
      localStorage.partnerPortalLoginObject,
    );
    const userName = partnerPortalLoginObject.object.username;
    return (
      <React.Fragment>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>Profile</div>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Hi, {userName}!</p>
                </div>
                <div>
                  <Button
                    variant="contained"
                    size="small"
                    onClick={logout}
                    onKeyPress={this.handleBack}
                  >
                    Logout
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default MobileHome;
