import React, { Component } from 'react';
import axios from 'axios';
import NumberFormat from 'react-number-format';
import { Redirect } from 'react-router-dom';
import Dialog from '@material-ui/core/Dialog';
import { PostAxios } from '../../../../Utils/Services';
import { DevTools, JavaLogger } from '../../../../Utils/SharedFunctions';
import styles from './StepThreeContainer.module.css';
import Information from '../../../../assets/images/information.svg';
import LoadingContainer from '../../Loading/LoadingContainer';
import MobileFooter from '../../Common/FooterComponent';
import OptionTick from '../../../../assets/images/option-tick.svg';
import Money from '../../../../assets/images/money.svg';
import { CreateApplicationContext } from '../CreateApplicationContext';

const stepNumber = 3;

const listAman = ['AMAN_PPI', 'AMAN_HARTA'];
const listProClassic = ['PROCLASSIC', 'CLASSICLAP', 'ADLD', 'ADLD_LAP'];
const listProPremium = ['PROPREMIUM', 'PREMIUMLAP'];
const listAmanProClassic = [
  'AMAN_PPI',
  'AMAN_HARTA',
  'PROCLASSIC',
  'CLASSICLAP',
  'ADLD',
  'ADLD_LAP',
];
const listAmanProPremium = [
  'AMAN_PPI',
  'AMAN_HARTA',
  'PROPREMIUM',
  'PREMIUMLAP',
];

class StepThree extends Component {
  static contextType = CreateApplicationContext;

  signal = axios.CancelToken.source();

  constructor(props) {
    super(props);
    this.state = {
      insuranceData: [
        { id: 1, product: 'AMAN', checked: false },
        { id: 2, product: 'proCLASSIC', checked: false },
        { id: 3, product: 'proPREMIUM', checked: false },
      ],
      filterInsurance: [],
      resultWo: [],
      resultLi: [],
      resultGo: [],
      resultLiGo: [],
      resultGoPremium: [],
      resultLiGoPremium: [],
      resultChosen: [],
      chosenProduct: [],
      popupShown: false,
      isValid: false,
      isBack: false,
      isLoading: true,
    };
    this.handleChooseProduct = this.handleChooseProduct.bind(this);
  }

  componentDidMount() {
    const { value } = this.context;
    const applicationId = value.stepOne.startApplicationId;
    JavaLogger('PARTNER_START_APPLICATION_STEP2', applicationId, this.signal);
    this.getCombinedResult(value.stepTwo);
  }

  componentWillUnmount() {
    this.signal.cancel('Login Api has been canceled');
  }

  getCombinedResult = async result => {
    await this.getWo(result);
    await this.getLi(result);
    await this.getGo(result);
    await this.getLiGo(result);
    await this.getGoPremium(result);
    await this.getLiGoPremium(result);
    await this.filterResult();
  };

  getWo = async stepTwoValue => {
    this.triggerLoading(true);
    try {
      const value = stepTwoValue;
      const serviceTypePreferencesWo = [
        { preference: 'NO_PREFERENCE', type: 'INSGO' },
        { preference: 'NO_PREFERENCE', type: 'INSLI' },
      ];
      value.serviceTypePreferences = serviceTypePreferencesWo;
      const payload = value;
      const { data } = await PostAxios(
        'MAIN',
        '/api/v1/bsl/calculate-customer-offer',
        payload,
        this.signal.token,
      );
      if (data === null) {
        this.setState({ popupShown: true });
      } else {
        this.setState({
          resultWo: data.object,
          // resultChosen: data.object,
        });
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
    this.triggerLoading(false);
  };

  getLi = async stepTwoValue => {
    this.triggerLoading(true);
    try {
      const value = stepTwoValue;
      const serviceTypePreferencesLi = [
        { preference: 'REQUIRED', type: 'INSLI' },
      ];
      value.serviceTypePreferences = serviceTypePreferencesLi;
      const payload = value;
      const { data } = await PostAxios(
        'MAIN',
        '/api/v1/bsl/calculate-customer-offer',
        payload,
        this.signal.token,
      );
      if (data === null) {
        this.setState({ popupShown: true });
      } else {
        this.setState({
          resultLi: data.object,
        });
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
    this.triggerLoading(false);
  };

  getGo = async stepTwoValue => {
    this.triggerLoading(true);
    try {
      const value = stepTwoValue;
      const serviceTypePreferencesGo = [
        { preference: 'REQUIRED', type: 'INSGO' },
      ];
      value.serviceTypePreferences = serviceTypePreferencesGo;
      const payload = value;
      const { data } = await PostAxios(
        'MAIN',
        '/api/v1/bsl/calculate-customer-offer',
        payload,
        this.signal.token,
      );
      if (data === null) {
        this.setState({ popupShown: true });
      } else {
        this.setState({
          resultGo: data.object,
        });
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
    this.triggerLoading(false);
  };

  getLiGo = async stepTwoValue => {
    this.triggerLoading(true);
    try {
      const value = stepTwoValue;
      const serviceTypePreferencesLiGo = [
        { preference: 'REQUIRED', type: 'INSGO' },
        { preference: 'REQUIRED', type: 'INSLI' },
      ];
      value.serviceTypePreferences = serviceTypePreferencesLiGo;
      const payload = value;
      const { data } = await PostAxios(
        'MAIN',
        '/api/v1/bsl/calculate-customer-offer',
        payload,
        this.signal.token,
      );
      if (data === null) {
        this.setState({ popupShown: true });
      } else {
        // There will be thanos here so be fucking careful
        this.setState({
          resultLiGo: data.object,
        });
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
    this.triggerLoading(false);
  };

  getGoPremium = async stepTwoValue => {
    this.triggerLoading(true);
    try {
      const { resultGo } = this.state;
      const payload = {};
      const commodity = stepTwoValue.commodities[0].category;
      let offerCode = '';
      let serviceChoice = [];

      resultGo.forEach(async item => {
        offerCode = item.code;
        // commodity = item.commodities[0].type;

        if (commodity === 'CAT_LAP') {
          serviceChoice = [
            { service: 'PREMIUMLAP', choice: 1 },
            { service: 'CLASSICLAP', choice: 0 },
          ];
        } else if (commodity === 'CAT_GG' || commodity === 'CAT_MP') {
          serviceChoice = [
            { service: 'PROPREMIUM', choice: 1 },
            { service: 'PROCLASSIC', choice: 0 },
          ];
        }
        payload.offerCode = offerCode;
        payload.serviceChoice = serviceChoice;

        const { data } = await PostAxios(
          'MAIN',
          '/api/v1/bsl/recalculate-customer-offer',
          payload,
          this.signal.token,
        );
        if (data.code === 'ERR_OFFER_NOT_FOUND_IN_BSL') {
          // this.setState({ popupShown: true, popupInfo: '' });
        } else {
          // There will be thanos here so be fucking careful
          this.setState(prevState => ({
            resultGoPremium: [
              ...prevState.resultGoPremium,
              data.object.customerOffer,
            ],
          }));
        }
      });
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
    this.triggerLoading(false);
  };

  getLiGoPremium = async stepTwoValue => {
    this.triggerLoading(true);
    try {
      const { resultLiGo } = this.state;
      const payload = {};
      const commodity = stepTwoValue.commodities[0].category;
      let offerCode = '';
      let serviceChoice = [];

      resultLiGo.forEach(async item => {
        offerCode = item.code;
        // commodity = item.commodities[0].type;

        if (commodity === 'CAT_LAP') {
          serviceChoice = [
            { service: 'PREMIUMLAP', choice: 1 },
            { service: 'CLASSICLAP', choice: 0 },
          ];
        } else if (commodity === 'CAT_GG' || commodity === 'CAT_MP') {
          serviceChoice = [
            { service: 'PROPREMIUM', choice: 1 },
            { service: 'PROCLASSIC', choice: 0 },
          ];
        }
        payload.offerCode = offerCode;
        payload.serviceChoice = serviceChoice;

        const { data } = await PostAxios(
          'MAIN',
          '/api/v1/bsl/recalculate-customer-offer',
          payload,
          this.signal.token,
        );
        if (data.code === 'ERR_OFFER_NOT_FOUND_IN_BSL') {
          // this.setState({ popupShown: true, popupInfo: '' });
        } else {
          // There will be thanos here so be fucking careful
          this.setState(prevState => ({
            resultLiGoPremium: [
              ...prevState.resultLiGoPremium,
              data.object.customerOffer,
            ],
          }));
        }
      });
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
    this.triggerLoading(false);
  };

  filterResult = () => {
    this.triggerLoading(true);

    const {
      resultWo,
      resultLi,
      resultGo,
      resultLiGo,
      resultGoPremium,
      resultLiGoPremium,
    } = this.state;

    const filterWo = [];
    const filterLi = [];
    const filterGo = [];
    const filterLiGo = [];
    const filterGoPremium = [];
    const filterLiGoPremium = [];

    let listService = [];

    // solve Wo
    for (let index = 0; index < resultWo.length; index += 1) {
      const { fees } = resultWo[index];

      for (let indexFees = 0; indexFees < fees.length; indexFees += 1) {
        listService.push(fees[indexFees].service);
      }

      if (listService.length === 4) {
        if (listService.some(r => listAmanProClassic.includes(r))) {
          // filterLiGo.push(resultWo[index]);
        } else if (listService.some(r => listAmanProPremium.includes(r))) {
          // filterLiGoPremium.push(resultWo[index]);
        }
      } else if (listService.length === 3) {
        if (listService.some(r => listAman.includes(r))) {
          // filterLi.push(resultWo[index]);
        } else if (listService.some(r => listProClassic.includes(r))) {
          // filterGo.push(resultWo[index]);
        } else if (listService.some(r => listProPremium.includes(r))) {
          // filterGoPremium.push(resultWo[index]);
        }
      } else {
        filterWo.push(resultWo[index]);
      }
      listService = [];
    }

    // solve Li
    for (let index = 0; index < resultLi.length; index += 1) {
      const { fees } = resultLi[index];

      for (let indexFees = 0; indexFees < fees.length; indexFees += 1) {
        listService.push(fees[indexFees].service);
      }

      if (listService.length === 4) {
        if (listService.some(r => listAmanProClassic.includes(r))) {
          // filterLiGo.push(resultLi[index]);
        } else if (listService.some(r => listAmanProPremium.includes(r))) {
          // filterLiGoPremium.push(resultLi[index]);
        }
      } else if (listService.length === 3) {
        if (listService.some(r => listAman.includes(r))) {
          filterLi.push(resultLi[index]);
        } else if (listService.some(r => listProClassic.includes(r))) {
          // filterGo.push(resultLi[index]);
        } else if (listService.some(r => listProPremium.includes(r))) {
          // filterGoPremium.push(resultLi[index]);
        }
      } else {
        // filterWo.push(resultLi[index]);
      }
      listService = [];
    }

    // solve Go
    for (let index = 0; index < resultGo.length; index += 1) {
      const { fees } = resultGo[index];

      for (let indexFees = 0; indexFees < fees.length; indexFees += 1) {
        listService.push(fees[indexFees].service);
      }

      if (listService.length === 4) {
        if (listService.some(r => listAmanProClassic.includes(r))) {
          // filterLiGo.push(resultGo[index]);
        } else if (listService.some(r => listAmanProPremium.includes(r))) {
          // filterLiGoPremium.push(resultGo[index]);
        }
      } else if (listService.length === 3) {
        if (listService.some(r => listAman.includes(r))) {
          // filterLi.push(resultGo[index]);
        } else if (listService.some(r => listProClassic.includes(r))) {
          filterGo.push(resultGo[index]);
        } else if (listService.some(r => listProPremium.includes(r))) {
          // filterGoPremium.push(resultGo[index]);
        }
      } else {
        // filterWo.push(resultGo[index]);
      }
      listService = [];
    }

    // solve LiGo
    for (let index = 0; index < resultLiGo.length; index += 1) {
      const { fees } = resultLiGo[index];

      for (let indexFees = 0; indexFees < fees.length; indexFees += 1) {
        listService.push(fees[indexFees].service);
      }

      if (listService.length === 4) {
        if (listService.some(r => listAmanProClassic.includes(r))) {
          filterLiGo.push(resultLiGo[index]);
        } else if (listService.some(r => listAmanProPremium.includes(r))) {
          // filterLiGoPremium.push(resultLiGo[index]);
        }
      } else if (listService.length === 3) {
        if (listService.some(r => listAman.includes(r))) {
          // filterLi.push(resultLiGo[index]);
        } else if (listService.some(r => listProClassic.includes(r))) {
          // filterGo.push(resultLiGo[index]);
        } else if (listService.some(r => listProPremium.includes(r))) {
          // filterGoPremium.push(resultLiGo[index]);
        }
      } else {
        // filterWo.push(resultLiGo[index]);
      }
      listService = [];
    }

    // solve GoPremium
    for (let index = 0; index < resultGoPremium.length; index += 1) {
      const { fees } = resultGoPremium[index];

      for (let indexFees = 0; indexFees < fees.length; indexFees += 1) {
        listService.push(fees[indexFees].service);
      }

      if (listService.length === 4) {
        if (listService.some(r => listAmanProClassic.includes(r))) {
          filterLiGo.push(resultLiGo[index]);
        } else if (listService.some(r => listAmanProPremium.includes(r))) {
          // filterLiGoPremium.push(resultLiGo[index]);
        }
      } else if (listService.length === 3) {
        if (listService.some(r => listAman.includes(r))) {
          // filterLi.push(resultLiGo[index]);
        } else if (listService.some(r => listProClassic.includes(r))) {
          // filterGo.push(resultLiGo[index]);
        } else if (listService.some(r => listProPremium.includes(r))) {
          // filterGoPremium.push(resultLiGo[index]);
        }
      } else {
        // filterWo.push(resultLiGo[index]);
      }
      listService = [];
    }

    // solve GoPremium
    for (let index = 0; index < resultGoPremium.length; index += 1) {
      const { fees } = resultGoPremium[index];

      for (let indexFees = 0; indexFees < fees.length; indexFees += 1) {
        listService.push(fees[indexFees].service);
      }

      if (listService.length === 4) {
        if (listService.some(r => listAmanProClassic.includes(r))) {
          filterLiGo.push(resultGoPremium[index]);
        } else if (listService.some(r => listAmanProPremium.includes(r))) {
          // filterLiGoPremium.push(resultGoPremium[index]);
        }
      } else if (listService.length === 3) {
        if (listService.some(r => listAman.includes(r))) {
          // filterLi.push(resultGoPremium[index]);
        } else if (listService.some(r => listProClassic.includes(r))) {
          // filterGo.push(resultGoPremium[index]);
        } else if (listService.some(r => listProPremium.includes(r))) {
          // filterGoPremium.push(resultGoPremium[index]);
        }
      } else {
        // filterWo.push(resultGoPremium[index]);
      }
      listService = [];
    }

    // solve LiGoPremium
    for (let index = 0; index < resultLiGoPremium.length; index += 1) {
      const { fees } = resultLiGoPremium[index];

      for (let indexFees = 0; indexFees < fees.length; indexFees += 1) {
        listService.push(fees[indexFees].service);
      }

      if (listService.length === 4) {
        if (listService.some(r => listAmanProClassic.includes(r))) {
          // filterLiGo.push(resultLiGoPremium[index]);
        } else if (listService.some(r => listAmanProPremium.includes(r))) {
          filterLiGoPremium.push(resultLiGoPremium[index]);
        }
      } else if (listService.length === 3) {
        if (listService.some(r => listAman.includes(r))) {
          // filterLi.push(resultLiGoPremium[index]);
        } else if (listService.some(r => listProClassic.includes(r))) {
          // filterGo.push(resultLiGoPremium[index]);
        } else if (listService.some(r => listProPremium.includes(r))) {
          // filterGoPremium.push(resultLiGoPremium[index]);
        }
      } else {
        // filterWo.push(resultLiGoPremium[index]);
      }
      listService = [];
    }

    this.setState({
      resultWo: filterWo,
      resultLi: filterLi,
      resultGo: filterGo,
      resultLiGo: filterLiGo,
      resultGoPremium: filterGoPremium,
      resultLiGoPremium: filterLiGoPremium,
      resultChosen: filterWo,
    });
    this.triggerLoading(false);
  };

  handlePopupClose = () => {
    this.setState({
      popupShown: false,
    });
  };

  handleBack = () => {
    this.setState({
      isBack: true,
    });
  };

  handleClickTest = value => () => {
    const {
      resultWo,
      resultLi,
      resultGo,
      resultLiGo,
      resultGoPremium,
      resultLiGoPremium,
      filterInsurance,
      insuranceData,
    } = this.state;

    if (filterInsurance.includes(value)) {
      for (let i = 0; i < filterInsurance.length; i += 1) {
        if (filterInsurance[i] === value) {
          filterInsurance.splice(i, 1);
          insuranceData[
            insuranceData.findIndex(x => x.product === value)
          ].checked = false;
        }
      }
    } else if (
      filterInsurance.includes('proCLASSIC') &&
      value === 'proPREMIUM'
    ) {
      filterInsurance.splice(
        filterInsurance.findIndex(x => x === 'proCLASSIC'),
        1,
      );
      filterInsurance.push('proPREMIUM');
      insuranceData[
        insuranceData.findIndex(x => x.product === value)
      ].checked = true;
      insuranceData[
        insuranceData.findIndex(x => x.product === 'proCLASSIC')
      ].checked = false;
    } else if (
      filterInsurance.includes('proPREMIUM') &&
      value === 'proCLASSIC'
    ) {
      filterInsurance.splice(
        filterInsurance.findIndex(x => x === 'proPREMIUM'),
        1,
      );
      filterInsurance.push('proCLASSIC');
      insuranceData[
        insuranceData.findIndex(x => x.product === value)
      ].checked = true;
      insuranceData[
        insuranceData.findIndex(x => x.product === 'proPREMIUM')
      ].checked = false;
    } else {
      filterInsurance.push(value);
      insuranceData[
        insuranceData.findIndex(x => x.product === value)
      ].checked = true;
    }

    filterInsurance.sort();

    this.setState({
      resultChosen: [],
      chosenProduct: [],
    });

    if (filterInsurance.length === 0) {
      this.setState({
        resultChosen: resultWo,
      });
    } else if (filterInsurance.length === 1) {
      if (filterInsurance.includes('AMAN')) {
        this.setState({
          resultChosen: resultLi,
        });
      } else if (filterInsurance.includes('proCLASSIC')) {
        this.setState({
          resultChosen: resultGo,
        });
      } else {
        this.setState({
          resultChosen: resultGoPremium,
        });
      }
    } else if (filterInsurance.length === 2) {
      if (
        filterInsurance.includes('AMAN') &&
        filterInsurance.includes('proCLASSIC')
      ) {
        this.setState({ resultChosen: resultLiGo });
      } else if (
        filterInsurance.includes('AMAN') &&
        filterInsurance.includes('proPREMIUM')
      ) {
        this.setState({ resultChosen: resultLiGoPremium });
      } else {
        this.setState({ resultChosen: [] });
      }
    } else {
      this.setState({ resultChosen: [] });
    }
  };

  handleChooseProduct = code => {
    const {
      resultWo,
      resultLi,
      resultGo,
      resultLiGo,
      resultGoPremium,
      resultLiGoPremium,
      filterInsurance,
    } = this.state;

    this.setState({
      chosenProduct: [],
    });

    let arrayIndex = 0;

    if (filterInsurance.length === 0) {
      arrayIndex = resultWo.findIndex(x => x.code === code);
      this.setState({ chosenProduct: resultWo[arrayIndex] });
    } else if (filterInsurance.length === 1) {
      if (filterInsurance.includes('AMAN')) {
        arrayIndex = resultLi.findIndex(x => x.code === code);
        this.setState({
          chosenProduct: resultLi[arrayIndex],
        });
      } else if (filterInsurance.includes('proCLASSIC')) {
        arrayIndex = resultGo.findIndex(x => x.code === code);
        this.setState({
          chosenProduct: resultGo[arrayIndex],
        });
      } else {
        arrayIndex = resultGoPremium.findIndex(x => x.code === code);
        this.setState({
          chosenProduct: resultGoPremium[arrayIndex],
        });
      }
    } else if (filterInsurance.length === 2) {
      if (
        filterInsurance.includes('AMAN') &&
        filterInsurance.includes('proCLASSIC')
      ) {
        arrayIndex = resultLiGo.findIndex(x => x.code === code);
        this.setState({ chosenProduct: resultLiGo[arrayIndex] });
      } else if (
        filterInsurance.includes('AMAN') &&
        filterInsurance.includes('proPREMIUM')
      ) {
        arrayIndex = resultLiGoPremium.findIndex(x => x.code === code);
        this.setState({ chosenProduct: resultLiGoPremium[arrayIndex] });
      } else {
        this.setState({ chosenProduct: [] });
      }
    } else {
      this.setState({ chosenProduct: [] });
    }
  };

  triggerLoading = loadingShown => {
    const isShown = loadingShown;
    if (isShown) {
      this.setState({
        isLoading: true,
      });
    } else {
      this.setState({ isLoading: false });
    }
  };

  handleContinue = () => {
    const { pushValue } = this.context;
    const { chosenProduct } = this.state;
    const stepThreeValue = {
      product: chosenProduct,
    };
    pushValue(stepNumber, stepThreeValue);
    this.setState({ isValid: true });
  };

  render() {
    const {
      insuranceData,
      filterInsurance,
      resultChosen,
      chosenProduct,
      popupShown,
      isValid,
      isBack,
      isLoading,
    } = this.state;

    const { value } = this.context;

    if (
      Object.keys(value.stepOne).length === 0 &&
      value.stepOne.constructor === Object
    )
      return <Redirect to="/create-application/step-one" />;

    if (isValid) return <Redirect to="/create-application/step-four" />;

    if (isBack) return <Redirect to="/create-application/step-two" />;

    return (
      <React.Fragment>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>
                    Data Pengajuan <br />& Kontrak
                  </div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Langkah 3</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Penawaran Kami</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>Berikut Penawaran Kami untuk Pembiayaan Anda</p>
                </div>
                <div className={styles['textfield-container']}>
                  <div className={styles['title-description']}>
                    <div>
                      <p>Perlindungan Tambahan</p>
                      <img src={Information} alt="Information" />
                    </div>
                  </div>
                  {insuranceData.map(props => (
                    <div className={styles['insurance-options']} key={props.id}>
                      <label className={styles.container}>
                        {props.product}
                        <input
                          id="insuranceCheckbox"
                          type="checkbox"
                          onChange={this.handleClickTest(props.product)}
                          checked={props.checked}
                        />
                        <span className={styles.checkmark} />
                      </label>
                    </div>
                  ))}
                </div>
                <div className={styles['step-detail-container']}>
                  <p>
                    Berikut Merupakan Hasil Kalkulasi untuk Penawaran Terbaik
                    dari Kami
                  </p>
                </div>
                {resultChosen.map(props => (
                  // <OfferComponent key={data.code} {...props} />
                  <div
                    className={styles['textfield-container']}
                    key={props.code}
                    onClick={() => this.handleChooseProduct(props.code)}
                    onKeyPress={() => this.handleChooseProduct(props.code)}
                    role="button"
                    tabIndex="0"
                  >
                    <div className={styles['option-title-wrapper']}>
                      <div className={styles['option-title']}>
                        {props.product.name}
                      </div>
                      <div
                        className={
                          props.code === chosenProduct.code
                            ? styles['option-tick']
                            : styles['option-untick']
                        }
                      >
                        <img src={OptionTick} alt="Option Tick" />
                      </div>
                    </div>
                    <div className={styles['option-filter-wrapper']}>
                      {filterInsurance.map(insurance => (
                        <div
                          className={styles['option-filter']}
                          key={insurance}
                        >
                          <p>{insurance}</p>
                        </div>
                      ))}
                    </div>
                    <div className={styles['option-detail']}>
                      <div className={styles['option-detail-wrapper']}>
                        <div className={styles['option-detail-title']}>
                          Harga Barang
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>
                            Rp
                            <NumberFormat
                              value={props.totalPrice}
                              thousandSeparator
                              displayType="text"
                            />
                          </p>
                        </div>
                      </div>
                      <div className={styles['option-detail-wrapper']}>
                        <div className={styles['option-detail-title']}>
                          Uang Muka
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>
                            Rp
                            <NumberFormat
                              value={props.downPayment}
                              thousandSeparator
                              displayType="text"
                            />
                          </p>
                        </div>
                      </div>
                      <div className={styles['option-detail-wrapper']}>
                        <div className={styles['option-detail-title']}>
                          Tenor
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>{props.terms} bulan</p>
                        </div>
                      </div>
                    </div>
                    <div className={styles['option-summary']}>
                      <div className={styles['option-summary-wrapper']}>
                        <div className={styles['option-summary-title']}>
                          Cicilan per Bulan
                        </div>
                        <div className={styles['option-summary-value']}>
                          <p>
                            Rp
                            <NumberFormat
                              value={props.totalInstallment}
                              thousandSeparator
                              displayType="text"
                            />
                          </p>
                        </div>
                      </div>
                      <div className={styles['option-interest-wrapper']}>
                        <div className={styles['option-summary-title']}>
                          Suku Bunga
                        </div>
                        <div className={styles['option-summary-value']}>
                          <p>
                            {(props.presentedInterestRate1 * 100)
                              .toFixed(2)
                              .replace(/\d(?=(\d{3})+\.)/g, '$&,')}
                            %
                          </p>
                        </div>
                      </div>
                    </div>
                    <div
                      className={
                        filterInsurance.length > 0
                          ? styles['option-detail-insurance']
                          : styles['option-detail-insurance-none']
                      }
                    >
                      <div className={styles['option-detail-wrapper']}>
                        <div className={styles['option-detail-title']}>
                          Perlindungan Tambahan
                        </div>
                        <div className={styles['option-insurance-value']}>
                          {props.fees
                            .filter(x => x.service !== null)
                            .map(data => (
                              <div key={data.code}>
                                <div
                                  className={styles['option-insurance-filter']}
                                >
                                  <p>
                                    {(() => {
                                      if (listAman.includes(data.service)) {
                                        return 'AMAN';
                                        // eslint-disable-next-line no-else-return
                                      } else if (
                                        listProClassic.includes(data.service)
                                      ) {
                                        return 'proCLASSIC';
                                      } else if (
                                        listProPremium.includes(data.service)
                                      ) {
                                        return 'proPREMIUM';
                                      } else {
                                        return '';
                                      }
                                    })()}
                                  </p>
                                </div>
                                <div
                                  className={styles['option-insurance-amount']}
                                >
                                  <p>
                                    Rp
                                    <NumberFormat
                                      value={data.amount}
                                      thousandSeparator
                                      displayType="text"
                                    />
                                  </p>
                                </div>
                              </div>
                            ))}
                        </div>
                      </div>
                    </div>
                    <div className={styles['option-payment']}>
                      <div className={styles['option-payment-title']}>
                        Total Pembayaran Tunai
                      </div>
                      <div className={styles['option-payment-detail']}>
                        <div className={styles['option-payment-logo']}>
                          <img src={Money} alt="Money" />
                        </div>
                        <div className={styles['option-payment-description']}>
                          <p className={styles['option-payment-value']}>
                            Rp
                            <NumberFormat
                              value={props.cashPayment}
                              thousandSeparator
                              displayType="text"
                            />
                          </p>
                          <p className={styles['option-payment-subtitle']}>
                            (Uang Muka + Biaya Admin)
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                <div
                  className={
                    chosenProduct.length !== 0
                      ? styles['submit-button-container']
                      : styles['submit-button-container-disabled']
                  }
                  onClick={
                    chosenProduct.length !== 0 ? this.handleContinue : () => {}
                  }
                  onKeyPress={
                    chosenProduct.length !== 0 ? this.handleContinue : () => {}
                  }
                  role="button"
                  tabIndex="0"
                >
                  <p>Lanjut</p>
                </div>
                <div
                  className={styles['back-button-container']}
                  onClick={this.handleBack}
                  onKeyPress={this.handleBack}
                  role="button"
                  tabIndex="0"
                >
                  <p>Kembali</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <MobileFooter />
        <Dialog open={popupShown} onClose={this.handlePopupClose} fullWidth>
          <div className={styles['popup-container']}>
            <div className={styles['popup-description-wrapper']}>
              <div className={styles['popup-title']}>
                <h2>Perlindungan Tambahan</h2>
              </div>
              <div className={styles['popup-info-wrapper']}>
                <div className={styles['popup-title']}>AMAN</div>
                <div className={styles['popup-description']}>
                  menjamin pembayaran cicilan Anda bila Anda atau pasangan
                  mengalami kejadian tidak terduga (sakit atau kecelakaan)
                </div>
              </div>
              <div className={styles['popup-info-wrapper']}>
                <div className={styles['popup-title']}>proCLASSIC</div>
                <div className={styles['popup-description']}>
                  melindungi perangkat Anda (HP, Gadget atau Laptop) dari risiko
                  akibat kerusakan yang tidak terduga
                </div>
              </div>
              <div className={styles['popup-info-wrapper']}>
                <div className={styles['popup-title']}>proPREMIUM</div>
                <div className={styles['popup-description']}>
                  melindungi perangkat Anda (HP, Gadget atau Laptop) dari risiko
                  akibat kerusakan yang tidak disengaja dan kehilangan perangkat
                  akibat pencurian/perampokan.
                </div>
              </div>
              <div
                className={styles['popup-button']}
                onClick={this.handlePopupClose}
                onKeyPress={this.handlePopupClose}
                role="button"
                tabIndex="0"
              >
                <p>Tutup</p>
              </div>
            </div>
          </div>
        </Dialog>
        <LoadingContainer open={isLoading} />
      </React.Fragment>
    );
  }
}

export default StepThree;
