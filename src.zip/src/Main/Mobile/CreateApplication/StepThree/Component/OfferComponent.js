import React from 'react';
import styles from './OfferComponent.module.css';
import OptionTick from '../../../../../assets/images/option-tick.svg';
import Money from '../../../../../assets/images/money.svg';

const OfferComponent = props => (
  <div className={styles['textfield-container']}>
    <div className={styles['option-title-wrapper']}>
      <div className={styles['option-title']}>{props.product}</div>
      <div
        className={
          props.isChosen ? styles['option-tick'] : styles['option-untick']
        }
      >
        <img src={OptionTick} alt="Option Tick" />
      </div>
    </div>
    <div className={styles['option-filter']}>
      <p>AMAN</p>
    </div>
    <div className={styles['option-detail']}>
      <div className={styles['option-detail-wrapper']}>
        <div className={styles['option-detail-title']}>Harga Barang</div>
        <div className={styles['option-detail-value']}>
          <p>{props.value}</p>
        </div>
      </div>
      <div className={styles['option-detail-wrapper']}>
        <div className={styles['option-detail-title']}>Uang Muka</div>
        <div className={styles['option-detail-value']}>
          <p>{props.downPayment}</p>
        </div>
      </div>
      <div className={styles['option-detail-wrapper']}>
        <div className={styles['option-detail-title']}>Tenor</div>
        <div className={styles['option-detail-value']}>
          <p>{props.tenor}</p>
        </div>
      </div>
    </div>
    <div className={styles['option-summary']}>
      <div className={styles['option-summary-wrapper']}>
        <div className={styles['option-summary-title']}>Cicilan per Bulan</div>
        <div className={styles['option-summary-value']}>
          <p>{props.installment}</p>
        </div>
      </div>
      <div className={styles['option-interest-wrapper']}>
        <div className={styles['option-summary-title']}>Suku Bunga</div>
        <div className={styles['option-summary-value']}>
          <p>{props.interest}</p>
        </div>
      </div>
    </div>
    <div className={styles['option-payment']}>
      <div className={styles['option-payment-title']}>
        Total Pembayaran Tunai
      </div>
      <div className={styles['option-payment-detail']}>
        <div className={styles['option-payment-logo']}>
          <img src={Money} alt="Money" />
        </div>
        <div className={styles['option-payment-description']}>
          <p className={styles['option-payment-value']}>{props.downPayment}</p>
          <p className={styles['option-payment-subtitle']}>
            (Uang Muka + Biaya Admin)
          </p>
        </div>
      </div>
    </div>
  </div>
);

export default OfferComponent;
