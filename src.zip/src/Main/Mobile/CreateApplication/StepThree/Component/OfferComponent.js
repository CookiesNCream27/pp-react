import React, { Component } from 'react';
import NumberFormat from 'react-number-format';
import styles from './OfferComponent.module.css';
import OptionTick from '../../../../../assets/images/option-tick.svg';
import Money from '../../../../../assets/images/money.svg';

class OfferComponent extends Component {
  render() {
    const data = this.props;
    return (
      <div className={styles['textfield-container']}>
        <div className={styles['option-title-wrapper']}>
          <div className={styles['option-title']}>{data.product.name}</div>
          <div
            className={
              data.isChosen ? styles['option-tick'] : styles['option-untick']
            }
          >
            <img src={OptionTick} alt="Option Tick" />
          </div>
        </div>
        <div className={styles['option-filter']}>
          <p>AMAN</p>
        </div>
        <div className={styles['option-detail']}>
          <div className={styles['option-detail-wrapper']}>
            <div className={styles['option-detail-title']}>Harga Barang</div>
            <div className={styles['option-detail-value']}>
              <p>
                Rp
                <NumberFormat
                  value={data.totalPrice}
                  thousandSeparator
                  displayType="text"
                />
              </p>
            </div>
          </div>
          <div className={styles['option-detail-wrapper']}>
            <div className={styles['option-detail-title']}>Uang Muka</div>
            <div className={styles['option-detail-value']}>
              <p>
                Rp
                <NumberFormat
                  value={data.downPayment}
                  thousandSeparator
                  displayType="text"
                />
              </p>
            </div>
          </div>
          <div className={styles['option-detail-wrapper']}>
            <div className={styles['option-detail-title']}>Tenor</div>
            <div className={styles['option-detail-value']}>
              <p>{data.terms} bulan</p>
            </div>
          </div>
        </div>
        <div className={styles['option-summary']}>
          <div className={styles['option-summary-wrapper']}>
            <div className={styles['option-summary-title']}>
              Cicilan per Bulan
            </div>
            <div className={styles['option-summary-value']}>
              <p>
                Rp
                <NumberFormat
                  value={data.totalInstallment}
                  thousandSeparator
                  displayType="text"
                />
              </p>
            </div>
          </div>
          <div className={styles['option-interest-wrapper']}>
            <div className={styles['option-summary-title']}>Suku Bunga</div>
            <div className={styles['option-summary-value']}>
              <p>
                {(data.presentedInterestRate1 * 100)
                  .toFixed(2)
                  .replace(/\d(?=(\d{3})+\.)/g, '$&,')}
                %
              </p>
            </div>
          </div>
        </div>
        <div className={styles['option-payment']}>
          <div className={styles['option-payment-title']}>
            Total Pembayaran Tunai
          </div>
          <div className={styles['option-payment-detail']}>
            <div className={styles['option-payment-logo']}>
              <img src={Money} alt="Money" />
            </div>
            <div className={styles['option-payment-description']}>
              <p className={styles['option-payment-value']}>
                Rp
                <NumberFormat
                  value={data.cashPayment}
                  thousandSeparator
                  displayType="text"
                />
              </p>
              <p className={styles['option-payment-subtitle']}>
                (Uang Muka + Biaya Admin)
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default OfferComponent;
