import React, { Component } from 'react';
import PropTypes from 'prop-types';
import styles from './InsuranceComponent.module.css';

class InsuranceComponent extends Component {
  render() {
    const { product } = this.props;
    return (
      <div className={styles['insurance-options']}>
        <label className={styles.container}>
          {product}
          <input type="checkbox" />
          <span className={styles.checkmark} />
        </label>
      </div>
    );
  }
}

export default InsuranceComponent;

InsuranceComponent.propTypes = {
  product: PropTypes.string,
};

InsuranceComponent.defaultProps = {
  product: '',
};
