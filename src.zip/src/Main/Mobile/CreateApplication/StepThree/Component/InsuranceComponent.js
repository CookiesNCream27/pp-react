import React, { Component } from 'react';
import styles from './InsuranceComponent.module.css';

class InsuranceComponent extends Component {
  render() {
    const { product, nigga } = this.props;
    return (
      <div className={styles['insurance-options']}>
        <label className={styles.container}>
          {product}
          <input type="checkbox" onClick={nigga(product)} />
          <span className={styles.checkmark} />
        </label>
      </div>
    );
  }
}

export default InsuranceComponent;
