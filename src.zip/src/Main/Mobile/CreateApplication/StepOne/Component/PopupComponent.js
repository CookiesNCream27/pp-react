import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Dialog from '@material-ui/core/Dialog';
import styles from './PopupComponent.module.css';
import LoginFailed from '../../../../../assets/images/login_failed.png';

class PopupComponent extends Component {
  handlePopupClose = e => {
    const { popupClose } = this.props;
    e.preventDefault();
    popupClose();
  };

  handleFingerprintPopupClose = e => {
    const { fingerprintPopupClose } = this.props;
    e.preventDefault();
    fingerprintPopupClose();
  };

  render() {
    const {
      popupShown,
      popupTitle,
      popupInfo,
      fingerprintPopupShown,
    } = this.props;
    return (
      <React.Fragment>
        <Dialog
          open={popupShown}
          onClose={this.handlePopupClose}
          fullWidth
          disableBackdropClick
          disableEscapeKeyDown
        >
          <div className={styles['popup-container']}>
            <div>
              <img src={LoginFailed} alt="Login Failed" />
            </div>
            <div>
              <h2 className={styles['popup-title']}>{popupTitle}</h2>{' '}
            </div>
            <div>
              <p className={styles['popup-description']}>{popupInfo}</p>
            </div>
            <div
              className={styles['popup-button']}
              onClick={this.handlePopupClose}
              onKeyPress={this.handlePopupClose}
              role="button"
              tabIndex="0"
            >
              <p>Tutup</p>
            </div>
          </div>
        </Dialog>
        <Dialog
          open={fingerprintPopupShown}
          onClose={this.handleFingerprintPopupClose}
          fullWidth
          disableBackdropClick
          disableEscapeKeyDown
        >
          <div className={styles['fingerprint-container']}>
            <div className={styles['fingerprint-title']}>Peringatan!</div>
            <div className={styles['fingerprint-content']}>
              Mohon Maaf, Anda belum bisa melakukan Pengajuan Kontrak melalui
              ponsel Anda
            </div>
            <div className={styles['fingerprint-content-second']}>
              Silahkan Akses melalui PC/Laptop Anda.
            </div>
            <div
              className={styles['popup-button']}
              onClick={this.handleFingerprintPopupClose}
              onKeyPress={this.handleFingerprintPopupClose}
              role="button"
              tabIndex="0"
            >
              <p>Tutup</p>
            </div>
          </div>
        </Dialog>
      </React.Fragment>
    );
  }
}

export default PopupComponent;

PopupComponent.propTypes = {
  popupShown: PropTypes.bool,
  popupTitle: PropTypes.string,
  popupInfo: PropTypes.string,
  popupClose: PropTypes.func,
  fingerprintPopupShown: PropTypes.bool,
  fingerprintPopupClose: PropTypes.func,
};

PopupComponent.defaultProps = {
  popupShown: false,
  popupTitle: '',
  popupInfo: '',
  popupClose: () => {},
  fingerprintPopupShown: false,
  fingerprintPopupClose: () => {},
};
