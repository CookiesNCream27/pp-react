import React, { Component } from 'react';
import axios from 'axios';
import { Redirect } from 'react-router-dom';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import InputBase from '@material-ui/core/InputBase';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import uuidv4 from 'uuid/v4';
import { GetAxios } from '../../../../Utils/Services';
import { DevTools, JavaLogger } from '../../../../Utils/SharedFunctions';
import resolvePrivileges from '../../../../Utils/UserPrivileges';
import styles from './StepOneContainer.module.css';
import PopupComponent from './Component/PopupComponent';
import LoadingContainer from '../../Loading/LoadingContainer';
import { CreateApplicationContext } from '../CreateApplicationContext';

const theme = createMuiTheme({
  typography: {
    useNextVariants: true,
    htmlFontSize: 15,
  },
  overrides: {
    MuiInput: {
      underline: {
        '&:before,&:after': {
          borderBottom: '2px solid #f8f5f8',
        },
      },
    },
  },
});

const deliveryMethodData = [
  {
    value: 'NONE',
    label: 'Pilih Metode Penyerahan',
    disabled: true,
  },
  {
    value: 'LP',
    label: 'Diserahkan di Toko',
    disabled: false,
  },
  {
    value: 'GD',
    label: 'Dikirim ke Rumah',
    disabled: false,
  },
];

const stepNumber = 1;

class StepOne extends Component {
  static contextType = CreateApplicationContext;

  signal = axios.CancelToken.source();

  constructor(props) {
    super(props);

    this.state = {
      deliveryMethod: 'NONE',
      nik: '',
      applicationId: uuidv4(),
      popupShown: false,
      fingerprintPopupShown: false,
      popupTitle: '',
      popupInfo: '',
      isValid: '',
      isLoading: false,
      isRedirectToFirstPage: false,
    };
  }

  componentDidMount() {
    if (this.checkFingerprintAccess()) {
      this.testConnection();
      const { applicationId } = this.state;
      JavaLogger('MNU_START_APP', applicationId, this.signal);
    } else {
      this.setState({
        fingerprintPopupShown: true,
      });
    }
    this.triggerLoading(false);
  }

  componentWillUnmount() {
    this.signal.cancel('Login Api has been canceled');
  }

  checkFingerprintAccess = () => resolvePrivileges.canAccessNoFP();

  testConnection = async () => {
    try {
      const { data } = await GetAxios(
        'MAIN',
        '/api/v1/bsl/test-connection',
        this.signal.token,
      );
      if (data.code === 'ERR_CONNECTION_FAILED_TO_BSL') {
        this.setState({
          popupShown: true,
          popupTitle: 'Informasi',
          popupInfo:
            'Maaf, sedang terdapat kendala pada sistem kami. Mohon coba kembali!',
        });
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
  };

  handleChangeDeliveryMethod = () => event => {
    this.setState({
      deliveryMethod: event.target.value,
    });
  };

  handleChangeNik = () => event => {
    const regex = /^\d+$/;
    if (regex.test(event.target.value) || event.target.value.length === 0) {
      if (event.target.value.length <= 16) {
        this.setState({ nik: event.target.value });
      }
    }
  };

  nikLengthValidation = () => {
    const { nik } = this.state;
    if (nik.length === 16) {
      this.nikValidation();
    } else {
      this.setState({
        popupShown: true,
        popupTitle: 'Informasi',
        popupInfo: 'NIK harus berjumlah 16 digit',
      });
    }
  };

  nikValidation = () => {
    const { nik } = this.state;

    const tanggalLahir = nik.substr(6, 2);
    const bulanLahir = nik.substr(8, 2);
    // const tahunLahir = nik.substr(10, 2);
    const numTanggalLahir = parseInt(tanggalLahir, 10);
    const numBulanLahir = parseInt(bulanLahir, 10);
    // const numTahunLahir = parseInt(tahunLahir, 10);

    const numLastDigit = nik.substr(12, 4);

    if (
      numTanggalLahir > 0 &&
      numTanggalLahir < 32 &&
      numBulanLahir > 0 &&
      numBulanLahir < 13 &&
      numLastDigit !== '0000'
    ) {
      this.ageValidation();
    } else if (
      numTanggalLahir > 40 &&
      numTanggalLahir < 72 &&
      numBulanLahir > 0 &&
      numBulanLahir < 13 &&
      numLastDigit !== '0000'
    ) {
      this.ageValidation();
    } else {
      this.setState({
        popupShown: true,
        popupTitle: 'Informasi',
        popupInfo: 'Format NIK tidak sesuai',
      });
    }
  };

  ageValidation = () => {
    const { deliveryMethod, nik, applicationId } = this.state;

    let tanggalLahir = nik.substr(6, 2);
    const bulanLahir = nik.substr(8, 2);
    const tahunLahir = nik.substr(10, 2);
    const genderCheck = parseInt(tanggalLahir, 10);
    if (genderCheck > 40) {
      const a = genderCheck - 40;
      if (a < 10) {
        tanggalLahir = `0${a.toString()}`;
      } else {
        tanggalLahir = a.toString();
      }
    }
    // const numBulanLahir = parseInt(bulanLahir, 10);
    const numTahunLahir = parseInt(tahunLahir, 10);

    const today = new Date();
    // const dd = `0${today.getDate()}`.slice(-2);
    // const mm = `0${today.getMonth() + 1}`.slice(-2);
    const yyyy = today.getFullYear();
    const yy = parseInt(yyyy.toString().substr(-2), 10);

    let numTahunLahirYYYY;

    if (numTahunLahir < yy) {
      numTahunLahirYYYY = parseInt(`200${numTahunLahir.toString()}`, 10);
    } else if (numTahunLahir > yy) {
      numTahunLahirYYYY = parseInt(`19${numTahunLahir.toString()}`, 10);
    } else {
      numTahunLahirYYYY = parseInt(`20${yy.toString()}`, 10);
    }

    const birthDate = `${numTahunLahirYYYY.toString()}-${bulanLahir}-${tanggalLahir}`;
    // const todayDate = `${yyyy.toString()}-${mm.toString()}-${dd.toString()}`;

    const diffInMs = Date.now() - Date.parse(birthDate);

    const diffInYear = Math.floor(diffInMs / (1000 * 60 * 60 * 24 * 365.25));

    if (diffInYear >= 19) {
      const { pushValue } = this.context;
      const stepOneValue = {
        nikValue: nik,
        deliveryMethodValue: deliveryMethod,
        startApplicationId: applicationId,
      };
      pushValue(stepNumber, stepOneValue);
      this.setState({
        popupShown: false,
        popupTitle: '',
        popupInfo: '',
        isValid: true,
      });
    } else {
      this.setState({
        popupShown: true,
        popupTitle: 'Informasi',
        popupInfo: 'Umur pelanggan harus diatas atau sama dengan 19 tahun',
      });
    }
  };

  handlePopupClose = () => {
    this.setState({
      popupShown: false,
    });
  };

  handleFingerprintPopupClose = () => {
    this.setState({
      fingerprintPopupShown: false,
      isRedirectToFirstPage: true,
    });
  };

  triggerLoading = loadingShown => {
    const isShown = loadingShown;
    if (isShown) {
      this.setState({
        isLoading: true,
      });
    } else {
      this.setState({ isLoading: false });
    }
  };

  render() {
    const {
      deliveryMethod,
      nik,
      isValid,
      isLoading,
      isRedirectToFirstPage,
      popupShown,
      fingerprintPopupShown,
      popupTitle,
      popupInfo,
    } = this.state;

    if (isRedirectToFirstPage) return <Redirect to="/home" />;

    if (isValid) return <Redirect to="/create-application/step-two" />;

    return (
      <React.Fragment>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>
                    Data Pengajuan <br />& Kontrak
                  </div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Langkah 1</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Informasi Pelanggan</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>Pastikan Nomor Identitas Anda Sesuai dengan KTP</p>
                </div>
                <div className={styles['textfield-container']}>
                  <div className={styles['first-description']}>
                    Metode Penyerahan Barang
                  </div>
                  <div className={styles['first-field']}>
                    <MuiThemeProvider theme={theme}>
                      <TextField
                        select
                        value={deliveryMethod}
                        onChange={this.handleChangeDeliveryMethod()}
                        fullWidth
                      >
                        {deliveryMethodData.map(option => (
                          <MenuItem
                            key={option.value}
                            value={option.value}
                            disabled={option.disabled}
                          >
                            {option.label}
                          </MenuItem>
                        ))}
                      </TextField>
                    </MuiThemeProvider>
                  </div>
                  {/* <hr /> */}
                  <div className={styles['second-description']}>
                    Data Pelanggan
                  </div>
                  <div className={styles['second-field']}>
                    <MuiThemeProvider theme={theme}>
                      <InputBase
                        type="tel"
                        placeholder="Isi NIK Sesuai KTP"
                        fullWidth
                        onChange={this.handleChangeNik()}
                        onKeyUp={this.handleChangeNik()}
                        maxLength="16"
                        value={nik}
                      />
                    </MuiThemeProvider>
                  </div>
                </div>
                <div
                  className={
                    deliveryMethod !== 'NONE' && nik.length !== 0
                      ? styles['submit-button-container']
                      : styles['submit-button-container-disabled']
                  }
                  onClick={
                    deliveryMethod !== 'NONE' && nik.length !== 0
                      ? this.nikLengthValidation
                      : () => {}
                  }
                  onKeyPress={
                    deliveryMethod !== 'NONE' && nik.length !== 0
                      ? this.nikLengthValidation
                      : () => {}
                  }
                  role="button"
                  tabIndex="0"
                >
                  <p>Lanjut</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <PopupComponent
          popupShown={popupShown}
          popupTitle={popupTitle}
          popupInfo={popupInfo}
          popupClose={this.handlePopupClose}
          fingerprintPopupShown={fingerprintPopupShown}
          fingerprintPopupClose={this.handleFingerprintPopupClose}
        />
        <LoadingContainer open={isLoading} />
      </React.Fragment>
    );
  }
}

export default StepOne;
