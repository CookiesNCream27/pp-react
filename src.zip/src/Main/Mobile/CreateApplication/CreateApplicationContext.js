import React from 'react';
import PropTypes from 'prop-types';
// import { DevTools } from '../../../Utils/SharedFunctions';

const CreateApplicationContext = React.createContext();

const createApplicationObject = {
  stepOne: {},
  stepTwo: {},
  stepThree: {},
  stepFour: {},
  stepFive: {},
  stepSix: {},
};

class CreateApplicationProvider extends React.Component {
  state = { value: createApplicationObject };

  constructor() {
    super();
    this.pushValue = this.pushValue.bind(this);
    this.removeValue = this.removeValue.bind(this);
  }

  pushValue(step, data) {
    switch (step) {
      case 1:
        this.setState(prevState => ({
          value: {
            ...prevState.value,
            stepOne: data,
          },
        }));
        break;
      case 2:
        this.setState(prevState => ({
          value: {
            ...prevState.value,
            stepTwo: data,
          },
        }));
        break;
      case 3:
        this.setState(prevState => ({
          value: {
            ...prevState.value,
            stepThree: data,
          },
        }));
        break;
      case 4:
        this.setState(prevState => ({
          value: {
            ...prevState.value,
            stepFour: data,
          },
        }));
        break;
      case 5:
        this.setState(prevState => ({
          value: {
            ...prevState.value,
            stepFive: data,
          },
        }));
        break;
      case 6:
        this.setState(prevState => ({
          value: {
            ...prevState.value,
            stepSix: data,
          },
        }));
        break;
      default:
        break;
    }
  }

  removeValue(step) {
    switch (step) {
      case 2:
        this.setState(prevState => ({
          value: {
            ...prevState.value,
            stepOne: {},
          },
        }));
        break;
      case 3:
        this.setState(prevState => ({
          value: {
            ...prevState.value,
            stepTwo: {},
          },
        }));
        break;
      case 4:
        this.setState(prevState => ({
          value: {
            ...prevState.value,
            stepThree: {},
          },
        }));
        break;
      case 5:
        this.setState(prevState => ({
          value: {
            ...prevState.value,
            stepFour: {},
          },
        }));
        break;
      case 6:
        this.setState(prevState => ({
          value: {
            ...prevState.value,
            stepFive: {},
          },
        }));
        break;
      default:
        break;
    }
  }

  render() {
    const { value } = this.state;
    const { children } = this.props;
    return (
      <CreateApplicationContext.Provider
        value={{
          value,
          pushValue: this.pushValue,
          removeValue: this.removeValue,
        }}
      >
        {children}
      </CreateApplicationContext.Provider>
    );
  }
}

CreateApplicationProvider.propTypes = {
  children: PropTypes.element.isRequired,
};

const CreateApplicationConsumer = CreateApplicationContext.Consumer;

export {
  CreateApplicationProvider,
  CreateApplicationConsumer,
  CreateApplicationContext,
};
