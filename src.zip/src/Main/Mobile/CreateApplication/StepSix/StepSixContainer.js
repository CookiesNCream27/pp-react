import React, { Component } from 'react';
import axios from 'axios';
import { Redirect } from 'react-router-dom';
import { Logger } from '../../../../Utils/SharedFunctions';
import styles from './StepSixContainer.module.css';
import MobileFooter from '../../Common/FooterComponent';
import { CreateApplicationContext } from '../CreateApplicationContext';
import { GetAxios } from '../../../../Utils/Services';

class StepSix extends Component {
  static contextType = CreateApplicationContext;

  signal = axios.CancelToken.source();

  constructor(props) {
    super(props);
    this.state = {
      qrCode: '',
      isValid: '',
    };

    this.getQrCode();
  }

  getQrCode = async () => {
    try {
      const { data } = await GetAxios(
        'MAIN',
        '/api/utils/v1/image/generate-qrcode/A190000913',
        this.signal.token,
        true,
      );
      const image = `data:${data['content-type']};base64,${btoa(
        String.fromCharCode(...new Uint8Array(data)),
      )}`;
      this.setState({ qrCode: image });
    } catch (error) {
      if (axios.isCancel(error)) {
        Logger(() => console.log('Error: ', error.message));
      }
    }
  };

  handleContinue = () => {
    this.setState({
      isValid: true,
    });
  };

  render() {
    const { qrCode, isValid } = this.state;
    Logger(() => console.log(qrCode, isValid));
    Logger(() => console.log(this.context));

    if (isValid) return <Redirect to="/home" />;

    return (
      <div>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>
                    Data Pengajuan <br />& Kontrak
                  </div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Langkah 6</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Scan QR Code</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>
                    Minta Pelanggan untuk Scan QR Code berikut menggunakan
                    Aplikasi{' '}
                    <span className={styles['brand-style']}>
                      My Home Credit.
                    </span>
                  </p>
                </div>
                <div className={styles['textfield-container']}>
                  <div className={styles['qr-code']}>
                    <img src={qrCode} alt="qrCode" />
                  </div>
                  <div className={styles['qr-description']}>
                    Setelah berhasil scan, minta pelanggan untuk mengisi
                    pengajuan di{' '}
                    <span className={styles['brand-style']}>
                      My Home Credit.
                    </span>
                  </div>
                </div>
                <div
                  className={styles['submit-button-container']}
                  onClick={this.handleContinue}
                  onKeyPress={this.handleContinue}
                  role="button"
                  tabIndex="0"
                >
                  <p>Selesai</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <MobileFooter />
      </div>
    );
  }
}

export default StepSix;
