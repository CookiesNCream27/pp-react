import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './NavbarComponent.module.css';
import IconBeranda from '../../../assets/images/icon-beranda.png';
import IconKontrak from '../../../assets/images/icon-kontrak.png';
import IconProfil from '../../../assets/images/icon-profil.png';
import { AuthContext } from '../../AuthContext';

class MobileNavbar extends Component {
  static contextType = AuthContext;

  render() {
    const { isAuth } = this.context;
    return (
      <React.Fragment>
        {isAuth && (
          <div className={styles['navbar-container']}>
            <NavLink
              exact
              to="/home"
              className={styles['nav-button-container']}
              style={{ textDecoration: 'none' }}
              activeStyle={{
                fontWeight: 'bold',
                color: '#e11931',
              }}
            >
              <div className={styles['button-container']}>
                <img
                  src={IconBeranda}
                  alt="icon-beranda"
                  className={styles['icon-beranda']}
                />
                <br />
                <p>Beranda</p>
              </div>
            </NavLink>
            <NavLink
              to="/create-application"
              className={styles['nav-button-container']}
              style={{ textDecoration: 'none' }}
              activeStyle={{
                fontWeight: 'bold',
                color: '#e11931',
              }}
            >
              <div className={styles['button-container']}>
                <img
                  src={IconKontrak}
                  alt="icon-kontrak"
                  className={styles['icon-kontrak']}
                />
                <br />
                <p>Kontrak Baru</p>
              </div>
            </NavLink>
            <NavLink
              exact
              to="/profile"
              className={styles['nav-button-container']}
              style={{ textDecoration: 'none' }}
              activeStyle={{
                fontWeight: 'bold',
                color: '#e11931',
              }}
            >
              <div className={styles['button-container']}>
                <img
                  src={IconProfil}
                  alt="icon-profil"
                  className={styles['icon-profil']}
                />
                <br />
                <p>Profil</p>
              </div>
            </NavLink>
          </div>
        )}
      </React.Fragment>
    );
  }
}

export default MobileNavbar;
