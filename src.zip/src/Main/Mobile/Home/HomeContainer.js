import React, { Component } from 'react';
import styles from './HomeContainer.module.css';
import { AuthContext } from '../../AuthContext';
import MobileFooter from '../Common/FooterComponent';

class MobileHome extends Component {
  static contextType = AuthContext;

  render() {
    return (
      <React.Fragment>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>Beranda</div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Tes Beranda</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Some Text</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>Sub TItle Sub Title</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <MobileFooter />
      </React.Fragment>
    );
  }
}

export default MobileHome;
