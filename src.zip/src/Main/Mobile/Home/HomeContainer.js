import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { AuthContext } from '../../AuthContext';

class MobileHome extends Component {
  static contextType = AuthContext;

  render() {
    const { logout } = this.context;

    const divStyle = {
      margin: '40px',
      border: '5px solid pink',
      textAlign: 'center',
    };

    const testStyle = {
      marginBottom: '20px',
    };

    return (
      <React.Fragment>
        <div style={divStyle}>
          <h1>Home Mobile</h1>
          <button style={testStyle} type="submit" onClick={logout}>
            Keluar
          </button>
        </div>
        <NavLink
          to="/create-application/step-one"
          exact
          activeClassName="active"
        >
          <div style={divStyle}>Create Application</div>
        </NavLink>
      </React.Fragment>
    );
  }
}

export default MobileHome;
