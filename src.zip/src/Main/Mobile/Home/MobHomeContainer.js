import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';

class MobHome extends Component {
  render() {
    const divStyle = {
      margin: '40px',
      border: '5px solid pink',
      textAlign: 'center',
    };

    return (
      <React.Fragment>
        <div style={divStyle}>
          <h1>Home Mobile</h1>
        </div>
        <NavLink to="/create-application" exact activeClassName="active">
          <div style={divStyle}>Create Application</div>
        </NavLink>
      </React.Fragment>
    );
  }
}

export default MobHome;
