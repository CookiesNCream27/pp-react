import React, { useState } from 'react';
import Button from '@material-ui/core/Button';
import CircularProgress from '@material-ui/core/CircularProgress';
import { Redirect } from 'react-router-dom';
import styles from './Error404Container.module.css';

const ErrorNotFound = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [redirect, setRedirect] = useState(false);

  const handle = () => {
    setIsLoading(true);
    setTimeout(() => {
      setRedirect(true);
    }, 1000);
  };

  const WhatToDisplay = () => {
    if (isLoading) {
      return <CircularProgress />;
    }
    return (
      <Button color="primary" variant="contained" onClick={handle}>
        Back To Home
      </Button>
    );
  };

  if (redirect) {
    return <Redirect to="/home" />;
  }

  return (
    <div className={styles['white-wash']}>
      <h1>Error 404 Not Found</h1>
      <div className={styles.wrapper}>
        <WhatToDisplay />
      </div>
    </div>
  );
};

export default ErrorNotFound;
