import React, { Component } from 'react';

class ErrorNotFound extends Component {
  render() {
    return <h1>Error 404</h1>;
  }
}

export default ErrorNotFound;
