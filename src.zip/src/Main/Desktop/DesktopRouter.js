import React, { Suspense } from 'react';
import { BrowserRouter as Router, Switch, Redirect } from 'react-router-dom';
import Header from './Common/Header/HeaderComponent';
import Footer from './Common/Footer/FooterComponent';
import LoadingContainer from './Loading/LoadingContainer';
import ProtectedRoutes from '../../Utils/ProtectedRoutes';
import DefaultRoute from '../../Utils/DefaultRoute';

const Root = () => (
  <Redirect
    to={{
      pathname: '/home',
    }}
  />
);

const Home = React.lazy(() => import('./Home/HomeContainer'));
const Login = React.lazy(() => import('./Login/LoginContainer'));
const Error404Container = React.lazy(() => import('./Error/Error404Container'));

const AppRouterDesktop = () => (
  <Router basename="/partnerportal">
    <Suspense fallback={<LoadingContainer />}>
      <Header />
      <div id="application-page-wrapper">
        <Switch>
          <ProtectedRoutes
            exact
            path="/"
            component={props => <Root {...props} />}
          />
          <ProtectedRoutes
            exact
            path="/home"
            component={props => <Home {...props} />}
          />
          <DefaultRoute
            exact
            path="/login"
            defaultRoute="true"
            component={props => <Login {...props} />}
          />
          <ProtectedRoutes
            component={props => <Error404Container {...props} />}
          />
        </Switch>
      </div>
      <Footer />
    </Suspense>
  </Router>
);

export default AppRouterDesktop;
