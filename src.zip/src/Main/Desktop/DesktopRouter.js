import React, { Suspense } from 'react';
import { BrowserRouter as Router, Switch, Redirect } from 'react-router-dom';
import Header from './Common/Header/HeaderComponent';
import Footer from './Common/Footer/FooterComponent';
import LoadingContainer from './Loading/LoadingContainer';
import ProtectedRoutes from '../../Utils/ProtectedRoutes';
import DefaultRoute from '../../Utils/DefaultRoute';

const Root = () => (
  <Redirect
    to={{
      pathname: '/home',
    }}
  />
);

const Home = React.lazy(() => import('./Home/HomeContainer'));
const Login = React.lazy(() => import('./Login/LoginContainer'));
const Error404Container = React.lazy(() => import('./Error/Error404Container'));

const AppRouterDesktop = () => (
  <Router basename="/partnerportalm">
    <Suspense fallback={<LoadingContainer />}>
      <Header />
      <div id="application-page-wrapper">
        <Switch>
          <ProtectedRoutes
            exact
            path="/"
            component={props => <Root {...props} />}
            metaTitle="Main"
          />
          <ProtectedRoutes
            exact
            path="/home"
            component={props => <Home {...props} />}
            metaTitle="Home"
          />
          <DefaultRoute
            exact
            path="/login"
            defaultRoute="true"
            component={props => <Login {...props} />}
            metaTitle="Login"
          />
          <ProtectedRoutes
            component={props => <Error404Container {...props} />}
            metaTitle="Error"
          />
        </Switch>
      </div>
      <Footer />
    </Suspense>
  </Router>
);

export default AppRouterDesktop;
