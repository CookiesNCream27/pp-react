import React, { Component } from 'react';
import styles from './FooterComponent.module.css';
import IconMail from '../../../../assets/images/mail_black.png';
import IconCall from '../../../../assets/images/call_footer.png';
import LogoOJK from '../../../../assets/images/Logo_OJK.png';
import IconFacebook from '../../../../assets/images/facebook.png';
import IconInstagram from '../../../../assets/images/instagram.png';
import IconTwitter from '../../../../assets/images/twitter.png';
import IconLinkedIn from '../../../../assets/images/linkdin.png';
import IconYoutube from '../../../../assets/images/youtube.png';

class Footer extends Component {
  render() {
    return (
      <div className={styles['footer-container']}>
        <div className={styles['footer-left-container']}>
          <div className={styles['footer-left-item']}>
            <img
              src={IconMail}
              alt="IconMail"
              className={styles['icon-mail']}
            />
            <a href="mailto:partner.helpline@homecredit.co.id">
              <small>partner.helpline@homecredit.co.id</small>
            </a>
            <span className={styles['icon-separator']}>|</span>
            <br />
            <img
              src={IconCall}
              className={styles['icon-phone']}
              alt="icon-phone"
            />
            <a href="tel:+622180625533">
              <small>(021) 8062-5533</small>
            </a>
          </div>
          <div className={styles['footer-left-item']}>
            <a
              href="https://www.facebook.com/homecreditid/"
              className={styles['socmed-icon-facebook']}
            >
              <img src={IconFacebook} alt="icon-facebook" />
            </a>
            <a
              href="https://www.instagram.com/homecreditid/"
              className={styles['socmed-icon-instagram']}
            >
              <img src={IconInstagram} alt="icon-instagram" />
            </a>
            <a
              href="https://twitter.com/homecreditid_"
              className={styles['socmed-icon-twitter']}
            >
              <img src={IconTwitter} alt="icon-twitter" />
            </a>
            <a
              href="https://www.linkedin.com/company/homecreditindonesia"
              className={styles['socmed-icon-linkedin']}
            >
              <img src={IconLinkedIn} alt="icon-linkedin" />
            </a>
            <a
              href="https://www.youtube.com/channel/UCbFe7opCDSZ3sKLV42MtCfA"
              className={styles['socmed-icon-youtube']}
            >
              <img src={IconYoutube} alt="icon-youtube" />
            </a>
          </div>
        </div>
        <div className={styles['footer-right-container']}>
          <div className={styles['footer-right-item']}>
            <img
              src={LogoOJK}
              alt="logo-ojk"
              className={styles['footer-right-icon']}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default Footer;
