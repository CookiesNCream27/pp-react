import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../../../AuthContext';
import styles from './HeaderComponent.module.css';
import Logo from '../../../../assets/images/hcid_logo.png';

class Header extends Component {
  static contextType = AuthContext;

  render() {
    const { isAuth, logout } = this.context;
    return (
      <div className={styles['header-container']}>
        <div className={styles['header-item-left']}>
          <Link to="/" className={styles['logo-wrapper']}>
            <img src={Logo} alt="Logo Home Credit" />
          </Link>
        </div>
        <div className={styles['header-item-right']}>
          <React.Fragment>
            {isAuth && (
              <button type="submit" onClick={logout}>
                Keluar
              </button>
            )}
          </React.Fragment>
        </div>
      </div>
    );
  }
}

export default Header;
