import React, { Component } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { AuthContext } from '../../../AuthContext';
import styles from './HeaderComponent.module.css';
import Logo from '../../../../assets/images/hcid_logo.png';

class Header extends Component {
  static contextType = AuthContext;

  render() {
    const { isAuth, logout } = this.context;
    return (
      <div className={styles['header-container']}>
        <div className={styles['header-item-left']}>
          <Link to="/" className={styles['logo-wrapper']}>
            <img src={Logo} alt="Logo Home Credit" />
          </Link>
        </div>
        <div className={styles['header-item-right']}>
          <React.Fragment>
            {isAuth && (
              <ul className={styles['navigation-container']}>
                <li className={styles['nav-menu']}>
                  <NavLink to="/" exact activeClassName="active">
                    Beranda
                  </NavLink>
                </li>
                <li className={styles['nav-menu']}>
                  <button type="submit" onClick={logout}>
                    Keluar
                  </button>
                </li>
              </ul>
            )}
          </React.Fragment>
        </div>
      </div>
    );
  }
}

export default Header;
