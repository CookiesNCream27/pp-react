const config = {
  environment: 'development',
  endpoint: {
    main: 'https://dev.homecredit.co.id/partner-zone',
    survey: 'https://dev.homecredit.co.id/partner-portal-survey',
  },
  piwik: { id: '12', url: 'https://webanalytic-test.homecredit.co.id' },
};

export default config;
