import axios from 'axios';
import { AuthHeader } from './SharedFunctions';
import appConfig from '../config/application';

const endpointUrl = (endpoint, url) => {
  switch (endpoint) {
    case 'MAIN':
      return appConfig.endpoint.main + url;
    case 'SURVEY':
      return appConfig.endpoint.survey + url;
    default:
      return appConfig.endpoint.main + url;
  }
};

export const PostAxios = async (endpoint, url, payload, cancelToken) => {
  const config = {
    headers: {
      ...AuthHeader(),
      'Content-Type': 'application/json',
    },
    cancelToken,
  };

  if (!payload) {
    payload = {};
  }

  const combinedUrl = endpointUrl(endpoint, url);

  try {
    const object = await axios.post(combinedUrl, payload, config);
    return object;
  } catch (error) {
    return Promise.reject(error);
  }
};

export const GetAxios = async (endpoint, url, cancelToken, arrayBuffer) => {
  let config;
  if (arrayBuffer) {
    config = {
      headers: {
        ...AuthHeader(),
        'Content-Type': 'application/json',
      },
      cancelToken,
      responseType: 'arraybuffer',
    };
  } else {
    config = {
      headers: {
        ...AuthHeader(),
        'Content-Type': 'application/json',
      },
      cancelToken,
    };
  }

  const combinedUrl = endpointUrl(endpoint, url);

  try {
    const data = await axios.get(combinedUrl, config);
    return data;
  } catch (error) {
    if (error.response.data.code === 'ERR_TOKEN_EXPIRED') {
      console.log(error.response);
    }
    throw error;
  }
};
