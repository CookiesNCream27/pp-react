import axios from 'axios';
import { AuthHeader } from './SharedFunctions';

export const PostAxios = async (url, payload, cancelToken) => {
  console.log('tes2');
  const config = {
    headers: {
      ...AuthHeader(),
      'Content-Type': 'application/json',
    },
    cancelToken,
  };

  if (!payload) {
    payload = {};
  }

  try {
    const object = await axios.post(url, payload, config);
    console.log(object);
    return object;
  } catch (error) {
    return Promise.reject(error);
  }
};

export const GetAxios = async (url, cancelToken) => {
  const config = {
    headers: {
      ...AuthHeader(),
      'Content-Type': 'application/json',
    },
    cancelToken,
  };

  try {
    const data = await axios.get(url, config);
    return data;
  } catch (error) {
    throw error;
  }
};
