import axios from 'axios';
import appConfig from '../config/application';
import { PostAxios } from './Services';

export const AuthHeader = () => {
  const partnerPortalLoginObject = localStorage.getItem(
    'partnerPortalLoginObject',
  );
  const parsedpartnerPortalLoginObject = JSON.parse(partnerPortalLoginObject);
  if (partnerPortalLoginObject) {
    return { Authorization: `Bearer ${parsedpartnerPortalLoginObject.auth}` };
  }
  return '';
};

export const DevTools = callback => {
  if (appConfig.environment === 'development') {
    callback();
  }
};

export const JavaLogger = async (activity, id, signal) => {
  try {
    const payload = {
      activityId: activity,
      startApplicationId: id,
    };
    await PostAxios('MAIN', '/logger/insert-activity', payload, signal.token);
  } catch (error) {
    if (axios.isCancel(error)) {
      DevTools(() => console.log('Error: ', error.message));
    }
  }
};
