export const AuthHeader = () => {
  // let loginObject = localStorage.getItem('loginObject');
  // console.log(loginObject);
  // if (loginObject) {
  //   loginObject = JSON.parse(loginObject);
  // }
  // if (loginObject) {
  //   return { Authorization: `Bearer ${loginObject.data}` };
  // }
  // return {};
  const token = `eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiI2OTc3ODlDNDM1MDM2NkVDRTA1MzE0MTUzODBBNTFEOCIsImV4cCI6MTU0NTgxODAzMn0.f7t6poayVlkIKTUWTZ9w0gXkehnIsvquK8V-fUvFnQSHJUCj1mz0c-9KUQ00JyXnUizN0iXbyHhnP7KR90ul8g`;
  return { Authorization: `Bearer ${token}` };
};

export const Logger = callback => {
  if (process.env.NODE_ENV === 'development') {
    callback();
  }
};
