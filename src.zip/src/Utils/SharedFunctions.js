export const AuthHeader = () => {
  const loginObject = localStorage.getItem('loginObject');
  const parsedLoginObject = JSON.parse(loginObject);
  if (loginObject) {
    return { Authorization: `Bearer ${parsedLoginObject.auth}` };
  }
  return '';
};

export const Logger = callback => {
  if (process.env.NODE_ENV === 'development') {
    callback();
  }
};
