import axios from 'axios';
import appConfig from '../config/application';
import { PostAxios } from './Services';

export const AuthHeader = () => {
  const loginObject = localStorage.getItem('loginObject');
  const parsedLoginObject = JSON.parse(loginObject);
  if (loginObject) {
    return { Authorization: `Bearer ${parsedLoginObject.auth}` };
  }
  return '';
};

export const DevTools = callback => {
  if (appConfig.environment === 'development') {
    callback();
  }
};

export const JavaLogger = async (activity, id, signal) => {
  try {
    const payload = {
      activityId: activity,
      startApplicationId: id,
    };
    await PostAxios('MAIN', '/logger/insert-activity', payload, signal.token);
  } catch (error) {
    if (axios.isCancel(error)) {
      DevTools(() => console.log('Error: ', error.message));
    }
  }
};
