import React from 'react';
import PropTypes from 'prop-types';

export default function MockComponent(props) {
  const { name } = props;
  return <h1>Hello, {name}!</h1>;
}

MockComponent.propTypes = {
  name: PropTypes.string,
};

MockComponent.defaultProps = {
  name: 'Aosop',
};
