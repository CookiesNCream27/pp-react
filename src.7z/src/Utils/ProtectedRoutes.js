import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import { AuthConsumer } from '../Main/AuthContext';

const ProtectedRoutes = ({ component: Component, ...rest }) => (
  <AuthConsumer>
    {({ isAuth }) => {
      if (isAuth) {
        return <Route {...rest} render={props => <Component {...props} />} />;
      }
      return (
        <Redirect
          to={{
            pathname: '/login',
          }}
        />
      );
    }}
  </AuthConsumer>
);

export default ProtectedRoutes;
