import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';

class MobileLogin extends Component {
  render() {
    const divStyle = {
      margin: '40px',
      border: '5px solid pink',
      textAlign: 'center',
    };

    return (
      <React.Fragment>
        <div style={divStyle}>
          <h1>Login Mobile</h1>
        </div>
        <NavLink to="/home" exact activeClassName="active">
          <div style={divStyle}>Home</div>
        </NavLink>
      </React.Fragment>
    );
  }
}

export default MobileLogin;
