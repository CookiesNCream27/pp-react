import React from 'react';
import PropTypes from 'prop-types';

const CreateApplicationContext = React.createContext();

const createApplicationObject = {
  stepOne: [],
  stepTwo: [],
  stepThree: [],
  stepFour: [],
  stepFive: [],
  stepSix: [],
};

class CreateApplicationProvider extends React.Component {
  state = { value: createApplicationObject };

  constructor() {
    super();
    this.pushValue = this.pushValue.bind(this);
    this.removeValue = this.removeValue.bind(this);
  }

  pushValue(data) {
    console.log(data);
    this.setState({ value: data });
  }

  removeValue(data) {
    console.log(data);
    this.setState({ value: data });
  }

  render() {
    const { value } = this.state;
    const { children } = this.props;
    console.log(value);
    return (
      <CreateApplicationContext.Provider
        value={{
          value,
          pushValue: this.pushValue,
          removeValue: this.removeValue,
        }}
      >
        {children}
      </CreateApplicationContext.Provider>
    );
  }
}

CreateApplicationProvider.propTypes = {
  children: PropTypes.element.isRequired,
};

const CreateApplicationConsumer = CreateApplicationContext.Consumer;

export {
  CreateApplicationProvider,
  CreateApplicationConsumer,
  CreateApplicationContext,
};
