import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import Dialog from '@material-ui/core/Dialog';
import { Logger } from '../../../../Utils/SharedFunctions';
import styles from './StepThreeContainer.module.css';
import InsuranceComponent from './Component/InsuranceComponent';
import OfferComponent from './Component/OfferComponent';
import Information from '../../../../assets/images/information.svg';
import MobileFooter from '../../Common/FooterComponent';

const insuranceData = [
  {
    id: 1,
    product: 'AMAN',
  },
  {
    id: 2,
    product: 'proCLASSIC',
  },
  {
    id: 3,
    product: 'proPREMIUM',
  },
];

const offerData = [
  {
    id: 1,
    product: 'Erafon Direct Gift',
    value: 'Rp 13.000.000,-',
    downPayment: 'Rp 4.801.000,-',
    tenor: '18 bulan',
    installment: 'Rp 787.600',
    interest: '3.990%',
    isChosen: true,
  },
  {
    id: 2,
    product: 'Erafon Direct Gift',
    value: 'Rp 13.000.000,-',
    downPayment: 'Rp 4.801.000,-',
    tenor: '15 bulan',
    installment: 'Rp 878.800',
    interest: '3.990%',
    isChosen: false,
  },
  {
    id: 3,
    product: 'Erafon Direct Gift',
    value: 'Rp 13.000.000,-',
    downPayment: 'Rp 4.801.000,-',
    tenor: '12 bulan',
    installment: 'Rp 1.015.400',
    interest: '3.990%',
    isChosen: false,
  },
];

class StepOne extends Component {
  constructor(props) {
    super(props);
    this.state = {
      insuranceData: [
        {
          id: 1,
          product: 'AMAN',
        },
        {
          id: 2,
          product: 'proCLASSIC',
        },
        {
          id: 3,
          product: 'proPREMIUM',
        },
      ],
      offerData: [
        {
          id: 1,
          product: 'Erafon Direct Gift',
          value: 'Rp 13.000.000,-',
          downPayment: 'Rp 4.801.000,-',
          tenor: '18 bulan',
          installment: 'Rp 787.600',
          interest: '3.990%',
          isChosen: true,
        },
        {
          id: 2,
          product: 'Erafon Direct Gift',
          value: 'Rp 13.000.000,-',
          downPayment: 'Rp 4.801.000,-',
          tenor: '15 bulan',
          installment: 'Rp 878.800',
          interest: '3.990%',
          isChosen: false,
        },
        {
          id: 3,
          product: 'Erafon Direct Gift',
          value: 'Rp 13.000.000,-',
          downPayment: 'Rp 4.801.000,-',
          tenor: '12 bulan',
          installment: 'Rp 1.015.400',
          interest: '3.990%',
          isChosen: false,
        },
      ],
      popupShown: false,
      popupInfo: '',
      isValid: false,
      isBack: false,
    };
  }

  chooseProduct = id => {
    const { offerData } = this.state;
    const index = offerData.findIndex(x => x.id === id);
    offerData[index].isChosen = true;
  };

  handlePopupClose = () => {
    this.setState({
      popupShown: false,
    });
  };

  handleBack = () => {
    this.setState({
      isBack: true,
    });
  };

  render() {
    const { popupShown, popupInfo, isValid, isBack } = this.state;

    if (isBack) return <Redirect to="/create-application/step-two" />;

    Logger(() => console.log(popupShown, popupInfo, isValid, offerData));
    return (
      <div>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>
                    Data Pengajuan <br />& Kontrak
                  </div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Langkah 3</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Penawaran Kami</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>Berikut Penawaran Kami untuk Pembiayaan Anda</p>
                </div>
                <div className={styles['textfield-container']}>
                  <div className={styles['title-description']}>
                    <div>
                      <p>Perlindungan Tambahan</p>
                      <img src={Information} alt="Information" />
                    </div>
                  </div>
                  {insuranceData.map((props, data) => {
                    return <InsuranceComponent key={data.id} {...props} />;
                  })}
                </div>
                <div className={styles['step-detail-container']}>
                  <p>
                    Berikut Merupakan Hasil Kalkulasi untuk Penawaran Terbaik
                    dari Kami
                  </p>
                </div>
                {offerData.map((props, data) => {
                  return <OfferComponent key={data.id} {...props} />;
                })}
                <div
                  className={styles['submit-button-container']}
                  onClick={Logger(() => console.log('continue button pressed'))}
                  onKeyPress={Logger(() =>
                    console.log('continue button pressed'),
                  )}
                  role="button"
                  tabIndex="0"
                >
                  <p>Lanjut</p>
                </div>
                <div
                  className={styles['back-button-container']}
                  onClick={this.handleBack}
                  onKeyPress={this.handleBack}
                  role="button"
                  tabIndex="0"
                >
                  <p>Kembali</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <MobileFooter />
        <Dialog open={popupShown} onClose={this.handlePopupClose} fullWidth>
          <div className={styles['popup-container']}>
            <div className={styles['popup-description-wrapper']}>
              <div className={styles['popup-title']}>
                <h2>Perlindungan Tambahan</h2>
              </div>
              <div className={styles['popup-info-wrapper']}>
                <div className={styles['popup-title']}>AMAN</div>
                <div className={styles['popup-description']}>
                  menjamin pembayaran cicilan Anda bila Anda atau pasangan
                  mengalami kejadian tidak terduga (sakit atau kecelakaan)
                </div>
              </div>
              <div className={styles['popup-info-wrapper']}>
                <div className={styles['popup-title']}>proCLASSIC</div>
                <div className={styles['popup-description']}>
                  melindungi perangkat Anda (HP, Gadget atau Laptop) dari risiko
                  akibat kerusakan yang tidak terduga
                </div>
              </div>
              <div className={styles['popup-info-wrapper']}>
                <div className={styles['popup-title']}>proPREMIUM</div>
                <div className={styles['popup-description']}>
                  melindungi perangkat Anda (HP, Gadget atau Laptop) dari risiko
                  akibat kerusakan yang tidak disengaja dan kehilangan perangkat
                  akibat pencurian/perampokan.
                </div>
              </div>
              <div
                className={styles['popup-button']}
                onClick={this.handlePopupClose}
                onKeyPress={this.handlePopupClose}
                role="button"
                tabIndex="0"
              >
                <p>Tutup</p>
              </div>
            </div>
          </div>
        </Dialog>
      </div>
    );
  }
}

export default StepOne;
