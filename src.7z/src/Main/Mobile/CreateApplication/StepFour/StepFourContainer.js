import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import styles from './StepFourContainer.module.css';
import MobileFooter from '../../Common/FooterComponent';
import CheckedBig from '../../../../assets/images/checked_big.svg';
import Money from '../../../../assets/images/money.svg';

class StepOne extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isValid: false,
      isBack: false,
    };
  }

  render() {
    const { isValid, isBack } = this.state;

    if (isValid) return <Redirect to="/create-application/step-five" />;

    if (isBack) return <Redirect to="/create-application/step-three" />;

    return (
      <div>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>
                    Data Pengajuan <br />& Kontrak
                  </div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Langkah 4</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Rangkuman Pengajuan</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>Pastikan Informasi Transaksi Anda Sudah Benar</p>
                </div>
                <div className={styles['summary-outer-container']}>
                  <div className={styles['summary-inner-container']}>
                    <div className={styles['summary-checked-container']}>
                      <img src={CheckedBig} alt="CheckedBig" />
                    </div>
                    <div className={styles['summary-detail-container']}>
                      <div className={styles['summary-title']}>Nokia 3310</div>
                      <div className={styles['summary-subtitle']}>
                        Detail Pembiayaan
                      </div>
                    </div>
                  </div>
                  <div className={styles['summary-second-container']}>
                    <div className={styles['option-detail']}>
                      <div className={styles['option-detail-wrapper-first']}>
                        <div className={styles['option-detail-title']}>
                          Model Barang
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>Handphone</p>
                        </div>
                      </div>
                      <div className={styles['option-detail-wrapper-first']}>
                        <div className={styles['option-detail-title']}>
                          Harga Barang
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>Rp 13.000.000,-</p>
                        </div>
                      </div>
                    </div>
                    <div className={styles['option-detail']}>
                      <div className={styles['option-detail-wrapper-second']}>
                        <div className={styles['option-detail-title']}>
                          Tenor
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>18 Bulan</p>
                        </div>
                      </div>
                      <div className={styles['option-detail-wrapper-second']}>
                        <div className={styles['option-detail-title']}>
                          Cicilan per Bulan
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>Rp 787.600,-</p>
                        </div>
                      </div>
                      <div className={styles['option-detail-wrapper-second']}>
                        <div className={styles['option-detail-title']}>
                          Suku Bunga
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>3.990%</p>
                        </div>
                      </div>
                    </div>
                    <div className={styles['option-detail']}>
                      <div className={styles['option-detail-wrapper']}>
                        <div className={styles['option-detail-title']}>
                          Perlindungan Tambahan
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>Rp 360.000</p>
                        </div>
                      </div>
                    </div>
                    <div className={styles['option-payment']}>
                      <div className={styles['option-payment-title']}>
                        Total Pembayaran Tunai
                      </div>
                      <div className={styles['option-payment-detail']}>
                        <div className={styles['option-payment-logo']}>
                          <img src={Money} alt="Money" />
                        </div>
                        <div className={styles['option-payment-description']}>
                          <p className={styles['option-payment-value']}>
                            Rp 4.801.000,-
                          </p>
                          <p className={styles['option-payment-subtitle']}>
                            (Uang Muka + Biaya Admin)
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  className={styles['submit-button-container']}
                  onClick={this.nikLengthValidation}
                  onKeyPress={this.nikLengthValidation}
                  role="button"
                  tabIndex="0"
                >
                  <p>Lanjut</p>
                  <div
                    className={styles['back-button-container']}
                    onClick={this.handleBack}
                    onKeyPress={this.handleBack}
                    role="button"
                    tabIndex="0"
                  >
                    <p>Kembali</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <MobileFooter />
      </div>
    );
  }
}

export default StepOne;
