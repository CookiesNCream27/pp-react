import React, { Suspense } from 'react';
import { BrowserRouter as Router, Switch, Redirect } from 'react-router-dom';
import MobileNavbar from './Common/NavbarComponent';
import MobileLoadingContainer from './Loading/LoadingContainer';
import ProtectedRoutes from '../../Utils/ProtectedRoutes';
import DefaultRoute from '../../Utils/DefaultRoute';

const Root = () => (
  <Redirect
    to={{
      pathname: '/home',
    }}
  />
);

const MobileHome = React.lazy(() => import('./Home/HomeContainer'));
const MobileLogin = React.lazy(() => import('./Login/LoginContainer'));
const MobileError = React.lazy(() => import('./Error/Error404Container'));
const MobileCreateApplication = React.lazy(() =>
  import('./CreateApplication/CreateApplicationContainer'),
);

const AppRouterMobile = () => (
  <Router basename="/partnerportal">
    <Suspense fallback={<MobileLoadingContainer />}>
      <Switch>
        <ProtectedRoutes
          exact
          path="/"
          component={props => <Root {...props} />}
        />
        <ProtectedRoutes
          exact
          path="/home"
          component={props => <MobileHome {...props} />}
        />
        <ProtectedRoutes
          exact
          path="/create-application/:createApplicationStep"
          component={props => <MobileCreateApplication {...props} />}
        />
        <DefaultRoute
          exact
          path="/login"
          defaultRoute="true"
          component={props => <MobileLogin {...props} />}
        />
        <ProtectedRoutes
          exact
          path="/create-application/:createApplicationStep"
          component={props => <MobileCreateApplication {...props} />}
        />
        <ProtectedRoutes component={props => <MobileError {...props} />} />
      </Switch>
      <MobileNavbar />
    </Suspense>
  </Router>
);

export default AppRouterMobile;
