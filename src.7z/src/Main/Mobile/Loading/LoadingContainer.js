import React, { Component } from 'react';

class MobileLoading extends Component {
  render() {
    const divStyle = {
      margin: '40px',
      border: '5px solid pink',
      textAlign: 'center',
    };

    return (
      <React.Fragment>
        <div style={divStyle}>
          <h1>Loading Mobile</h1>
        </div>
      </React.Fragment>
    );
  }
}

export default MobileLoading;
