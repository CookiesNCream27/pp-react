import React, { Component } from 'react';
import styles from './NavbarComponent.module.css';
import IconBeranda from '../../../assets/images/icon-beranda.png';
import IconKontrak from '../../../assets/images/icon-kontrak.png';
import IconProfil from '../../../assets/images/icon-profil.png';

class MobileNavbar extends Component {
  render() {
    return (
      <React.Fragment>
        <div className={styles['navbar-container']}>
          <div className={styles['button-container']}>
            <img
              src={IconBeranda}
              alt="icon-beranda"
              className={styles['icon-beranda']}
            />
            <br />
            <p>Beranda</p>
          </div>
          <div className={styles['button-container']}>
            <img
              src={IconKontrak}
              alt="icon-kontrak"
              className={styles['icon-kontrak']}
            />
            <br />
            <p className={styles['active-menu']}>Kontrak Baru</p>
          </div>
          <div className={styles['button-container']}>
            <img
              src={IconProfil}
              alt="icon-profil"
              className={styles['icon-profil']}
            />
            <br />
            <p>Profil</p>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default MobileNavbar;
