import React, { Component } from 'react';

class StepTwo extends Component {
  render() {
    return <h1>Step 2</h1>;
  }
}

export default StepTwo;
