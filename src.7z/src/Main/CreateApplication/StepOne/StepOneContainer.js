import React, { Component } from 'react';

class StepOne extends Component {
  render() {
    return <h1>Step One</h1>;
  }
}

export default StepOne;
