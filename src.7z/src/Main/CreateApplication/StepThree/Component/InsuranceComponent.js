import React from 'react';
import styles from './InsuranceComponent.module.css';

const InsuranceComponent = props => (
  <div className={styles['insurance-options']}>
    <label className={styles['container']}>
      {props.product}
      <input type="checkbox" />
      <span className={styles['checkmark']} />
    </label>
  </div>
);

export default InsuranceComponent;
