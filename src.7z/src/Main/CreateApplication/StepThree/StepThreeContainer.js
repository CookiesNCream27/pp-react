import React, { Component } from 'react';

class StepThree extends Component {
  render() {
    return <h1>Step 3</h1>;
  }
}

export default StepThree;
