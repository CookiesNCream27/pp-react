import React, { Component, Suspense } from 'react';
import ProtectedRoutes from '../../Utils/ProtectedRoutes';
import LoadingContainer from '../Loading/LoadingContainer';

const StepOne = React.lazy(() => import('./StepOne/StepOneContainer'));
const StepTwo = React.lazy(() => import('./StepTwo/StepTwoContainer'));
const StepThree = React.lazy(() => import('./StepThree/StepThreeContainer'));

class CreateApplication extends Component {
  render() {
    return (
      <React.Fragment>
        <Suspense fallback={<LoadingContainer />}>
          <ProtectedRoutes
            exact
            path="/create-application/step-one"
            component={props => <StepOne {...props} />}
          />
          <ProtectedRoutes
            exact
            path="/create-application/step-two"
            component={props => <StepTwo {...props} />}
          />
          <ProtectedRoutes
            exact
            path="/create-application/step-three"
            component={props => <StepThree {...props} />}
          />
        </Suspense>
      </React.Fragment>
    );
  }
}

export default CreateApplication;
