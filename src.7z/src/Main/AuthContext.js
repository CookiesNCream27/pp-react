import React from 'react';
import PropTypes from 'prop-types';

let loginObject = localStorage.getItem('loginObject');

if (loginObject) {
  loginObject = JSON.parse(loginObject);
}

const AuthContext = React.createContext();

class AuthProvider extends React.Component {
  state = { isAuth: !!loginObject };

  constructor() {
    super();
    this.login = this.login.bind(this);
    this.logout = this.logout.bind(this);
  }

  login(data) {
    if (data.auth !== null) {
      this.setState({ isAuth: true });
      localStorage.setItem('loginObject', JSON.stringify(data));
    }
  }

  logout() {
    localStorage.removeItem('loginObject');
    this.setState({ isAuth: false });
  }

  render() {
    const { isAuth } = this.state;
    const { children } = this.props;

    return (
      <AuthContext.Provider
        value={{ isAuth, login: this.login, logout: this.logout }}
      >
        {children}
      </AuthContext.Provider>
    );
  }
}

AuthProvider.propTypes = {
  children: PropTypes.element.isRequired,
};

const AuthConsumer = AuthContext.Consumer;

export { AuthProvider, AuthConsumer, AuthContext };
