import React, { Suspense } from 'react';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import blue from '@material-ui/core/colors/blue';
import LoadingContainer from './Loading/LoadingContainer';
import { AuthProvider } from './AuthContext';
import DesktopRouter from './DesktopRouter';
import MobileRouter from './Mobile/MobileRouter';

import './App.css';

const theme = createMuiTheme({
  palette: {
    primary: {
      main: '#e11931',
    },
    secondary: blue,
  },
  typography: {
    useNextVariants: true,
    fontSize: 16,
    fontWeightMedium: 700,
  },
});

const AppRouter = () => {
  if (window.innerWidth < 481) {
    return <MobileRouter />;
  }
  return <DesktopRouter />;
};

const App = () => (
  <AuthProvider>
    <MuiThemeProvider theme={theme}>
      <Suspense fallback={<LoadingContainer />}>
        <AppRouter />
      </Suspense>
    </MuiThemeProvider>
  </AuthProvider>
);

export default App;
