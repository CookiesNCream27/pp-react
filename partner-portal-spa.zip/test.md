---
Aspire assesment
---

Individual Goals

- Per team goals
- Yourself goals

---

Training
what do you need

---

Front End Dev Assesment.

0.  Feel free to use any frameworks or tools you would like to achieve the task. :)
1.  Choose one from these API.
    https://swapi.co/ - Star Wars API
    https://pokeapi.co/ - Pokemon API
    https://ghibliapi.herokuapp.com/ - Ghibli API
1.  Create Multipage Single Page Web Application (SPA) with clear UX and detailed views.
1.  Consume data from one of this API and serve all data using infinity scroll for main pages.
1.  Put your code into public repository (i.e. GItlab, Github, etc).
1.  Make readme.md and put it into your repository and explain why you choose these frameworks or tools to achieve the task.
1.  [Bonus] Create simple unit test of your webApp.
1.  [Bonus] Develop custom function and implement it to your webApp.

---=================================== Critical Question and Listening ===========================================================================---
Kamis, 15 November 2018

---
