const fs = require('fs');
const js = require('./package.json');

const someFile = './src/index.js';
fs.readFile(someFile, 'utf8', (err, data) => {
  if (err) {
    return console.log(err);
  }

  const firstvariable = 'ver';
  const secondvariable = '_ver';

  const filterStuff = data.match(
    new RegExp(`${firstvariable}(.*)${secondvariable}`),
  );

  const result = data.replace(
    filterStuff[1],
    ` */ console.info('ver-${js.version}'); /* `,
  );

  fs.writeFile(someFile, result, 'utf8', errWrite => {
    if (errWrite) return console.log(err);
    return console.log(`Partner Portal ${js.version}`);
  });

  return console.log('Version Updated!');
});
