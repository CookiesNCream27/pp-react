const fs = require('fs');
const js = require('./package.json');

const someFile = './src/index.js';
fs.readFile(someFile, 'utf8', (err, data) => {
  if (err) {
    return console.log(err);
  }
  const result = data.replace(/applicationVersion/g, js.version);

  fs.writeFile(someFile, result, 'utf8', errWrite => {
    if (errWrite) return console.log(err);
    return console.log(`Partner Portal${js.version}`);
  });

  return console.log('Version Updated!');
});
