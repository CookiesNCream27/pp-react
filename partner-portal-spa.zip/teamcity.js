const fs = require('fs');
const js = require('./package.json');

fs.writeFile(`./public/ver.${js.version}.teamcity`, js.version, err => {
  if (err) {
    return console.log(err);
  }

  return console.log('Application');
});
