const config = {
  environment: 'staging',
  endpoint: {
    url: 'https://sandbox.homecredit.co.id',
    main: 'https://sandbox.homecredit.co.id/partner-zone',
    survey: 'https://sandbox.homecredit.co.id/partner-portal-survey',
  },
  piwik: { id: '12', url: 'https://webanalytic-test.homecredit.co.id' },
};

export default config;
