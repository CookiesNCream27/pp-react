const config = {
  environment: 'production',
  endpoint: {
    url: 'https://oasys.homecredit.co.id',
    main: 'https://oasys.homecredit.co.id/partner-zone',
    survey: 'https://oasys.homecredit.co.id/partner-portal-survey',
  },
  piwik: { id: '9', url: 'https://webanalytics.homecredit.co.id' },
};

export default config;
