const config = window.PARTNER_PORTAL;
export default config;
