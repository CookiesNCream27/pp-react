let loginObject = localStorage.getItem('loginObject');

if (loginObject) {
  loginObject = JSON.parse(loginObject);
} else {
  loginObject = null;
}

const currentRole = loginObject.object.partnerRole.roleId;

export const roleEnum = {
  poloAdmin: 'ALDI_TNT_ADMIN',
  poloUser: 'ALDI_TNT_USER',
  poloAdminNoFP: 'ALDI_TNT_ADMIN',
  poloUserNoFP: 'ALDI_TNT_USER',
};

const resolvePrivileges = {
  canAccessNoFP: () => {
    if (
      currentRole === roleEnum.poloAdminNoFP ||
      currentRole === roleEnum.poloUserNoFP
    ) {
      return true;
    }
    return false;
  },
  canView: () => {
    if (
      currentRole === roleEnum.poloAdmin ||
      currentRole === roleEnum.poloUser
    ) {
      return true;
    }
    return false;
  },
};

export default resolvePrivileges;
