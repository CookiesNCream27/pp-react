let partnerPortalLoginObject = localStorage.getItem('partnerPortalLoginObject');

if (partnerPortalLoginObject) {
  partnerPortalLoginObject = JSON.parse(partnerPortalLoginObject);
} else {
  partnerPortalLoginObject = null;
}

let currentRole;

if (partnerPortalLoginObject !== null) {
  currentRole = partnerPortalLoginObject.object.partnerRole.roleId;
} else {
  currentRole = null;
}

const roleEnum = {
  poloAdmin: 'ALDI_TNT_ADMIN',
  poloUser: 'ALDI_TNT_USER',
  poloAdminNoFP: 'ALDI_TNT_ADMIN_FP',
  poloUserNoFP: 'ALDI_TNT_USER_FP',
  offlinePartnerUser: 'OFFLINE_PARTNER_USER',
  offlinePartnerUserInvoice: 'OFFLINE_PARTNER_USER_INVOICE',
  offlinePartnerAdmin: 'OFFLINE_PARTNER_ADMIN',
  offlinePartnerAdminInvoice: 'OFFLINE_PARTNER_ADMIN_INVOICE',
  onlinePartnerAdmin: 'ONLINE_PARTNER_ADMIN',
  onlinePartnerUser: 'ONLINE_PARTNER_USER',
  bdAdmin: 'BD_ADMIN',
  superAdmin: 'SUPER_ADMIN',
  financeAdmin: 'FINANCE_ADMIN',
  financeAdminInvoice: 'FINANCE_ADMIN_INVOICE',
  afSecurity: 'AF_SECURITY',
  salesHelpdeskAdmin: 'SALES_HELPDESK_ADMIN',
  dsmAdmin: 'DSM_ADMIN',
  // new role
  salesAgent: 'SALES_AGENT',
};

const resolvePrivileges = {
  isAuth: () => {
    if (partnerPortalLoginObject === null) {
      return false;
    }
    return true;
  },
  canAccessNoFP: () => {
    if (
      currentRole === roleEnum.poloAdminNoFP ||
      currentRole === roleEnum.poloUserNoFP
    ) {
      return true;
    }
    return false;
  },
  canView: () => {
    if (
      currentRole === roleEnum.poloAdmin ||
      currentRole === roleEnum.poloUser
    ) {
      return true;
    }
    return false;
  },
  showImeiValidationPopup: () => {
    if (
      currentRole === roleEnum.offlinePartnerUser ||
      currentRole === roleEnum.offlinePartnerUserInvoice
    ) {
      return true;
    }
    return false;
  },
  hideDeliveryAdviceButton: () => {
    if (
      currentRole === roleEnum.bdAdmin ||
      currentRole === roleEnum.dsmAdmin ||
      currentRole === roleEnum.onlinePartnerAdmin ||
      currentRole === roleEnum.onlinePartnerAdminInvoice ||
      currentRole === roleEnum.salesHelpdeskAdmin
    ) {
      return true;
    }
    return false;
  },
  disableDeliveryAdviceButton: () => {
    if (
      currentRole === roleEnum.financeAdmin ||
      currentRole === roleEnum.financeAdminInvoice ||
      currentRole === roleEnum.offlinePartnerAdmin ||
      currentRole === roleEnum.offlinePartnerAdminInvoice
    ) {
      return true;
    }
    return false;
  },
  showImeiFillingPopup: () => {
    if (
      currentRole === roleEnum.poloAdmin ||
      currentRole === roleEnum.poloAdminNoFP ||
      currentRole === roleEnum.poloUser ||
      currentRole === roleEnum.poloUserNoFP
    ) {
      return true;
    }
    return false;
  },
  showInvoiceNumber: () => {
    if (
      currentRole === roleEnum.offlinePartnerAdminInvoice ||
      currentRole === roleEnum.offlinePartnerUserInvoice ||
      currentRole === roleEnum.financeAdminInvoice
    ) {
      return true;
    }
    return false;
  },
  showInvoiceFillingPopup: () => {
    if (currentRole === roleEnum.offlinePartnerUserInvoice) {
      return true;
    }
    return false;
  },
  hideNavigationBar: () => {
    if (currentRole === roleEnum.salesAgent) {
      return true;
    }
    return false;
  },
  skipQRCode: () => {
    if (currentRole === roleEnum.salesAgent) {
      return true;
    }
    return false;
  },
};

export const routeBlocker = path => {
  if (currentRole === roleEnum.salesAgent) {
    if (
      path === '/' ||
      path === '/home' ||
      path === '/portfolio' ||
      path === '/contract-dashboard' ||
      path === '/contract-search' ||
      path === '//delivery-advice/:contractNumber' ||
      path === '/faq' ||
      path === '/profile' ||
      path === '/user-management'
    ) {
      return true;
    }
  }
  return false;
};

export default resolvePrivileges;
