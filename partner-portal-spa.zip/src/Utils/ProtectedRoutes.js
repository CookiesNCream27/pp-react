import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import PropTypes from 'prop-types';
import { AuthConsumer } from '../Main/AuthContext';
import { routeBlocker } from './UserPrivileges';

const ProtectedRoutes = ({ component: Component, ...rest }) => (
  <AuthConsumer>
    {({ isAuth }) => {
      document.title = `${
        rest.metaTitle
      }  -  Partner Portal | PT. Home Credit Indonesia`;
      if (isAuth) {
        if (routeBlocker(rest.path)) {
          return (
            <Redirect
              to={{
                pathname: '/create-application',
              }}
            />
          );
        }
        return <Route {...rest} render={props => <Component {...props} />} />;
      }
      return (
        <Redirect
          to={{
            pathname: '/login',
          }}
        />
      );
    }}
  </AuthConsumer>
);

export default ProtectedRoutes;

ProtectedRoutes.propTypes = {
  component: PropTypes.func.isRequired,
};
