import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import PropTypes from 'prop-types';
import { AuthConsumer } from '../Main/AuthContext';

const DefaultRoute = ({ component: Component, ...rest }) => (
  <AuthConsumer>
    {({ isAuth }) => {
      document.title = `${
        rest.metaTitle
      } - Partner Portal | PT. Home Credit Indonesia`;
      if (!isAuth) {
        return <Route {...rest} render={props => <Component {...props} />} />;
      }
      return (
        <Redirect
          to={{
            pathname: '/',
          }}
        />
      );
    }}
  </AuthConsumer>
);

export default DefaultRoute;

DefaultRoute.propTypes = {
  component: PropTypes.func.isRequired,
};
