import React from 'react';
import ReactDOM from 'react-dom';
import App from './Main/App';

ReactDOM.render(<App />, document.getElementById('partner-portal-root'));

/* ver */ console.info('ver-0.0.4'); /* _ver */

console.log(
  '%c ------ 🔥 Partner Portal  🔥 ------',
  'color: #fff; font-weight:300; font-size: 21px; background-color: #e11931; padding: 20px; width: 1000px',
);
