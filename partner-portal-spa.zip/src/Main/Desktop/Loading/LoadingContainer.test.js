import React from 'react';
import ReactDOM from 'react-dom';
import LoadingContainer from './LoadingContainer';

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<LoadingContainer />, div);
  ReactDOM.unmountComponentAtNode(div);
});
