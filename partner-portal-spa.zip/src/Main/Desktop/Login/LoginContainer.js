import React, { Component } from 'react';
import axios from 'axios';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import Grid from '@material-ui/core/Grid';
import { AuthContext } from '../../AuthContext';
import { PostAxios } from '../../../Utils/Services';
import { DevTools } from '../../../Utils/SharedFunctions';
import styles from './LoginContainer.module.css';
import LoginFailed from '../../../assets/images/login_failed.png';
import LoginWelcome from '../../../assets/images/login_welcome.png';

class Login extends Component {
  static contextType = AuthContext;

  signal = axios.CancelToken.source();

  state = {
    username: '',
    password: '',
    disabled: true,
    popupshown: false,
  };

  componentWillUnmount() {
    this.signal.cancel('Login Api has been canceled');
  }

  submitLogin = (payload, login) => async e => {
    e.preventDefault();
    try {
      const { data } = await PostAxios(
        'MAIN',
        '/user-management/login',
        payload,
        this.signal.token,
      );
      await login(data);
      if (data.auth === null) {
        this.setState({
          popupshown: true,
        });
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
  };

  handleChange = str => event => {
    this.setState(
      {
        [str]: event.target.value,
      },
      () => this.checkValidInput(),
    );
  };

  checkValidInput = () => {
    const { username, password } = this.state;
    if (username && password) {
      this.setState({ disabled: false });
    } else {
      this.setState({ disabled: true });
    }
  };

  handleClose = () => {
    this.setState({
      popupshown: false,
    });
  };

  render() {
    const { username, password } = this.state;
    const { disabled, popupshown } = this.state;
    const { login } = this.context;

    return (
      <div className={styles['login-container']}>
        <div className={styles['login-left-item']}>
          <img src={LoginWelcome} alt="Login Welcome" />
        </div>
        <br />
        <div className={styles['login-right-item']}>
          <div className={styles['login-box']}>
            <form
              autoComplete="off"
              onSubmit={this.submitLogin({ username, password }, login)}
            >
              <div>
                <TextField
                  inputProps={{ 'data-cy': 'login-username-input' }}
                  InputLabelProps={{ shrink: true }}
                  className="login-field"
                  label="Email atau Nomor Telepon"
                  type="text"
                  onChange={this.handleChange('username')}
                  placeholder="Isi Email atau Nomor Telepon"
                  margin="normal"
                  variant="outlined"
                  value={username}
                  autoComplete="username"
                />
              </div>
              <div>
                <TextField
                  inputProps={{ 'data-cy': 'login-password-input' }}
                  InputLabelProps={{ shrink: true }}
                  className="login-field"
                  label="Kata Sandi"
                  type="password"
                  autoComplete="current-password"
                  onChange={this.handleChange('password')}
                  placeholder="Isi Kata Sandi"
                  margin="normal"
                  variant="outlined"
                  value={password}
                />
              </div>
              <div>
                <Button
                  data-cy="login-submit-button"
                  disabled={disabled}
                  color="primary"
                  variant="contained"
                  type="submit"
                >
                  Masuk
                </Button>
              </div>
            </form>
          </div>
          <Dialog open={popupshown} onClose={this.handleClose}>
            <div className={styles['popup-container']}>
              <Grid
                container
                direction="column"
                justify="center"
                alignItems="center"
              >
                <Grid item md={8}>
                  <img src={LoginFailed} alt="Login Failed" />
                </Grid>
                <Grid item md={8}>
                  <h2 className={styles['popup-title']}>LOGIN GAGAL</h2>
                </Grid>
                <Grid item md={8}>
                  <p className={styles['popup-description']}>
                    Email/telepon atau password yang anda masukkan salah
                  </p>
                </Grid>
                <Grid item md={8}>
                  <Button
                    className={styles['popup-button']}
                    onClick={this.handleClose}
                  >
                    Coba Lagi
                  </Button>
                </Grid>
              </Grid>
            </div>
          </Dialog>
        </div>
      </div>
    );
  }
}

export default Login;
