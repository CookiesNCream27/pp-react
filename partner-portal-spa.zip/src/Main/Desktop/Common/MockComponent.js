import React from 'react';
import PropTypes from 'prop-types';

export default function MockComponent(props) {
  const { name } = props;
  return <h4>Hello from JavaScript, {name}</h4>;
}

MockComponent.propTypes = {
  name: PropTypes.string,
};

MockComponent.defaultProps = {
  name: 'Aosop',
};
