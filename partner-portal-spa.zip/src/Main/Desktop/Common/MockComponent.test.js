import React from 'react';
import TestRenderer from 'react-test-renderer';
import MockComponent from './MockComponent';

it('functional component renders correctly', () => {
  const props = {
    name: 'Hairy Potter X',
  };
  const tree = TestRenderer.create(<MockComponent props={props} />).toJSON();
  expect(tree).toMatchSnapshot();
});
