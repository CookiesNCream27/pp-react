import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import styles from './HomeContainer.module.css';
import MockComponent from '../Common/MockComponent';

class Home extends Component {
  constructor() {
    super();
    this.state = { firstName: 'Harry', lastName: 'Potter' };
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(e) {
    const { lastName } = this.state;
    e.preventDefault();
    if (lastName === 'Potter') {
      this.setState({ firstName: 'Harry', lastName: 'Plopper' });
    } else {
      this.setState({ firstName: 'Hairy', lastName: 'Potter' });
    }
  }

  render() {
    const { firstName, lastName } = this.state;
    const combinedName = `${firstName} ${lastName}`;

    return (
      <div className={styles['App-header']}>
        <div>
          <MockComponent name={combinedName} />
        </div>
        <Button color="primary" variant="contained" onClick={this.handleClick}>
          Switch
        </Button>
      </div>
    );
  }
}

export default Home;
