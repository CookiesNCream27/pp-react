import React from 'react';
import Button from '@material-ui/core/Button';
import appConfig from '../../../config/application';
import styles from './HomeContainer.module.css';

const redirect = () => {
  window.location.href = `${appConfig.endpoint.url}/partnerportal`;
};

const Home = () => {
  return (
    <div className={styles.apps}>
      <div className={styles.wordWrap}>
        <p>
          Mohon maaf, aplikasi ini sedang dalam tahap pengembangan. Silahkan
          klik tautan dibawah untuk melanjutkan ke versi desktop.
        </p>
      </div>
      <Button color="primary" variant="contained" onClick={redirect}>
        Alihkan
      </Button>
    </div>
  );
};

export default Home;
