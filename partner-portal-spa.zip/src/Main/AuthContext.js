import React from 'react';
import PropTypes from 'prop-types';

let partnerPortalLoginObject = localStorage.getItem('partnerPortalLoginObject');

if (partnerPortalLoginObject) {
  partnerPortalLoginObject = JSON.parse(partnerPortalLoginObject);
}

const AuthContext = React.createContext();

class AuthProvider extends React.Component {
  state = { isAuth: !!partnerPortalLoginObject };

  constructor() {
    super();
    this.login = this.login.bind(this);
    this.logout = this.logout.bind(this);
  }

  login(data) {
    if (data.auth !== null) {
      this.setState({ isAuth: true });
      localStorage.setItem('partnerPortalLoginObject', JSON.stringify(data));
    }
  }

  logout() {
    localStorage.removeItem('partnerPortalLoginObject');
    this.setState({ isAuth: false });
    window.location.reload();
  }

  render() {
    const { isAuth } = this.state;
    const { children } = this.props;

    return (
      <AuthContext.Provider
        value={{ isAuth, login: this.login, logout: this.logout }}
      >
        {children}
      </AuthContext.Provider>
    );
  }
}

AuthProvider.propTypes = {
  children: PropTypes.element.isRequired,
};

const AuthConsumer = AuthContext.Consumer;

export { AuthProvider, AuthConsumer, AuthContext };
