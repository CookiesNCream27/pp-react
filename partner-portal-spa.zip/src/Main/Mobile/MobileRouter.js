import React, { Suspense } from 'react';
import { BrowserRouter as Router, Switch, Redirect } from 'react-router-dom';
import MobileNavbar from './Common/NavbarComponent';
import MobileFooter from './Common/FooterComponent';
import ProtectedRoutes from '../../Utils/ProtectedRoutes';
import DefaultRoute from '../../Utils/DefaultRoute';
import LogoHCID from '../../assets/images/white-hcid.png';

const Root = () => (
  <Redirect
    to={{
      pathname: '/home',
    }}
  />
);

const MobileLoadingContainer = () => {
  const loaderCustom = {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: '10vh',
  };
  return (
    <div style={loaderCustom}>
      <img src={LogoHCID} alt="" />
    </div>
  );
};

const MobileHome = React.lazy(() => import('./Home/HomeContainer'));
const MobileLogin = React.lazy(() => import('./Login/LoginContainer'));
const MobileProfile = React.lazy(() => import('./Profile/ProfileContainer'));
const MobileError = React.lazy(() => import('./Error/Error404Container'));
const MobileCreateApplication = React.lazy(() =>
  import('./CreateApplication/CreateApplicationContainer'),
);
const MobileContractDashboard = React.lazy(() =>
  import('./Contract/ContractDashboard/ContractDashboardContainer'),
);
const MobileContractSearch = React.lazy(() =>
  import('./Contract/ContractSearch/ContractSearchContainer'),
);
const MobileContractDeliveryAdvice = React.lazy(() =>
  import('./Contract/DeliveryAdvice/DeliveryAdviceContainer'),
);

const AppRouterMobile = () => (
  <Router basename="/partnerportalm">
    <Suspense fallback={<MobileLoadingContainer open />}>
      <Switch>
        <ProtectedRoutes
          exact
          path="/"
          component={props => <Root {...props} />}
          metaTitle="Main"
        />
        <ProtectedRoutes
          exact
          path="/home"
          component={props => <MobileHome {...props} />}
          metaTitle="Home"
        />
        <ProtectedRoutes
          exact
          path="/contract-dashboard"
          component={props => <MobileContractDashboard {...props} />}
          metaTitle="Contract Dashboard"
        />
        <ProtectedRoutes
          exact
          path="/contract-search"
          component={props => <MobileContractSearch {...props} />}
          metaTitle="Contract Search"
        />
        <ProtectedRoutes
          exact
          path="/create-application"
          component={props => <MobileCreateApplication {...props} />}
          metaTitle="Create Application"
        />
        <ProtectedRoutes
          exact
          path="/create-application/:createApplicationStep"
          component={props => <MobileCreateApplication {...props} />}
          metaTitle="Create Application"
        />
        <ProtectedRoutes
          exact
          path="/delivery-advice/:contractNumber"
          component={props => <MobileContractDeliveryAdvice {...props} />}
          metaTitle="Delivery Advice"
        />
        <ProtectedRoutes
          exact
          path="/profile"
          component={props => <MobileProfile {...props} />}
          metaTitle="Profile"
        />
        <DefaultRoute
          exact
          path="/login"
          defaultRoute="true"
          component={props => <MobileLogin {...props} />}
          metaTitle="Login"
        />
        <ProtectedRoutes
          component={props => <MobileError {...props} metaTitle="Error" />}
        />
      </Switch>
      <MobileNavbar />
      <MobileFooter />
      {/* <TokenExpiredDialog render={this.context.isUserExpired}/> */}
    </Suspense>
  </Router>
);

export default AppRouterMobile;
