import React, { Component } from 'react';
import Dialog from '@material-ui/core/Dialog';
import PropTypes from 'prop-types';
import styles from './LoadingContainer.module.css';
import homeCreditLoader from '../../../assets/gif/loading.gif';

class MobileLoading extends Component {
  render() {
    const { open } = this.props;
    const loaderShown = open;
    const loaderClose = () => {};
    return (
      <Dialog
        disableBackdropClick
        disableEscapeKeyDown
        open={loaderShown}
        onClose={loaderClose}
      >
        <div className={styles['loading-container']}>
          <div className={styles['loading-content']}>
            <img
              className={styles['loading-gif']}
              src={homeCreditLoader}
              alt="Home Credit Loader"
            />
          </div>
        </div>
      </Dialog>
    );
  }
}

MobileLoading.propTypes = {
  open: PropTypes.bool,
};

MobileLoading.defaultProps = {
  open: false,
};

export default MobileLoading;
