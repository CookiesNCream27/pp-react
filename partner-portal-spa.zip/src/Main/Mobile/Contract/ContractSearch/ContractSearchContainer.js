import React, { Component } from 'react';
import styles from './ContractSearchContainer.module.css';
import DetailLetter from '../../../../assets/images/detail_letter.svg';

class ContractSearch extends Component {
  render() {
    return (
      <React.Fragment>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>Pencarian Kontrak</div>
                </div>
                <div className={styles['textfield-container']}>
                  <div className={styles['title-wrapper']}>
                    <div className={styles['contract-number']}>3800015537</div>
                    <div className={styles['contract-status']}>AKTIF</div>
                  </div>
                  <div className={styles['contract-detail']}>
                    <div className={styles['contract-detail-wrapper']}>
                      <div className={styles['contract-detail-top']}>
                        <div className={styles['contract-description']}>
                          Tanggal Buat
                        </div>
                        <div className={styles['contract-value']}>
                          21 Nov 2018
                        </div>
                      </div>
                      <div className={styles['contract-detail-bottom']}>
                        <div className={styles['contract-description']}>
                          Harga Barang
                        </div>
                        <div className={styles['contract-value']}>
                          Rp 6.000.000
                        </div>
                      </div>
                    </div>
                    <div className={styles['contract-detail-wrapper']}>
                      <div className={styles['contract-detail-top']}>
                        <div className={styles['contract-description']}>
                          Nama Pelanggan
                        </div>
                        <div className={styles['contract-value']}>
                          Via Vallen
                        </div>
                      </div>
                      <div className={styles['contract-detail-bottom']}>
                        <div className={styles['contract-description']}>
                          DP + Admin
                        </div>
                        <div className={styles['contract-value']}>
                          Rp 2.500.000
                        </div>
                      </div>
                    </div>
                    <div className={styles['contract-detail-wrapper']}>
                      <div className={styles['contract-detail-top']}>
                        <div className={styles['contract-description']}>
                          Nama Barang
                        </div>
                        <div className={styles['contract-value']}>
                          HP14 bs 01...
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={styles['contract-imei']}>
                  <div className={styles['imei-description']}>IMEI/SN</div>
                  <div className={styles['imei-value']}>520489527079798</div>
                  <div className={styles['imei-detail']}>
                    <img src={DetailLetter} alt="Detail" width="75%" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default ContractSearch;
