import React, { Component } from 'react';
import axios from 'axios';
import NumberFormat from 'react-number-format';
// import { Redirect } from 'react-router-dom';
// import { JavaLogger } from '../../../../Utils/SharedFunctions';
import styles from './DeliveryAdviceContainer.module.css';
import CheckedBig from '../../../../assets/images/checked_big.svg';

class StepFour extends Component {
  signal = axios.CancelToken.source();

  constructor(props) {
    super(props);
    this.state = {
      isValid: false,
      isBack: false,
    };
  }

  componentDidMount() {
    // const { value } = this.context;
    // const applicationId = value.stepOne.startApplicationId;
    // JavaLogger('PARTNER_START_APPLICATION_STEP3', applicationId, this.signal);
  }

  handleContinue = () => {
    this.setState({
      isValid: true,
      isBack: false,
    });
  };

  handleBack = () => {
    this.setState({ isValid: false, isBack: true });
  };

  render() {
    // const { isValid, isBack } = this.state;

    // const { value } = this.context;

    // if (
    //   Object.keys(value.stepOne).length === 0 &&
    //   value.stepOne.constructor === Object
    // )
    //   return <Redirect to="/create-application/step-one" />;

    // if (isValid) return <Redirect to="/create-application/step-five" />;

    // if (isBack) return <Redirect to="/create-application/step-three" />;

    return (
      <div>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>Instruksi Penyerahan</div>
                </div>
                <div className={styles['summary-outer-container']}>
                  <div className={styles['summary-inner-container']}>
                    <div className={styles['summary-checked-container']}>
                      <img src={CheckedBig} alt="CheckedBig" />
                    </div>
                    <div className={styles['summary-detail-container']}>
                      <div className={styles['option-detail-left']}>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Pelanggan
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>Salim Utama</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Kontrak
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>3900001228</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Tanggal Pembuatan Kontrak
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>30 Jan 2019</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Tanda Tangan Kontrak
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>30 Jan 2019</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Status Kontrak
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>Aktif</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Nomor Faktur
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>-</p>
                          </div>
                        </div>
                      </div>
                      <div className={styles['option-detail-right']}>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Mitra
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>HCI_Partner_TEST</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Tipe Mitra
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>Stand</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Nama Toko
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>JFS_SALESROOMt</p>
                          </div>
                        </div>
                        {/* <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Harga Barang
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>
                              Rp{' '}
                              <NumberFormat
                                value={1000000}
                                thousandSeparator
                                displayType="text"
                              />
                              ,-
                            </p>
                          </div>
                        </div> */}
                      </div>
                    </div>
                    <div className={styles['summary-detail-bottom-container']}>
                      <div className={styles['option-detail-left']}>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Pembayaran
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>
                              Jumlah Total Pembayaran Tunai (termasuk Biaya
                              Administrasi Rp. 0,-) yang harus ditagih dari
                              pelanggan
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles['summary-second-container']}>
                    <div className={styles['summary-detail-container']}>
                      <div className={styles['option-detail-left']}>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Model
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>-</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Pabrikan
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>HP14-bs012TX GOLD</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            IMEI
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>520489527079798</p>
                          </div>
                        </div>
                      </div>
                      <div className={styles['option-detail-right']}>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Jumlah
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>1</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className={styles['summary-detail-bottom-container']}>
                      <div className={styles['option-detail-left']}>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Harga
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>
                              Rp{' '}
                              <NumberFormat
                                value={1000000}
                                thousandSeparator
                                displayType="text"
                              />
                              ,-
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={styles['summary-total-container']}>
                  <div className={styles['option-payment']}>
                    <div className={styles['option-payment-title']}>
                      Oleh: HCID_POS_Test... 21/01/2019
                    </div>
                    <div className={styles['option-payment-detail']}>
                      <div className={styles['option-payment-logo']}>
                        <img src={CheckedBig} alt="Money" width="40%" />
                      </div>
                      <div className={styles['option-payment-description']}>
                        <p className={styles['option-payment-value']}>
                          Terkonfirmasi Pembayaran DP
                        </p>
                      </div>
                    </div>
                  </div>
                  <br />
                  <div className={styles['option-payment']}>
                    <div className={styles['option-payment-title']}>
                      Oleh: HCID_POS_Test... 21/01/2019
                    </div>
                    <div className={styles['option-payment-detail']}>
                      <div className={styles['option-payment-logo']}>
                        <img src={CheckedBig} alt="Money" width="40%" />
                      </div>
                      <div className={styles['option-payment-description']}>
                        <p className={styles['option-payment-value']}>
                          Terkonfirmasi Barang Diterima
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  className={styles['submit-button-container']}
                  onClick={this.handleContinue}
                  onKeyPress={this.handleContinue}
                  role="button"
                  tabIndex="0"
                >
                  <p>Unduh PDF</p>
                </div>
                <div
                  className={styles['back-button-container']}
                  onClick={this.handleBack}
                  onKeyPress={this.handleBack}
                  role="button"
                  tabIndex="0"
                >
                  <p>Kembali</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default StepFour;
