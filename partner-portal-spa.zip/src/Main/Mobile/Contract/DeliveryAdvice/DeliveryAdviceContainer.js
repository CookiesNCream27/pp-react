/* eslint-disable no-else-return */
import React, { Component } from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import Slider from 'react-slick';
import Dialog from '@material-ui/core/Dialog';
import TextField from '@material-ui/core/TextField';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
// import { Redirect } from 'react-router-dom';
import { DevTools } from '../../../../Utils/SharedFunctions';
import { GetAxios, PostAxios } from '../../../../Utils/Services';
import resolvePrivileges from '../../../../Utils/UserPrivileges';
import styles from './DeliveryAdviceContainer.module.css';
import LoadingContainer from '../../Loading/LoadingContainer';
import CheckedBig from '../../../../assets/images/checked_big.svg';
import KonfirmasiPembayaran from '../../../../assets/images/konfirmasi_pembayaran.png';
import HomeDelivery from '../../../../assets/images/home_delivery.png';

const sliderSettings = {
  dots: true,
  dotsClass: 'slick-dots',
  arrows: false,
  infinite: false,
};

const ImeiValidationPopup = props => {
  const data = props;
  return (
    <Dialog open={data.popupShown} onClose={data.onPopupClose} fullWidth>
      <div className={styles['popup-container-done']}>
        <div className={styles['popup-detail-value']}>
          <p>Mohon isi IMEI/Serial Number</p>
        </div>
        <div
          className={styles['submit-button-container']}
          onClick={data.onPopupClose}
          onKeyPress={data.onPopupClose}
          role="button"
          tabIndex="0"
        >
          <p>OK</p>
        </div>
      </div>
    </Dialog>
  );
};

const PaymentConfirmationPopup = props => {
  const data = props;
  return (
    <Dialog open={data.popupShown} onClose={data.onPopupClose} fullWidth>
      <div className={styles['popup-container']}>
        <div className={styles['popup-detail-value']}>
          <img src={KonfirmasiPembayaran} alt="Konfirmasi Pembayaran" />
        </div>
        <div className={styles['popup-detail-value']}>
          <h2 className={styles['popup-title']}>KONFIRMASI PEMBAYARAN</h2>
        </div>
        <div className={styles['popup-detail-value']}>
          <p className={styles['popup-description']}>
            Saya mengkonfirmasi DP telah dibayarkan sebesar {data.cashPayment}
            termasuk Biaya Administrasi sebesar {data.originationFee}
          </p>
          <p />
        </div>
        <div
          className={styles['submit-button-container']}
          onClick={data.confirmPayment}
          onKeyPress={data.confirmPayment}
          role="button"
          tabIndex="0"
        >
          <p>Lanjutkan</p>
        </div>
        <div
          className={styles['back-button-container']}
          onClick={data.onPopupClose}
          onKeyPress={data.onPopupClose}
          role="button"
          tabIndex="0"
        >
          <p>Batal</p>
        </div>
      </div>
    </Dialog>
  );
};

const PaymentDonePopup = props => {
  const data = props;
  return (
    <Dialog open={data.popupShown} onClose={data.onPopupClose} fullWidth>
      <div className={styles['popup-container-done']}>
        <div className={styles['popup-detail-value']}>
          <p>Konfirmasi DP Berhasil</p>
        </div>
        <div
          className={styles['submit-button-container']}
          onClick={data.onPopupClose}
          onKeyPress={data.onPopupClose}
          role="button"
          tabIndex="0"
        >
          <p>OK</p>
        </div>
      </div>
    </Dialog>
  );
};

const ImeiFillingConfirmationPopup = props => {
  const data = props;
  const theme = createMuiTheme({
    typography: {
      useNextVariants: true,
      htmlFontSize: 15,
    },
    overrides: {
      MuiInput: {
        underline: {
          '&:before,&:after': {
            borderBottom: '2px solid #f8f5f8',
          },
        },
        outlined: {
          '&$cssFocused $notchedOutline': {
            borderBottom: '#f8f5f8',
          },
        },
        label: {
          '&$cssFocused': {
            borderBottom: '#f8f5f8',
          },
        },
      },
    },
  });

  return (
    <Dialog open={data.popupShown} onClose={data.onPopupClose} fullWidth>
      <div className={styles['popup-container']}>
        <div className={styles['popup-detail-value']}>
          <p>Masukkan {data.fillingType}</p>
          <MuiThemeProvider theme={theme}>
            <TextField
              label={data.fillingType}
              fullWidth
              variant="outlined"
              error={data.invalidImei}
              helperText={data.invalidImei ? 'Invalid' : ''}
              onChange={data.changeImei}
              onKeyUp={data.changeImei}
            />
          </MuiThemeProvider>
        </div>
        <div
          className={
            data.invalidImei
              ? styles['submit-button-container-disabled']
              : styles['submit-button-container']
          }
          onClick={data.invalidImei ? () => {} : data.confirmImeiSn}
          onKeyPress={data.invalidImei ? () => {} : data.confirmImeiSn}
          role="button"
          tabIndex="0"
        >
          <p>Simpan</p>
        </div>
        <div
          className={styles['back-button-container']}
          onClick={data.onPopupClose}
          onKeyPress={data.onPopupClose}
          role="button"
          tabIndex="0"
        >
          <p>Batal</p>
        </div>
      </div>
    </Dialog>
  );
};

const InvoiceFillingConfirmationPopup = props => {
  const data = props;
  const theme = createMuiTheme({
    typography: {
      useNextVariants: true,
      htmlFontSize: 15,
    },
    overrides: {
      MuiInput: {
        underline: {
          '&:before,&:after': {
            borderBottom: '2px solid #f8f5f8',
          },
        },
        outlined: {
          '&$cssFocused $notchedOutline': {
            borderBottom: '#f8f5f8',
          },
        },
        label: {
          '&$cssFocused': {
            borderBottom: '#f8f5f8',
          },
        },
      },
    },
  });

  return (
    <Dialog open={data.popupShown} onClose={data.onPopupClose} fullWidth>
      <div className={styles['popup-container']}>
        <div className={styles['popup-detail-value']}>
          <p>Silahkan masukan Nomor Faktur pada form dibawah ini</p>
          <MuiThemeProvider theme={theme}>
            <TextField
              label="Nomor Faktur"
              fullWidth
              variant="outlined"
              error={data.invalidInvoice}
              helperText={data.invalidInvoice ? 'Invalid' : ''}
              onChange={data.changeInvoice}
              onKeyUp={data.changeInvoice}
            />
          </MuiThemeProvider>
        </div>
        <div
          className={
            data.invalidInvoice
              ? styles['submit-button-container-disabled']
              : styles['submit-button-container']
          }
          onClick={data.invalidInvoice ? () => {} : data.confirmInvoice}
          onKeyPress={data.invalidInvoice ? () => {} : data.confirmInvoice}
          role="button"
          tabIndex="0"
        >
          <p>OK</p>
        </div>
        <div
          className={styles['back-button-container']}
          onClick={data.onPopupClose}
          onKeyPress={data.onPopupClose}
          role="button"
          tabIndex="0"
        >
          <p>Kembali</p>
        </div>
      </div>
    </Dialog>
  );
};

const ImeiFillingDonePopup = props => {
  const data = props;
  return (
    <Dialog open={data.popupShown} onClose={data.onPopupClose} fullWidth>
      <div className={styles['popup-container-done']}>
        <div className={styles['popup-detail-value']}>
          <p>Konfirmasi {data.fillingType} Berhasil</p>
        </div>
        <div
          className={styles['submit-button-container']}
          onClick={data.onPopupClose}
          onKeyPress={data.onPopupClose}
          role="button"
          tabIndex="0"
        >
          <p>OK</p>
        </div>
      </div>
    </Dialog>
  );
};

const ImeiFillingFailPopup = props => {
  const data = props;
  return (
    <Dialog open={data.popupShown} onClose={data.onPopupClose} fullWidth>
      <div className={styles['popup-container-done']}>
        <div className={styles['popup-detail-value']}>
          <p>
            Nomor {data.fillingType} gagal terkirim.
            <br /> Untuk mengaktivasi kontrak, silakan hubungi Partner Helpline
            di (021) 8062-5533 atau email ke partner.helpline@homecredit.co.id
          </p>
        </div>
        <div
          className={styles['submit-button-container']}
          onClick={data.onPopupClose}
          onKeyPress={data.onPopupClose}
          role="button"
          tabIndex="0"
        >
          <p>OK</p>
        </div>
      </div>
    </Dialog>
  );
};

const InvoiceFillingDonePopup = props => {
  const data = props;
  return (
    <Dialog open={data.popupShown} onClose={data.onPopupClose} fullWidth>
      <div className={styles['popup-container-done']}>
        <div className={styles['popup-detail-value']}>
          <p>Berhasil menambahkan nomor faktur</p>
        </div>
        <div
          className={styles['submit-button-container']}
          onClick={data.onPopupClose}
          onKeyPress={data.onPopupClose}
          role="button"
          tabIndex="0"
        >
          <p>OK</p>
        </div>
      </div>
    </Dialog>
  );
};

const DeliveryConfirmationPopup = props => {
  const data = props;
  return (
    <Dialog open={data.popupShown} onClose={data.onPopupClose} fullWidth>
      <div className={styles['popup-container']}>
        <div className={styles['popup-detail-value']}>
          <img src={HomeDelivery} alt="Home Delivery" />
        </div>
        <div className={styles['popup-detail-value']}>
          <h2 className={styles['popup-title']}>BARANG SIAP DIKIRIMKAN</h2>
        </div>
        <div className={styles['popup-detail-value']}>
          <p className={styles['popup-description']}>
            Saya mengkonfirmasi pengiriman siap dilakukan pada tanggal{' '}
            {data.deliveryDate}
          </p>
          <p />
        </div>
        <div
          className={styles['submit-button-container']}
          onClick={data.confirmDelivery}
          onKeyPress={data.confirmDelivery}
          role="button"
          tabIndex="0"
        >
          <p>Lanjutkan</p>
        </div>
        <div
          className={styles['back-button-container']}
          onClick={data.onPopupClose}
          onKeyPress={data.onPopupClose}
          role="button"
          tabIndex="0"
        >
          <p>Batal</p>
        </div>
      </div>
    </Dialog>
  );
};

const DeliveryDonePopup = props => {
  const data = props;
  return (
    <Dialog open={data.popupShown} onClose={data.onPopupClose} fullWidth>
      <div className={styles['popup-container-done']}>
        <div className={styles['popup-detail-value']}>
          <p>Konfirmasi Siap Dikirim Berhasil</p>
        </div>
        <div
          className={styles['submit-button-container']}
          onClick={data.onPopupClose}
          onKeyPress={data.onPopupClose}
          role="button"
          tabIndex="0"
        >
          <p>OK</p>
        </div>
      </div>
    </Dialog>
  );
};

const DeliveredConfirmationPopup = props => {
  const data = props;
  return (
    <Dialog open={data.popupShown} onClose={data.onPopupClose} fullWidth>
      <div className={styles['popup-container']}>
        <div className={styles['popup-detail-value']}>
          <img src={HomeDelivery} alt="Home Delivery" />
        </div>
        <div className={styles['popup-detail-value']}>
          <h2 className={styles['popup-title']}>KONFIRMASI PENGIRIMAN</h2>
        </div>
        <div className={styles['popup-detail-value']}>
          <p>
            Saya mengkonfirmasi pengiriman komoditi melalui {data.deliveryType}{' '}
            pada tanggal {data.deliveryDate}
          </p>
          <p />
        </div>
        <div
          className={styles['submit-button-container']}
          onClick={data.confirmDelivered}
          onKeyPress={data.confirmDelivered}
          role="button"
          tabIndex="0"
        >
          <p>Lanjutkan</p>
        </div>
        <div
          className={styles['back-button-container']}
          onClick={data.onPopupClose}
          onKeyPress={data.onPopupClose}
          role="button"
          tabIndex="0"
        >
          <p>Batal</p>
        </div>
      </div>
    </Dialog>
  );
};

const DeliveredDonePopup = props => {
  const data = props;
  return (
    <Dialog open={data.popupShown} onClose={data.onPopupClose} fullWidth>
      <div className={styles['popup-container-done']}>
        <div className={styles['popup-detail-value']}>
          <p>Konfirmasi {data.deliveryTypeMessage} Berhasil</p>
        </div>
        <div
          className={styles['submit-button-container']}
          onClick={data.onPopupClose}
          onKeyPress={data.onPopupClose}
          role="button"
          tabIndex="0"
        >
          <p>OK</p>
        </div>
      </div>
    </Dialog>
  );
};

class DeliveryAdviceClass extends Component {
  signal = axios.CancelToken.source();

  constructor(props) {
    super(props);
    this.state = {
      buybackAmount: {},
      deliveryAdvice: {},
      customerData: {},
      partnerCommodity: [],
      partnerSalesroom: {},
      partner: {},
      deliveryType: '',
      commodityType: '',
      commodityId: '',
      imei: '0',
      invoice: '',
      isImeiInvalid: false,
      isInvoiceInvalid: false,
      isPaid: false,
      isReadyToDeliver: false,
      isDelivered: false,
      isPaidTime: false,
      isDeliveryTime: false,
      isImeiValidationPopupShown: false,
      isPaymentConfirmPopupShown: false,
      isPaymentDonePopupShown: false,
      isImeiFillingConfirmPopupShown: false,
      isImeiFillingDonePopupShown: false,
      isImeiFillingFailPopupShown: false,
      isInvoiceFillingConfirmPopupShown: false,
      isInvoiceFillingDonePopupShown: false,
      isReadyToDeliverConfirmPopupShown: false,
      isReadyToDeliverDonePopupShown: false,
      isDeliveredConfirmPopupShown: false,
      isDeliveredDonePopupShown: false,
      isLoading: false,
    };
  }

  componentDidMount() {
    this.getData();
  }

  getData = async () => {
    await this.getBuybackAmount();
    await this.getDeliveryAdvice();
    await this.getCustomerData();
    await this.checkImei();
    await this.checkStatus();
    await this.checkDeliveryType();
    await this.checkTimestamp();
  };

  getBuybackAmount = async () => {
    this.triggerLoading(true);
    try {
      const { match } = this.props;
      const { data } = await GetAxios(
        'MAIN',
        `/api/v1/buyback/get-buyback-amount/${match.params.contractNumber}`,
        this.signal.token,
      );
      if (data.code === '00') {
        await this.setState({
          buybackAmount: data,
        });
      }
    } catch (error) {
      DevTools(() => console.log('Error: ', error.message));
    }
    this.triggerLoading(false);
  };

  getDeliveryAdvice = async () => {
    this.triggerLoading(true);
    try {
      const { match } = this.props;
      const user = JSON.parse(localStorage.partnerPortalLoginObject).object;
      const payload = {
        contractNumber: match.params.contractNumber,
        partnerSalesroomId: user.partnerSalesroom.id,
        roleName: user.partnerRole.roleId,
      };
      const { data } = await PostAxios(
        'MAIN',
        '/user-management/get-delivery-advice-by-contractnumber',
        payload,
        this.signal.token,
      );
      if (data.code === '00') {
        await this.setState({
          deliveryAdvice: data.object,
        });
      }
    } catch (error) {
      DevTools(() => console.log('Error: ', error.message));
    }
    this.triggerLoading(false);
  };

  getCustomerData = async () => {
    this.triggerLoading(true);
    try {
      const { match } = this.props;
      const payload = {
        contractNumber: match.params.contractNumber,
        productCode: null,
      };
      const { data } = await PostAxios(
        'MAIN',
        '/user-management/get-contract-by-contract-number-by-partner-salesroom-id-by-role-name',
        payload,
        this.signal.token,
      );
      if (data.code === '00') {
        await this.setState({
          customerData: data.object,
          partnerCommodity: data.object.partnerCommodityResponses,
          partnerSalesroom: data.object.partnerSalesroom,
          partner: data.object.partnerSalesroom.partner,
        });
      }
    } catch (error) {
      DevTools(() => console.log('Error: ', error.message));
    }
    this.triggerLoading(false);
  };

  confirmPayment = async () => {
    this.triggerLoading(true);
    try {
      console.log('payment');
      const { match } = this.props;
      const user = JSON.parse(localStorage.partnerPortalLoginObject).object;
      const payload = {
        contractNumber: match.params.contractNumber,
        partnerSalesroomId: user.partnerSalesroom.id,
      };
      const { data } = await PostAxios(
        'MAIN',
        '/user-management/Confirm-The-DP',
        payload,
        this.signal.token,
      );
      if (data.code === '00') {
        await this.setState({
          isPaid: true,
        });
        await this.closePaymentConfirmPopup();
        await this.openPaymentDonePopup();
      }
    } catch (error) {
      DevTools(() => console.log('Error: ', error.message));
    }
    this.triggerLoading(false);
  };

  confirmDelivery = async () => {
    this.triggerLoading(true);
    try {
      console.log('delivery');
      const { match } = this.props;
      const user = JSON.parse(localStorage.partnerPortalLoginObject).object;
      const payload = {
        contractNumber: match.params.contractNumber,
        partnerSalesroomId: user.partnerSalesroom.id,
      };
      const { data } = await PostAxios(
        'MAIN',
        '/user-management/Confirm-Delivery',
        payload,
        this.signal.token,
      );
      if (data.code === '00') {
        await this.setState({
          isReadyToDeliver: true,
        });
        await this.closeReadyToDeliveryConfirmPopup();
        await this.openReadyToDeliveryDonePopup();
      }
    } catch (error) {
      DevTools(() => console.log('Error: ', error.message));
    }
    this.triggerLoading(false);
  };

  confirmDelivered = async () => {
    this.triggerLoading(true);
    try {
      const { match } = this.props;
      const user = JSON.parse(localStorage.partnerPortalLoginObject).object;
      const payload = {
        contractNumber: match.params.contractNumber,
        partnerSalesroomId: user.partnerSalesroom.id,
      };
      const { data } = await PostAxios(
        'MAIN',
        '/user-management/Confirm-Delivered',
        payload,
        this.signal.token,
      );
      if (data.code === '00') {
        await this.setState({
          isDelivered: true,
        });
        await this.closeDeliveredConfirmPopup();
        await this.openDeliveredDonePopup();
      }
    } catch (error) {
      DevTools(() => console.log('Error: ', error.message));
    }
    this.triggerLoading(false);
  };

  confirmImeiSerialNumber = async () => {
    this.triggerLoading(true);
    try {
      const { match } = this.props;
      const { commodityType, commodityId, imei } = this.state;
      let payload = {};
      if (commodityType === 'mobile') {
        payload = {
          commodityId,
          contractNumber: match.params.contractNumber,
          imei,
        };
      } else if (commodityType === 'laptop') {
        payload = {
          commodityId,
          contractNumber: match.params.contractNumber,
          serialNumber: imei,
        };
      }
      const { data } = await PostAxios(
        'MAIN',
        '/user-management/insert-serial-number',
        payload,
        this.signal.token,
      );
      if (data.code === '00') {
        await this.setState({
          isImeiInvalid: false,
        });
        await this.closeImeiFillingConfirmPopup(false);
        await this.openImeiFillingDonePopup();
        // } else if (data.code === 'ERR_INSERT_SERIAL_NUMBER_FAILED') {
      } else {
        await this.closeImeiFillingConfirmPopup(true);
        await this.openImeiFillingFailPopup();
      }
    } catch (error) {
      DevTools(() => console.log('Error: ', error.message));
    }
    this.triggerLoading(false);
  };

  confirmInvoice = async () => {
    this.triggerLoading(true);
    try {
      const { match } = this.props;
      const { invoice } = this.state;
      const user = JSON.parse(localStorage.partnerPortalLoginObject).object;
      const payload = {
        contractNumber: match.params.contractNumber,
        invoiceNumber: invoice,
        roleName: user.partnerRole.roleId,
      };
      const { data } = await PostAxios(
        'MAIN',
        '/user-management/insert-invoice-number',
        payload,
        this.signal.token,
      );
      if (data.code === '00') {
        await this.closeInvoiceFillingConfirmPopup(true);
        await this.openInvoiceFillingDonePopup();
      }
    } catch (error) {
      DevTools(() => console.log('Error: ', error.message));
    }
    this.triggerLoading(false);
  };

  checkImei = () => {
    this.triggerLoading(true);
    const { partnerCommodity } = this.state;
    const index = partnerCommodity.findIndex(
      x =>
        x.typeCode === 'CT_TE_MP' ||
        x.typeCode === 'CT_TE_SDB' ||
        x.typeCode === 'CT_TE_SPP' ||
        x.typeCode === 'CT_CT_LAP',
    );

    if (
      partnerCommodity[index].typeCode === 'CT_TE_MP' ||
      partnerCommodity[index].typeCode === 'CT_TE_SDB' ||
      partnerCommodity[index].typeCode === 'CT_TE_SPP'
    ) {
      this.setState({
        commodityType: 'mobile',
        commodityId: partnerCommodity[index].id,
      });
    } else if (partnerCommodity[index].typeCode === 'CT_CT_LAP') {
      this.setState({
        commodityType: 'laptop',
        commodityId: partnerCommodity[index].id,
      });
    }

    if (
      ((partnerCommodity[index].typeCode === 'CT_TE_MP' ||
        partnerCommodity[index].typeCode === 'CT_TE_SDB' ||
        partnerCommodity[index].typeCode === 'CT_TE_SPP') &&
        partnerCommodity[index].imei === null) ||
      (partnerCommodity[index].typeCode === 'CT_CT_LAP' &&
        partnerCommodity[index].serialNumber === null)
    ) {
      this.setState({
        isImeiInvalid: true,
      });
    }

    if (resolvePrivileges.showImeiValidationPopup()) {
      this.setState({
        isImeiValidationPopupShown: true,
      });
    }
    DevTools(() =>
      console.log('does not need imei/serial number popup validation'),
    );
    this.triggerLoading(false);
  };

  // eslint-disable-next-line consistent-return
  validateImei = event => {
    const { imei, commodityType } = this.state;
    const imeiValue = event.target.value;

    if (commodityType === 'mobile') {
      if (imeiValue && imeiValue !== '') {
        if (imeiValue.replace(' ', '') !== '') {
          this.setState({
            imei: imeiValue.trim(),
          });
        }
      }
    } else if (commodityType === 'laptop') {
      this.setState({
        imei: imeiValue,
        isImeiInvalid: false,
      });
    }

    if (imeiValue.length === 0) {
      this.setState({
        imei: '',
        isImeiInvalid: true,
      });
    }

    if (commodityType === 'mobile') {
      const ar = [];
      const nag = imei;
      const etal = /^[0-9]{15}$/;
      if (!etal.test(nag)) {
        this.setState({
          isImeiInvalid: true,
        });
      } else {
        const nagsplit = nag.split('');
        for (let i = 0; i < nagsplit.length; i += 1) {
          if (i % 2 === 0) {
            ar.push(Number(nagsplit[i]));
          } else {
            const doubled = Number(nagsplit[i]) * 2;
            if (String(doubled).length > 1) {
              const doubledsplit = String(doubled).split('');
              for (let j = 0; j < doubledsplit.length; j += 1) {
                ar.push(Number(doubledsplit[j]));
              }
            } else {
              ar.push(doubled);
            }
          }
        }
        let sum = 0;
        for (let k = 0; k < ar.length; k += 1) {
          sum += ar[k];
        }
        if (sum % 10 === 0) {
          this.setState({
            isImeiInvalid: false,
          });
        } else {
          this.setState({
            isImeiInvalid: true,
          });
        }
      }
    }
  };

  validateInvoice = event => {
    const invoiceValue = event.target.value;

    if (invoiceValue.length > 0) {
      this.setState({
        invoice: invoiceValue,
        isInvoiceInvalid: true,
      });
    } else {
      this.setState({
        invoice: '',
        isInvoiceInvalid: false,
      });
    }
  };

  showImei = id => {
    const { partnerCommodity } = this.state;
    const index = partnerCommodity.findIndex(x => x.id === id);

    if (partnerCommodity[index].imei !== null) {
      return partnerCommodity[index].imei;
    } else if (partnerCommodity[index].serialNumber !== null) {
      return partnerCommodity[index].serialNumber;
    } else {
      return '-';
    }
  };

  checkDeliveryType = () => {
    const { partnerCommodity } = this.state;
    const { deliveryType } = partnerCommodity[0];

    if (deliveryType === 'Over the counter') {
      return this.setState({
        deliveryType: 'OTC',
      });
    }
    return this.setState({
      deliveryType: 'HD',
    });
  };

  checkStatus = () => {
    this.triggerLoading(true);
    const { customerData } = this.state;
    const status = customerData.statusIdPP;

    switch (status) {
      case 'STATUS_HD_GOODS_DELIVERY':
        this.setState({
          isPaid: true,
        });
        break;
      case 'STATUS_HD_GOODS_SENT':
        this.setState({
          isPaid: true,
          isReadyToDeliver: true,
        });
        break;
      case 'STATUS_OTC_GOODS_RECEIVED':
        this.setState({
          isPaid: true,
          isReadyToDeliver: true,
          isDelivered: true,
        });
        break;
      case 'STATUS_ACTIVE':
        this.setState({
          isPaid: true,
          isReadyToDeliver: true,
          isDelivered: true,
        });
        break;
      default:
        break;
    }
    this.triggerLoading(false);
  };

  checkTimestamp = () => {
    this.triggerLoading(true);
    const { deliveryAdvice } = this.state;

    if (
      deliveryAdvice.dPStatusModifiedBy === null &&
      deliveryAdvice.dPStatusModifiedDate === null
    ) {
      this.setState({
        isPaidTime: true,
      });
    }

    if (
      deliveryAdvice.deliveryStatusModifiedBy === null &&
      deliveryAdvice.deliveryStatusModifiedDate === null
    ) {
      this.setState({
        isDeliveryTime: true,
      });
    }
    this.triggerLoading(false);
  };

  changeDeliveryButtonDescription = () => {
    const { deliveryType, isReadyToDeliver, isDelivered } = this.state;

    if (deliveryType === 'OTC') {
      if (isReadyToDeliver) {
        if (isDelivered) {
          return 'Terkonfirmasi Over The Counter';
        }
        return 'Konfirmasi Over The Counter';
      }
      return 'Konfirmasi Over The Counter';
    }
    if (isReadyToDeliver) {
      if (isDelivered) {
        return 'Terkonfirmasi Barang Telah Diterima';
      }
      return 'Konfirmasi Barang Terkirim';
    } else {
      return 'Konfirmasi Siap Dikirim';
    }
  };

  changeDeliveryButtonFunction = () => {
    const {
      deliveryType,
      isImeiInvalid,
      isInvoiceInvalid,
      isReadyToDeliver,
      isDelivered,
    } = this.state;

    if (isImeiInvalid) {
      if (resolvePrivileges.showImeiFillingPopup()) {
        this.setState({
          isImeiFillingConfirmPopupShown: true,
        });
      }
    } else if (isInvoiceInvalid) {
      if (resolvePrivileges.showInvoiceFillingPopup()) {
        this.setState({
          isInvoiceFillingConfirmPopupShown: true,
        });
      }
    } else {
      if (deliveryType === 'OTC') {
        if (isReadyToDeliver) {
          if (isDelivered) {
            this.setState({
              isDeliveredConfirmPopupShown: true,
            });
          }
          this.setState({
            isDeliveredConfirmPopupShown: true,
          });
        }
      }
      if (isReadyToDeliver) {
        if (isDelivered) {
          this.setState({
            isDeliveredConfirmPopupShown: true,
          });
        }
        this.setState({
          isDeliveredConfirmPopupShown: true,
        });
      } else {
        this.setState({
          isReadyToDeliverConfirmPopupShown: true,
        });
      }
    }
  };

  disablePaymentButton = () => {
    const { isPaid, isImeiInvalid } = this.state;
    const user = JSON.parse(localStorage.partnerPortalLoginObject).object;
    const role = user.partnerRole.roleId;

    if (resolvePrivileges.disableDeliveryAdviceButton()) {
      if (
        role === 'OFFLINE_PARTNER_USER' ||
        role === 'OFFLINE_PARTNER_USER_INVOICE'
      )
        if (!isPaid && isImeiInvalid) {
          return false;
        }
    } else if (
      role === 'ALDI_TNT_ADMIN' ||
      role === 'ALDI_TNT_USER' ||
      role === 'ALDI_TNT_ADMIN_FP' ||
      role === 'ALDI_TNT_USER_FP'
    ) {
      if (!isPaid) {
        return false;
      }
    }
    return true;
  };

  changeFillingType = commodity => {
    switch (commodity) {
      case 'mobile':
        return 'IMEI';
      case 'laptop':
        return 'Serial Number';
      default:
        return '';
    }
  };

  exportPdf = async () => {
    try {
      const { match } = this.props;
      const { deliveryAdvice } = this.state;
      const { data } = await GetAxios(
        'MAIN',
        `/user-management/export-contract-detail-to-pdf?contractNumber=${
          match.params.contractNumber
        }&contractStatus=${deliveryAdvice.statusPP}`,
        this.signal.token,
        false,
      );
      // const pdf = `data:${data.headers['content-type']};base64,${btoa(
      //   String.fromCharCode(...new Uint8Array(data.body)),
      // )}`;
      const file = new Blob(data, { type: 'application/pdf' });
      console.log(file);
      const fileURL = URL.createObjectURL(file);
      window.open(fileURL);
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
  };

  closeImeiValidationPopup = () => {
    this.setState({
      isImeiValidationPopupShown: false,
    });
  };

  openPaymentConfirmPopup = () => {
    this.setState({
      isPaymentConfirmPopupShown: true,
    });
    // this.getData();
  };

  closePaymentConfirmPopup = () => {
    this.setState({
      isPaymentConfirmPopupShown: false,
    });
    // this.getData();
  };

  openPaymentDonePopup = async () => {
    await this.getData();
    await this.setState({
      isPaymentDonePopupShown: true,
    });
    // this.getData();
  };

  closePaymentDonePopup = () => {
    this.setState({
      isPaymentDonePopupShown: false,
    });
    // this.getData();
  };

  openImeiFillingConfirmPopup = () => {
    this.setState({
      isImeiFillingConfirmPopupShown: true,
    });
    // this.getData();
  };

  closeImeiFillingConfirmPopup = imeiInvalid => {
    this.setState({
      isImeiFillingConfirmPopupShown: false,
      isImeiInvalid: imeiInvalid,
      imei: '',
    });
    // this.getData();
  };

  openImeiFillingDonePopup = async () => {
    await this.getData();
    await this.setState({
      isImeiFillingDonePopupShown: true,
    });
    // this.getData();
  };

  closeImeiFillingDonePopup = () => {
    this.setState({
      isImeiFillingDonePopupShown: false,
    });
    // this.getData();
  };

  openImeiFillingFailPopup = async () => {
    await this.getData();
    await this.setState({
      isImeiFillingFailPopupShown: true,
      isImeiInvalid: true,
      imei: '',
    });
    // this.getData();
  };

  closeImeiFillingFailPopup = () => {
    this.setState({
      isImeiFillingFailPopupShown: false,
    });
    // this.getData();
  };

  openInvoiceFillingConfirmPopup = () => {
    this.setState({
      isInvoiceFillingConfirmPopupShown: true,
    });
    // this.getData();
  };

  closeInvoiceFillingConfirmPopup = invoiceInvalid => {
    this.setState({
      isInvoiceFillingConfirmPopupShown: false,
      isInvoiceInvalid: invoiceInvalid,
      invoice: '',
    });
    // this.getData();
  };

  openInvoiceFillingDonePopup = async () => {
    await this.getData();
    await this.setState({
      isInvoiceFillingDonePopupShown: true,
    });
    // this.getData();
  };

  closeInvoiceFillingDonePopup = () => {
    this.setState({
      isInvoiceFillingDonePopupShown: false,
    });
    // this.getData();
  };

  openReadyToDeliveryConfirmPopup = () => {
    this.setState({
      isReadyToDeliverConfirmPopupShown: true,
    });
    // this.getData();
  };

  closeReadyToDeliveryConfirmPopup = () => {
    this.setState({
      isReadyToDeliverConfirmPopupShown: false,
    });
    // this.getData();
  };

  openReadyToDeliveryDonePopup = async () => {
    await this.getData();
    await this.setState({
      isReadyToDeliverDonePopupShown: true,
    });
    // this.getData();
  };

  closeReadyToDeliveryDonePopup = () => {
    this.setState({
      isReadyToDeliverDonePopupShown: false,
    });
    // this.getData();
  };

  openDeliveredConfirmPopup = () => {
    this.setState({
      isDeliveredConfirmPopupShown: true,
    });
    // this.getData();
  };

  closeDeliveredConfirmPopup = () => {
    this.setState({
      isDeliveredConfirmPopupShown: false,
    });
    // this.getData();
  };

  openDeliveredDonePopup = async () => {
    await this.getData();
    await this.setState({
      isDeliveredDonePopupShown: true,
    });
    // this.getData();
  };

  closeDeliveredDonePopup = () => {
    this.setState({
      isDeliveredDonePopupShown: false,
    });
    // this.getData();
  };

  triggerLoading = loadingShown => {
    const isShown = loadingShown;
    if (isShown) {
      this.setState({
        isLoading: true,
      });
    } else {
      this.setState({ isLoading: false });
    }
  };

  render() {
    const {
      buybackAmount,
      deliveryAdvice,
      customerData,
      partnerCommodity,
      partnerSalesroom,
      partner,
      deliveryType,
      commodityType,
      isImeiInvalid,
      isInvoiceInvalid,
      isPaid,
      isDelivered,
      isPaidTime,
      isDeliveryTime,
      isImeiValidationPopupShown,
      isPaymentConfirmPopupShown,
      isPaymentDonePopupShown,
      isImeiFillingConfirmPopupShown,
      isImeiFillingDonePopupShown,
      isImeiFillingFailPopupShown,
      isInvoiceFillingConfirmPopupShown,
      isInvoiceFillingDonePopupShown,
      isReadyToDeliverConfirmPopupShown,
      isReadyToDeliverDonePopupShown,
      isDeliveredConfirmPopupShown,
      isDeliveredDonePopupShown,
      isLoading,
    } = this.state;
    DevTools(() => console.log(buybackAmount));
    return (
      <div>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>Instruksi Penyerahan</div>
                </div>
                <div className={styles['summary-outer-container']}>
                  <div className={styles['summary-inner-container']}>
                    <div className={styles['summary-checked-container']}>
                      <img src={CheckedBig} alt="CheckedBig" />
                    </div>
                    <div className={styles['summary-detail-container']}>
                      <div className={styles['option-detail-left']}>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Pelanggan
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>{customerData.customerName}</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Kontrak
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>{customerData.contractNumber}</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Tanggal Pembuatan Kontrak
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>{customerData.contractCreateDate}</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Tanda Tangan Kontrak
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>{customerData.contractDecisionDate}</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Status Kontrak
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>{customerData.statusPP}</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Tenor
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>{customerData.tenor}</p>
                          </div>
                        </div>
                        <div
                          className={
                            resolvePrivileges.showInvoiceNumber()
                              ? styles['option-detail-wrapper-first']
                              : styles['option-detail-wrapper-first-hidden']
                          }
                        >
                          <div className={styles['option-detail-title']}>
                            Nomor Faktur
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>-</p>
                          </div>
                        </div>
                      </div>
                      <div className={styles['option-detail-right']}>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Mitra
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>{partnerSalesroom.name}</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Tipe Mitra
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>{partner.type}</p>
                          </div>
                        </div>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Nama Toko
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>{partner.name}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className={styles['summary-detail-bottom-container']}>
                      <div className={styles['option-detail-left']}>
                        <div className={styles['option-detail-wrapper-first']}>
                          <div className={styles['option-detail-title']}>
                            Pembayaran
                          </div>
                          <div className={styles['option-detail-value']}>
                            <p>
                              Jumlah Total Pembayaran Tunai (termasuk Biaya
                              Administrasi {customerData.originationFee}) yang
                              harus ditagih dari pelanggan:{' '}
                              {customerData.cashPayment}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <Slider {...sliderSettings}>
                    {partnerCommodity.map(commodity => (
                      <React.Fragment key={commodity.id}>
                        <div className={styles['summary-second-container']}>
                          <div className={styles['summary-detail-container']}>
                            <div className={styles['option-detail-left']}>
                              <div
                                className={
                                  styles['option-detail-wrapper-first']
                                }
                              >
                                <div className={styles['option-detail-title']}>
                                  Model
                                </div>
                                <div className={styles['option-detail-value']}>
                                  <p>
                                    {commodity.modelNumber === null
                                      ? '-'
                                      : commodity.modelNumber}
                                  </p>
                                </div>
                              </div>
                              <div
                                className={
                                  styles['option-detail-wrapper-first']
                                }
                              >
                                <div className={styles['option-detail-title']}>
                                  Pabrikan
                                </div>
                                <div className={styles['option-detail-value']}>
                                  <p>
                                    {commodity.producer === null
                                      ? '-'
                                      : commodity.producer}
                                  </p>
                                </div>
                              </div>
                              <div
                                className={
                                  styles['option-detail-wrapper-first']
                                }
                              >
                                <div className={styles['option-detail-title']}>
                                  {commodityType === 'mobile'
                                    ? 'IMEI'
                                    : 'Serial Number'}
                                </div>
                                <div className={styles['option-detail-value']}>
                                  <p>{this.showImei(commodity.id)}</p>
                                </div>
                              </div>
                            </div>
                            <div className={styles['option-detail-right']}>
                              <div
                                className={
                                  styles['option-detail-wrapper-first']
                                }
                              >
                                <div className={styles['option-detail-title']}>
                                  Jumlah
                                </div>
                                <div className={styles['option-detail-value']}>
                                  <p>1</p>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div
                            className={
                              styles['summary-detail-bottom-container']
                            }
                          >
                            <div className={styles['option-detail-left']}>
                              <div
                                className={
                                  styles['option-detail-wrapper-first']
                                }
                              >
                                <div className={styles['option-detail-title']}>
                                  Harga
                                </div>
                                <div className={styles['option-detail-value']}>
                                  <p>{commodity.price}</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </React.Fragment>
                    ))}
                  </Slider>
                </div>
                <div
                  className={
                    resolvePrivileges.hideDeliveryAdviceButton()
                      ? styles['summary-total-container-hidden']
                      : styles['summary-total-container']
                  }
                >
                  <div className={styles['option-payment']}>
                    <div
                      className={
                        isPaidTime
                          ? styles['option-payment-title-hidden']
                          : styles['option-payment-title']
                      }
                    >
                      Oleh: {deliveryAdvice.dPStatusModifiedBy},{' '}
                      {deliveryAdvice.dPStatusModifiedDate}
                    </div>
                    <div
                      className={
                        this.disablePaymentButton()
                          ? styles['option-payment-detail-disabled']
                          : styles['option-payment-detail']
                      }
                      onClick={
                        this.disablePaymentButton()
                          ? () => {}
                          : this.openPaymentConfirmPopup
                      }
                      onKeyPress={
                        this.disablePaymentButton()
                          ? () => {}
                          : this.openPaymentConfirmPopup
                      }
                      role="button"
                      tabIndex="0"
                    >
                      <div
                        className={
                          isPaid
                            ? styles['option-payment-logo']
                            : styles['option-payment-logo-hidden']
                        }
                      >
                        <img src={CheckedBig} alt="Money" width="40%" />
                      </div>
                      <div className={styles['option-payment-description']}>
                        <p className={styles['option-payment-value']}>
                          {isPaid
                            ? 'Terkonfirmasi Pembayaran DP'
                            : 'Konfirmasi Pembayaran DP'}
                        </p>
                      </div>
                    </div>
                  </div>
                  <br />
                  <div className={styles['option-payment']}>
                    <div
                      className={
                        isDeliveryTime
                          ? styles['option-payment-title-hidden']
                          : styles['option-payment-title']
                      }
                    >
                      Oleh: {deliveryAdvice.deliveryStatusModifiedBy},{' '}
                      {deliveryAdvice.deliveryStatusModifiedDate}
                    </div>
                    <div
                      className={
                        resolvePrivileges.disableDeliveryAdviceButton() ||
                        !isPaid ||
                        isDelivered
                          ? styles['option-payment-detail-disabled']
                          : styles['option-payment-detail']
                      }
                      onClick={
                        resolvePrivileges.disableDeliveryAdviceButton() ||
                        !isPaid ||
                        isDelivered
                          ? () => {}
                          : this.changeDeliveryButtonFunction
                      }
                      onKeyPress={
                        resolvePrivileges.disableDeliveryAdviceButton() ||
                        !isPaid ||
                        isDelivered
                          ? () => {}
                          : this.changeDeliveryButtonFunction
                      }
                      role="button"
                      tabIndex="0"
                    >
                      <div
                        className={
                          isDelivered
                            ? styles['option-payment-logo']
                            : styles['option-payment-logo-hidden']
                        }
                      >
                        <img src={CheckedBig} alt="Money" width="40%" />
                      </div>
                      <div className={styles['option-payment-description']}>
                        <p className={styles['option-payment-value']}>
                          {this.changeDeliveryButtonDescription()}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  className={styles['submit-button-container']}
                  onClick={this.exportPdf}
                  onKeyPress={this.exportPdf}
                  role="button"
                  tabIndex="0"
                >
                  <p>Unduh PDF</p>
                </div>
                <div
                  className={styles['back-button-container']}
                  // onClick={handleBack}
                  // onKeyPress={handleBack}
                  role="button"
                  tabIndex="0"
                >
                  <p>Kembali</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <ImeiValidationPopup
          popupShown={isImeiValidationPopupShown}
          onPopupClose={this.closeImeiValidationPopup}
        />
        <PaymentConfirmationPopup
          originationFee={customerData.originationFee}
          cashPayment={customerData.cashPayment}
          popupShown={isPaymentConfirmPopupShown}
          onPopupClose={this.closePaymentConfirmPopup}
          confirmPayment={this.confirmPayment}
        />
        <PaymentDonePopup
          popupShown={isPaymentDonePopupShown}
          onPopupClose={this.closePaymentDonePopup}
        />
        <ImeiFillingConfirmationPopup
          fillingType={this.changeFillingType(commodityType)}
          popupShown={isImeiFillingConfirmPopupShown}
          onPopupClose={() => this.closeImeiFillingConfirmPopup(true)}
          confirmImeiSn={this.confirmImeiSerialNumber}
          changeImei={this.validateImei}
          invalidImei={isImeiInvalid}
        />
        <ImeiFillingDonePopup
          fillingType={this.changeFillingType(commodityType)}
          popupShown={isImeiFillingDonePopupShown}
          onPopupClose={this.closeImeiFillingDonePopup}
        />
        <ImeiFillingFailPopup
          fillingType={this.changeFillingType(commodityType)}
          popupShown={isImeiFillingFailPopupShown}
          onPopupClose={this.closeImeiFillingFailPopup}
        />
        <InvoiceFillingConfirmationPopup
          popupShown={isInvoiceFillingConfirmPopupShown}
          onPopupClose={() => this.closeInvoiceFillingConfirmPopup(false)}
          confirmInvoice={this.confirmInvoice}
          changeInvoice={this.validateInvoice}
          invalidInvoice={isInvoiceInvalid}
        />
        <InvoiceFillingDonePopup
          popupShown={isInvoiceFillingDonePopupShown}
          onPopupClose={this.closeInvoiceFillingDonePopup}
        />
        <DeliveryConfirmationPopup
          deliveryDate={deliveryAdvice.dateNow}
          popupShown={isReadyToDeliverConfirmPopupShown}
          onPopupClose={this.closeReadyToDeliveryConfirmPopup}
          confirmDelivery={this.confirmDelivery}
        />
        <DeliveryDonePopup
          popupShown={isReadyToDeliverDonePopupShown}
          onPopupClose={this.closeReadyToDeliveryDonePopup}
        />
        <DeliveredConfirmationPopup
          deliveryType={
            deliveryType === 'OTC' ? 'Over The Counter' : 'Home Delivery'
          }
          deliveryDate={deliveryAdvice.dateNow}
          popupShown={isDeliveredConfirmPopupShown}
          onPopupClose={this.closeDeliveredConfirmPopup}
          confirmDelivered={this.confirmDelivered}
        />
        <DeliveredDonePopup
          popupShown={isDeliveredDonePopupShown}
          onPopupClose={this.closeDeliveredDonePopup}
          deliveryTypeMessage={
            deliveryType === 'OTC' ? 'Over The Counter' : 'Terkirim'
          }
        />
        <LoadingContainer open={isLoading} />
      </div>
    );
  }
}

export default DeliveryAdviceClass;

DeliveryAdviceClass.propTypes = {
  match: PropTypes.instanceOf(Object).isRequired,
};
