import React, { Component } from 'react';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import styles from './ContractDashboardContainer.module.css';

class Dashboard extends Component {
  constructor() {
    super();
    this.state = {
      tabValue: 0,
    };
  }

  handleTabChange = (e, newValue) => {
    this.setState({
      tabValue: newValue,
    });
  };

  render() {
    const { tabValue } = this.state;
    return (
      <React.Fragment>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>Pencarian Kontrak</div>
                </div>
                <div className={styles['textfield-container']}>
                  <div>
                    <Tabs
                      value={tabValue}
                      onChange={this.handleTabChange}
                      indicatorColor="primary"
                      textColor="primary"
                      centered
                    >
                      <Tab label="Item One" />
                      <Tab label="Item Two" />
                    </Tabs>
                    {tabValue === 0 && <div>Item One</div>}
                    {tabValue === 1 && <div>Item Two</div>}
                  </div>
                </div>
                <div
                  className={styles['submit-button-container']}
                  onClick={() => {}}
                  onKeyPress={() => {}}
                  role="button"
                  tabIndex="0"
                >
                  <p>Cari</p>
                </div>
                <div
                  className={styles['back-button-container']}
                  onClick={() => {}}
                  onKeyPress={() => {}}
                  role="button"
                  tabIndex="0"
                >
                  <p>Reset</p>
                </div>
                <div className={styles['textfield-container']}>
                  <div className={styles['title-wrapper']}>
                    <div className={styles['title-description']}>
                      Aplikasi Terdaftar
                    </div>
                    <div className={styles['title-date']}>14 Februari 2019</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default Dashboard;
