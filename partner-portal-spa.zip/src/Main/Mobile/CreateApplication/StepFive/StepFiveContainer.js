import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
// import { DevTools } from '../../../../Utils/SharedFunctions';
import styles from './StepFiveContainer.module.css';
import MobileFooter from '../../Common/FooterComponent';
import { CreateApplicationContext } from '../CreateApplicationContext';

const theme = createMuiTheme({
  // Name of the component ⚛️
  typography: {
    // The properties to apply
    useNextVariants: true,
    // Use the system font instead of the default Roboto font.
    htmlFontSize: 15,
    fontWeight: '500',
  },
});

const raCodeData = [
  {
    value: 'NONE',
    label: 'Pilih RA Code',
    disabled: true,
  },
  {
    value: '00',
    label: '0',
    disabled: false,
  },
  {
    value: '1',
    label: '1',
    disabled: false,
  },
  {
    value: '2',
    label: '2',
    disabled: false,
  },
  {
    value: '3',
    label: '3',
    disabled: false,
  },
];

const stepNumber = 5;

class StepFive extends Component {
  static contextType = CreateApplicationContext;

  constructor(props) {
    super(props);
    this.state = {
      raCode: 'NONE',
      isValid: '',
      isBack: '',
    };
  }

  handleChangeRaCode = () => event => {
    this.setState({
      raCode: event.target.value,
    });
  };

  handleContinue = () => {
    const { pushValue } = this.context;
    const { raCode } = this.state;
    const stepFiveValue = { raCode };
    pushValue(stepNumber, stepFiveValue);
    this.setState({
      isValid: true,
    });
  };

  handleBack = () => {
    this.setState({
      isBack: true,
    });
  };

  render() {
    const { raCode, isValid, isBack } = this.state;

    const { value } = this.context;

    if (
      Object.keys(value.stepOne).length === 0 &&
      value.stepOne.constructor === Object
    )
      return <Redirect to="/create-application/step-one" />;

    if (isValid) return <Redirect to="/create-application/step-six" />;

    if (isBack) return <Redirect to="/create-application/step-four" />;

    return (
      <div>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>
                    Data Pengajuan <br />& Kontrak
                  </div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Langkah 5</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Verifikasi Kode RA</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>Berikan Handphone anda ke Petugas untuk kode verifikasi</p>
                </div>
                <div className={styles['textfield-container']}>
                  <div className={styles['first-description']}>Kode RA</div>
                  <div className={styles['first-field']}>
                    {/* Diserahkan di toko */}
                    <MuiThemeProvider theme={theme}>
                      <TextField
                        select
                        value={raCode}
                        onChange={this.handleChangeRaCode()}
                        fullWidth
                      >
                        {raCodeData.map(option => (
                          <MenuItem
                            key={option.value}
                            value={option.value}
                            disabled={option.disabled}
                          >
                            {option.label}
                          </MenuItem>
                        ))}
                      </TextField>
                    </MuiThemeProvider>
                  </div>
                </div>
                <div
                  className={
                    raCode !== 'NONE'
                      ? styles['submit-button-container']
                      : styles['submit-button-container-disabled']
                  }
                  onClick={raCode !== 'NONE' ? this.handleContinue : () => {}}
                  onKeyPress={
                    raCode !== 'NONE' ? this.handleContinue : () => {}
                  }
                  role="button"
                  tabIndex="0"
                >
                  <p>Lanjut</p>
                </div>
                <div
                  className={styles['back-button-container']}
                  onClick={this.handleBack}
                  onKeyPress={this.handleBack}
                  role="button"
                  tabIndex="0"
                >
                  <p>Kembali</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <MobileFooter />
      </div>
    );
  }
}

export default StepFive;
