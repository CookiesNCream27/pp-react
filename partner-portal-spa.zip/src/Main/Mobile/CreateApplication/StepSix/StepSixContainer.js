import React, { Component } from 'react';
import axios from 'axios';
import { Redirect } from 'react-router-dom';
import { DevTools, JavaLogger } from '../../../../Utils/SharedFunctions';
import styles from './StepSixContainer.module.css';
import { CreateApplicationContext } from '../CreateApplicationContext';
import { PostAxios, GetAxios } from '../../../../Utils/Services';

class StepSix extends Component {
  static contextType = CreateApplicationContext;

  signal = axios.CancelToken.source();

  constructor(props) {
    super(props);
    this.state = {
      applicationId: '',
      qrCode: '',
      isValid: '',
    };
  }

  componentDidMount() {
    const { value } = this.context;
    const applicationId = value.stepOne.startApplicationId;
    this.setState({
      applicationId: value.stepOne.startApplicationId,
    });
    JavaLogger('PARTNER_START_APPLICATION_STEP6', applicationId, this.signal);
    this.getQrCode();
  }

  getApplicationId = async () => {
    try {
      const { value } = this.context;
      const { stepOne, stepTwo, stepThree, stepFive } = value;

      const applicationCommodityList = [];
      for (let i = 0; i < stepTwo.commodities.length; i += 1) {
        const applicationCommodity = {
          commodityCode: stepTwo.commodities[i].category,
          commodityName: stepTwo.commodities[i].categoryName,
          commodityTypeCode: stepTwo.commodities[i].type,
          commodityTypeName: stepTwo.commodities[i].typeName,
          deliveryTypeCode: stepOne.deliveryMethodValue,
          deliveryTypeName: stepOne.deliveryMethodValue,
          goodsPrice: stepTwo.commodities[i].price,
          manufacturerCode: stepTwo.commodities[i].manufacturer
            ? stepTwo.commodities[i].manufacturer
            : '-',
          manufacturerName: stepTwo.commodities[i].manufacturer
            ? stepTwo.commodities[i].manufacturer
            : '-',
          modelNumber: stepTwo.commodities[i].model,
        };
        applicationCommodityList.push(applicationCommodity);
      }

      let originationFee;

      stepThree.product[0].fees.forEach(element => {
        if (element.code === 'TITF_ORIG_FEE') {
          originationFee = element.amount;
        } else {
          originationFee = 0;
        }
      });

      // for (let i = 0; i < stepThree.product[0].fees.length; i += 1) {
      //   if (stepThree.product[0].fees[i].code === 'TITF_ORIG_FEE') {
      //     originationFee = stepThree.product[0].fees[i].amount;
      //     break;
      //   } else {
      //     originationFee = 0;
      //   }
      // }

      const qrCodePayload = {
        customerRank: stepFive.customerRank,
        nik: stepOne.nikValue,
        partnerProductOffer: {
          partnerProduct: {
            productCode: stepThree.product[0].product.code,
            productName: stepThree.product[0].product.name,
            cashPayment: stepThree.product[0].cashPayment,
            downPayment: stepThree.product[0].downPayment,
            originationFee,
            effectiveFlatRate: stepThree.product[0].presentedInterestRate1,
            monthlyInstallment: stepThree.product[0].totalInstallment,
            tenor: stepThree.product[0].terms,
            creditAmount: stepThree.product[0].loanAmount,
          },
          offerCode: stepThree.product[0].code,
        },
        selectedCustomerOffer: stepThree.product[0],
        partnerFingerprint: stepFive.partnerFingerprint,
        applicationCommodityList,
        applicationUniqueId: stepOne.startApplicationId,
      };

      const { data } = await PostAxios(
        'MAIN',
        '/api/v1/aldi/create-application',
        qrCodePayload,
        this.signal.token,
      );
      this.setState({ applicationId: data.object.applicationId });
    } catch (error) {
      console.log('error: ', error);
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
  };

  getQrCode = async () => {
    try {
      await this.getApplicationId();
      const { applicationId } = this.state;
      const { data } = await GetAxios(
        'MAIN',
        `/api/utils/v1/image/generate-qrcode/${applicationId}`,
        this.signal.token,
        true,
      );
      const image = `data:${data['content-type']};base64,${btoa(
        String.fromCharCode(...new Uint8Array(data)),
      )}`;
      this.setState({ qrCode: image });
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
  };

  handleContinue = () => {
    this.setState({
      isValid: true,
    });
  };

  render() {
    const { qrCode, isValid } = this.state;

    const { value } = this.context;

    if (
      Object.keys(value.stepOne).length === 0 &&
      value.stepOne.constructor === Object
    )
      return <Redirect to="/create-application/step-one" />;

    if (isValid) return <Redirect to="/home" />;

    return (
      <div>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>
                    Data Pengajuan <br />& Kontrak
                  </div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Langkah 6</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Scan QR Code</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>
                    Minta Pelanggan untuk Scan QR Code berikut menggunakan
                    Aplikasi{' '}
                    <span className={styles['brand-style']}>
                      My Home Credit.
                    </span>
                  </p>
                </div>
                <div className={styles['textfield-container']}>
                  <div className={styles['qr-code']}>
                    {qrCode === '' ? (
                      <p>Loading</p>
                    ) : (
                      <img src={qrCode} alt="qrCode" />
                    )}
                  </div>
                  <div className={styles['qr-description']}>
                    Setelah berhasil scan, minta pelanggan untuk mengisi
                    pengajuan di{' '}
                    <span className={styles['brand-style']}>
                      My Home Credit.
                    </span>
                  </div>
                </div>
                <div
                  className={styles['submit-button-container']}
                  onClick={this.handleContinue}
                  onKeyPress={this.handleContinue}
                  role="button"
                  tabIndex="0"
                >
                  <p>Selesai</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default StepSix;
