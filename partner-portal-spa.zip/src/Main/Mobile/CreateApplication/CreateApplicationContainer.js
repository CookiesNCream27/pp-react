import React, { Component, Suspense } from 'react';
import { Redirect, Switch } from 'react-router-dom';
import ProtectedRoutes from '../../../Utils/ProtectedRoutes';
import MobileLoadingContainer from '../Loading/LoadingContainer';
import { CreateApplicationProvider } from './CreateApplicationContext';

const MobileStepOne = React.lazy(() => import('./StepOne/StepOneContainer'));
const MobileStepTwo = React.lazy(() => import('./StepTwo/StepTwoContainer'));
const MobileStepThree = React.lazy(() =>
  import('./StepThree/StepThreeContainer'),
);
const MobileStepFour = React.lazy(() => import('./StepFour/StepFourContainer'));
const MobileStepFive = React.lazy(() => import('./StepFive/StepFiveContainer'));
const MobileStepSix = React.lazy(() => import('./StepSix/StepSixContainer'));

const Root = () => (
  <Redirect
    to={{
      pathname: '/create-application/step-one',
    }}
  />
);

class MobileCreateApplication extends Component {
  render() {
    return (
      <React.Fragment>
        <CreateApplicationProvider>
          <Suspense fallback={<MobileLoadingContainer />}>
            <Switch>
              <ProtectedRoutes
                exact
                path="/create-application"
                component={props => <Root {...props} />}
                metaTitle="Create Application"
              />
              <ProtectedRoutes
                exact
                path="/create-application/step-one"
                component={props => <MobileStepOne {...props} />}
                metaTitle="Create Application Step One"
              />
              <ProtectedRoutes
                exact
                path="/create-application/step-two"
                component={props => <MobileStepTwo {...props} />}
                metaTitle="Create Application Step Two"
              />
              <ProtectedRoutes
                exact
                path="/create-application/step-three"
                component={props => <MobileStepThree {...props} />}
                metaTitle="Create Application Step Three"
              />
              <ProtectedRoutes
                exact
                path="/create-application/step-four"
                component={props => <MobileStepFour {...props} />}
                metaTitle="Create Application Step Four"
              />
              <ProtectedRoutes
                exact
                path="/create-application/step-five"
                component={props => <MobileStepFive {...props} />}
                metaTitle="Create Application Step Five"
              />
              <ProtectedRoutes
                exact
                path="/create-application/step-six"
                component={props => <MobileStepSix {...props} />}
                metaTitle="Create Application Step Six"
              />
            </Switch>
          </Suspense>
        </CreateApplicationProvider>
      </React.Fragment>
    );
  }
}

export default MobileCreateApplication;
