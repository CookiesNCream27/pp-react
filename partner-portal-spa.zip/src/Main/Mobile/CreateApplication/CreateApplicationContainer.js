import React, { Component, Suspense } from 'react';
import { Redirect } from 'react-router-dom';
import ProtectedRoutes from '../../../Utils/ProtectedRoutes';
import MobileLoadingContainer from '../Loading/LoadingContainer';
import { CreateApplicationProvider } from './CreateApplicationContext';
import MobileError from '../Error/Error404Container';

const MobileStepOne = React.lazy(() => import('./StepOne/StepOneContainer'));
const MobileStepTwo = React.lazy(() => import('./StepTwo/StepTwoContainer'));
const MobileStepThree = React.lazy(() =>
  import('./StepThree/StepThreeContainer'),
);
const MobileStepFour = React.lazy(() => import('./StepFour/StepFourContainer'));
const MobileStepFive = React.lazy(() => import('./StepFive/StepFiveContainer'));
const MobileStepSix = React.lazy(() => import('./StepSix/StepSixContainer'));

const Root = () => (
  <Redirect
    to={{
      pathname: '/create-application/step-one',
    }}
  />
);

class MobileCreateApplication extends Component {
  render() {
    return (
      <React.Fragment>
        <CreateApplicationProvider>
          <Suspense fallback={<MobileLoadingContainer />}>
            <ProtectedRoutes
              exact
              path="/create-application"
              component={props => <Root {...props} />}
            />
            <ProtectedRoutes
              exact
              path="/create-application/step-one"
              component={props => <MobileStepOne {...props} />}
            />
            <ProtectedRoutes
              exact
              path="/create-application/step-two"
              component={props => <MobileStepTwo {...props} />}
            />
            <ProtectedRoutes
              exact
              path="/create-application/step-three"
              component={props => <MobileStepThree {...props} />}
            />
            <ProtectedRoutes
              exact
              path="/create-application/step-four"
              component={props => <MobileStepFour {...props} />}
            />
            <ProtectedRoutes
              exact
              path="/create-application/step-five"
              component={props => <MobileStepFive {...props} />}
            />
            <ProtectedRoutes
              exact
              path="/create-application/step-six"
              component={props => <MobileStepSix {...props} />}
            />
            <ProtectedRoutes component={props => <MobileError {...props} />} />
          </Suspense>
        </CreateApplicationProvider>
      </React.Fragment>
    );
  }
}

export default MobileCreateApplication;
