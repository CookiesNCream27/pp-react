import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import InputBase from '@material-ui/core/InputBase';
import Dialog from '@material-ui/core/Dialog';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import styles from './StepOneContainer.module.css';
import MobileFooter from '../../Common/FooterComponent';
import LoginFailed from '../../../../assets/images/login_failed.png';
import { CreateApplicationContext } from '../CreateApplicationContext';

const theme = createMuiTheme({
  // Name of the component ⚛️
  typography: {
    // The properties to apply
    // Use the system font instead of the default Roboto font.
    useNextVariants: true,
    htmlFontSize: 15,
  },
});

const deliveryMethodData = [
  {
    value: 'NONE',
    label: 'Pilih Metode Penyerahan',
    disabled: true,
  },
  {
    value: 'TOKO',
    label: 'Diserahkan di Toko',
    disabled: false,
  },
  {
    value: 'RUMAH',
    label: 'Dikirim ke Rumah',
    disabled: false,
  },
];

const stepNumber = 1;

class StepOne extends Component {
  static contextType = CreateApplicationContext;

  constructor(props) {
    super(props);
    this.state = {
      deliveryMethod: 'NONE',
      nik: '',
      popupShown: false,
      popupInfo: '',
      isValid: '',
    };
  }

  handleChangeDeliveryMethod = () => event => {
    this.setState({
      deliveryMethod: event.target.value,
    });
  };

  handleChangeNik = () => event => {
    const regex = /^\d+$/;
    if (regex.test(event.target.value) || event.target.value.length === 0) {
      if (event.target.value.length <= 16) {
        this.setState({ nik: event.target.value });
      }
    }
  };

  nikLengthValidation = () => {
    const { nik } = this.state;
    if (nik.length === 16) {
      this.nikValidation();
    } else {
      this.setState({
        popupShown: true,
        popupInfo: 'NIK harus berjumlah 16 digit',
      });
    }
  };

  nikValidation = () => {
    const { nik } = this.state;

    const tanggalLahir = nik.substr(6, 2);
    const bulanLahir = nik.substr(8, 2);
    // const tahunLahir = nik.substr(10, 2);
    const numTanggalLahir = parseInt(tanggalLahir, 10);
    const numBulanLahir = parseInt(bulanLahir, 10);
    // const numTahunLahir = parseInt(tahunLahir, 10);

    if (
      numTanggalLahir > 0 &&
      numTanggalLahir < 32 &&
      numBulanLahir > 0 &&
      numBulanLahir < 13
    ) {
      this.ageValidation();
    } else if (
      numTanggalLahir > 40 &&
      numTanggalLahir < 72 &&
      numBulanLahir > 0 &&
      numBulanLahir < 13
    ) {
      this.ageValidation();
    } else {
      this.setState({
        popupShown: true,
        popupInfo: 'Format NIK tidak sesuai',
      });
    }
  };

  ageValidation = () => {
    const { deliveryMethod, nik } = this.state;

    let tanggalLahir = nik.substr(6, 2);
    const bulanLahir = nik.substr(8, 2);
    const tahunLahir = nik.substr(10, 2);
    const genderCheck = parseInt(tanggalLahir, 10);
    if (genderCheck > 40) {
      const a = genderCheck - 40;
      if (a < 10) {
        tanggalLahir = `0${a.toString()}`;
      } else {
        tanggalLahir = a.toString();
      }
    }
    // const numBulanLahir = parseInt(bulanLahir, 10);
    const numTahunLahir = parseInt(tahunLahir, 10);

    const today = new Date();
    // const dd = `0${today.getDate()}`.slice(-2);
    // const mm = `0${today.getMonth() + 1}`.slice(-2);
    const yyyy = today.getFullYear();
    const yy = parseInt(yyyy.toString().substr(-2), 10);

    let numTahunLahirYYYY;

    if (numTahunLahir < yy) {
      numTahunLahirYYYY = parseInt(`200${numTahunLahir.toString()}`, 10);
    } else if (numTahunLahir > yy) {
      numTahunLahirYYYY = parseInt(`19${numTahunLahir.toString()}`, 10);
    } else {
      numTahunLahirYYYY = parseInt(`20${yy.toString()}`, 10);
    }

    const birthDate = `${numTahunLahirYYYY.toString()}-${bulanLahir}-${tanggalLahir}`;
    // const todayDate = `${yyyy.toString()}-${mm.toString()}-${dd.toString()}`;

    const diffInMs = Date.now() - Date.parse(birthDate);

    const diffInYear = Math.floor(diffInMs / (1000 * 60 * 60 * 24 * 365.25));

    if (diffInYear >= 19) {
      const { pushValue } = this.context;
      const stepOneValue = {
        nikValue: nik,
        deliveryMethodValue: deliveryMethod,
      };
      pushValue(stepNumber, stepOneValue);
      this.setState({
        popupShown: false,
        popupInfo: '',
        isValid: true,
      });
    } else {
      this.setState({
        popupShown: true,
        popupInfo: 'Umur pelanggan harus diatas atau sama dengan 19 tahun',
      });
    }
  };

  handlePopupClose = () => {
    this.setState({
      popupShown: false,
    });
  };

  render() {
    const { deliveryMethod, nik, popupShown, popupInfo, isValid } = this.state;

    if (isValid) return <Redirect to="/create-application/step-two" />;

    return (
      <div>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>
                    Data Pengajuan <br />& Kontrak
                  </div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Langkah 1</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Informasi Pelanggan</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>Pastikan Nomor Identitas Anda Sesuai dengan KTP</p>
                </div>
                <div className={styles['textfield-container']}>
                  <div className={styles['first-description']}>
                    Metode Penyerahan Barang
                  </div>
                  <div className={styles['first-field']}>
                    {/* Diserahkan di toko */}
                    <MuiThemeProvider theme={theme}>
                      <TextField
                        id="standard-select-currency"
                        select
                        value={deliveryMethod}
                        onChange={this.handleChangeDeliveryMethod()}
                        fullWidth
                      >
                        {deliveryMethodData.map(option => (
                          <MenuItem
                            key={option.value}
                            value={option.value}
                            disabled={option.disabled}
                          >
                            {option.label}
                          </MenuItem>
                        ))}
                      </TextField>
                    </MuiThemeProvider>
                  </div>
                  {/* <hr /> */}
                  <div className={styles['second-description']}>
                    Data Pelanggan
                  </div>
                  <div className={styles['second-field']}>
                    <MuiThemeProvider theme={theme}>
                      <InputBase
                        placeholder="Isi NIK Sesuai KTP"
                        fullWidth
                        onChange={this.handleChangeNik()}
                        onKeyUp={this.handleChangeNik()}
                        maxLength="16"
                        value={nik}
                      />
                    </MuiThemeProvider>
                  </div>
                </div>
                <div
                  className={
                    deliveryMethod !== 'NONE' && nik.length !== 0
                      ? styles['submit-button-container']
                      : styles['submit-button-container-disabled']
                  }
                  onClick={
                    deliveryMethod !== 'NONE' && nik.length !== 0
                      ? this.nikLengthValidation
                      : () => {}
                  }
                  onKeyPress={
                    deliveryMethod !== 'NONE' && nik.length !== 0
                      ? this.nikLengthValidation
                      : () => {}
                  }
                  role="button"
                  tabIndex="0"
                >
                  <p>Lanjut</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <MobileFooter />
        <Dialog open={popupShown} onClose={this.handlePopupClose} fullWidth>
          <div className={styles['popup-container']}>
            <div>
              <img src={LoginFailed} alt="Login Failed" />
            </div>
            <div>
              <h2 className={styles['popup-title']}>GAGAL</h2>{' '}
            </div>
            <div>
              <p className={styles['popup-description']}>{popupInfo}</p>
            </div>
            <div
              className={styles['popup-button']}
              onClick={this.handlePopupClose}
              onKeyPress={this.handlePopupClose}
              role="button"
              tabIndex="0"
            >
              <p>Coba Lagi</p>
            </div>
          </div>
        </Dialog>
      </div>
    );
  }
}

export default StepOne;
