import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Dialog from '@material-ui/core/Dialog';
import styles from './PopupComponent.module.css';
import LoginFailed from '../../../../../assets/images/login_failed.png';

class PopupComponent extends Component {
  handlePopupClose = e => {
    const { popupClose } = this.props;
    e.preventDefault();
    popupClose();
  };

  render() {
    console.log(this.props);
    const { popupShown, popupTitle, popupInfo } = this.props;
    return (
      <Dialog open={popupShown} onClose={this.handlePopupClose} fullWidth>
        <div className={styles['popup-container']}>
          <div>
            <img src={LoginFailed} alt="Login Failed" />
          </div>
          <div>
            <h2 className={styles['popup-title']}>{popupTitle}</h2>{' '}
          </div>
          <div>
            <p className={styles['popup-description']}>{popupInfo}</p>
          </div>
          <div
            className={styles['popup-button']}
            onClick={this.handlePopupClose}
            onKeyPress={this.handlePopupClose}
            role="button"
            tabIndex="0"
          >
            <p>Tutup</p>
          </div>
        </div>
      </Dialog>
    );
  }
}

export default PopupComponent;

PopupComponent.propTypes = {
  popupShown: PropTypes.bool,
  popupTitle: PropTypes.string,
  popupInfo: PropTypes.string,
  popupClose: PropTypes.func,
};

PopupComponent.defaultProps = {
  popupShown: false,
  popupTitle: '',
  popupInfo: '',
  popupClose: () => {},
};
