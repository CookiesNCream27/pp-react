import React, { Component } from 'react';
import axios from 'axios';
import { Redirect } from 'react-router-dom';
import NumberFormat from 'react-number-format';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import InputBase from '@material-ui/core/InputBase';
import InputAdornment from '@material-ui/core/InputAdornment';
import Dialog from '@material-ui/core/Dialog';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import { DevTools, JavaLogger } from '../../../../Utils/SharedFunctions';
import { PostAxios, GetAxios } from '../../../../Utils/Services';
import styles from './StepTwoContainer.module.css';
import LoadingContainer from '../../Loading/LoadingContainer';
import LoginFailed from '../../../../assets/images/login_failed.png';
import Exit from '../../../../assets/images/exit.png';
import PlusSign from '../../../../assets/images/plus_sign.png';
import PlusSignEnable from '../../../../assets/images/plus_sign_enable.png';
import { CreateApplicationContext } from '../CreateApplicationContext';

const theme = createMuiTheme({
  typography: {
    useNextVariants: true,
    htmlFontSize: 15,
    fontWeight: 'bold',
  },
  overrides: {
    MuiInput: {
      underline: {
        '&:before,&:after': {
          borderBottom: '1px solid #f8f5f8',
        },
      },
    },
  },
});

let totalEmptyField = 999;
let totalEmptyFieldForContinue = 999;

const stepNumber = 2;

class StepTwo extends Component {
  static contextType = CreateApplicationContext;

  signal = axios.CancelToken.source();

  constructor(props) {
    super(props);
    this.state = {
      customerProduct: [
        {
          id: 1,
          commodityCategory: 'NONE',
          commodityType: 'NONE',
          manufacturer: 'Pilih Merk',
          commodityTypeList: [
            {
              code: 'NONE',
              name: {
                localizedString: [
                  { locale: 'IN', text: 'Pilih Tipe Barang' },
                  { locale: 'EN', text: 'Choose Commodity Type' },
                ],
              },
              sortOrder: 0,
              categoryCode: 'NONE',
            },
          ],
          manufacturerList: [
            {
              code: 'Pilih Merk',
              productType: '',
              currency: '',
              manufacturer: ['Pilih Merk'],
              productVariant: [],
              tariffItem: [],
            },
          ],
          model: '',
          price: '',
        },
      ],
      commodityCategory: [
        {
          code: 'NONE',
          name: {
            localizedString: [
              { locale: 'IN', text: 'Pilih Jenis Produk' },
              { locale: 'EN', text: 'Choose Commodity Category' },
            ],
          },
          sortOrder: 0,
        },
      ],
      total: '',
      popupShown: false,
      popupInfo: '',
      isValid: false,
      isBack: false,
      isLoading: false,
    };
    this.addProduct = this.addProduct.bind(this);
    this.enableAddProduct = this.enableAddProduct.bind(this);
    this.enableContinue = this.enableContinue.bind(this);
  }

  componentDidMount() {
    const { value } = this.context;
    const applicationId = value.stepOne.startApplicationId;
    JavaLogger('PARTNER_START_APPLICATION_STEP1', applicationId, this.signal);
    this.getCommodityCategory();
    this.triggerLoading(false);
  }

  componentWillUnmount() {
    this.signal.cancel('Login Api has been canceled');
  }

  getCommodityCategory = async () => {
    try {
      const { data } = await GetAxios(
        'MAIN',
        '/api/v1/bsl/get-code-list',
        this.signal.token,
      );
      if (data === null) {
        this.setState({
          popupShown: true,
          popupInfo: '',
        });
      } else {
        this.setState(
          prevState => ({
            commodityCategory: [
              ...prevState.commodityCategory,
              ...data.commodityCategory,
            ],
          }),
          () => {},
        );
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
  };

  getCommodityType = async (commodityCategoryValue, index) => {
    this.triggerLoading(true);
    const { customerProduct } = this.state;
    try {
      const value = commodityCategoryValue;
      const arrayIndex = index;
      const { data } = await GetAxios(
        'MAIN',
        `/api/v1/bsl/get-code-list/${value}`,
        this.signal.token,
      );
      if (data === null) {
        this.setState({ popupShown: true, popupInfo: '' });
      } else {
        const arrayLength =
          customerProduct[arrayIndex].commodityTypeList.length;
        customerProduct[arrayIndex].commodityTypeList.splice(
          1,
          arrayLength - 1,
        );
        customerProduct[arrayIndex].commodityTypeList.push(...data);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
    this.triggerLoading(false);
  };

  getManufacturer = async (manufacturerValue, index) => {
    this.triggerLoading(true);
    const { customerProduct } = this.state;
    const partnerPortalLoginObject = JSON.parse(
      localStorage.partnerPortalLoginObject,
    );
    const salesroomCode = partnerPortalLoginObject.object.partnerSalesroom.code;

    try {
      const value = manufacturerValue;
      const arrayIndex = index;
      const payload = {
        productProfile: ['PP_UNSEC'],
        commodityType: [value],
        salesroomCode,
      };
      const { data } = await PostAxios(
        'MAIN',
        '/api/v1/bsl/get-product-for-commodity',
        payload,
        this.signal.token,
      );
      const finalData = data.infoForCommodityType[0].product.filter(
        x => x.manufacturer.length > 0,
      );
      if (data === null) {
        this.setState({ popupShown: true, popupInfo: '' });
      } else {
        const arrayLength = customerProduct[arrayIndex].manufacturerList.length;
        customerProduct[arrayIndex].manufacturerList.splice(1, arrayLength - 1);
        customerProduct[arrayIndex].manufacturerList.push(...finalData);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        DevTools(() => console.log('Error: ', error.message));
      }
    }
    this.triggerLoading(false);
  };

  handleChangeCommodityCategory = (name, id) => event => {
    const { customerProduct } = this.state;
    const index = customerProduct.findIndex(x => x.id === id);
    customerProduct[index].commodityCategory = event.target.value;
    customerProduct[index].commodityType = 'NONE';
    customerProduct[index].manufacturer = 'Pilih Merk';
    this.forceUpdate();
    this.getCommodityType(event.target.value, index);
    this.enableAddProduct();
    this.enableContinue();
  };

  handleChangeCommodityType = (name, id) => event => {
    const { customerProduct } = this.state;
    const index = customerProduct.findIndex(x => x.id === id);
    customerProduct[index].commodityType = event.target.value;
    this.forceUpdate();
    this.getManufacturer(event.target.value, index);
    this.enableAddProduct();
    this.enableContinue();
  };

  handleChangeManufacturer = (name, id) => event => {
    const { customerProduct } = this.state;
    const index = customerProduct.findIndex(x => x.id === id);
    customerProduct[index].manufacturer = event.target.value;
    this.forceUpdate();
  };

  handleChangeModel = (name, id) => event => {
    const { customerProduct } = this.state;
    const index = customerProduct.findIndex(x => x.id === id);
    customerProduct[index].model = event.target.value;
    this.forceUpdate();
    this.enableContinue();
  };

  handleChangeTotal = values => {
    this.setState({ total: values.value });
    this.enableContinue();
  };

  priceValidation = () => {
    let price = 0;
    const { customerProduct, total, commodityCategory } = this.state;

    for (let index = 0; index < customerProduct.length; index += 1) {
      price += parseInt(customerProduct[index].price, 10);
    }

    if (total >= price) {
      this.setState({
        popupShown: true,
        popupInfo:
          'Total Pembayaran Tunai tidak boleh lebih besar dari harga barang',
      });
    } else {
      const { pushValue } = this.context;
      const stepTwoValue = {
        commodities: [],
        maximalCashPayment: parseInt(total, 10),
      };
      for (let index = 0; index < customerProduct.length; index += 1) {
        const finalObject = {
          manufacturer:
            customerProduct[index].manufacturer === 'Pilih Merk'
              ? null
              : customerProduct[index].manufacturer,
          model: customerProduct[index].model,
          price: customerProduct[index].price,
          type: customerProduct[index].commodityType,
          typeName:
            customerProduct[index].commodityTypeList[
              customerProduct[index].commodityTypeList.findIndex(
                x => x.code === customerProduct[index].commodityType,
              )
            ].name.localizedString[0].text,
          category: customerProduct[index].commodityCategory,
          categoryName:
            commodityCategory[
              commodityCategory.findIndex(
                x => x.code === customerProduct[index].commodityCategory,
              )
            ].name.localizedString[0].text,
        };
        stepTwoValue.commodities.push(finalObject);
      }
      pushValue(stepNumber, stepTwoValue);
      this.setState({
        popupShown: false,
        popupInfo: '',
        isValid: true,
      });
    }
  };

  addProduct = () => {
    const { customerProduct } = this.state;
    const arrayLength = customerProduct.length;
    const newId = customerProduct[arrayLength - 1].id + 1;
    const newCustomerProduct = {
      id: newId,
      commodityCategory: 'NONE',
      commodityType: 'NONE',
      manufacturer: 'Pilih Merk',
      model: '',
      price: '',
      commodityTypeList: [
        {
          code: 'NONE',
          name: {
            localizedString: [
              { locale: 'IN', text: 'Pilih Tipe Barang' },
              { locale: 'EN', text: 'Choose Commodity Type' },
            ],
          },
          sortOrder: 0,
          categoryCode: 'NONE',
        },
      ],
      manufacturerList: [
        {
          code: 'Pilih Merk',
          productType: '',
          currency: '',
          manufacturer: ['Pilih Merk'],
          productVariant: [],
          tariffItem: [],
        },
      ],
    };
    customerProduct.push(newCustomerProduct);
    this.forceUpdate();
    this.enableAddProduct();
  };

  removeProduct = id => {
    const { customerProduct } = this.state;
    const arrayIndex = customerProduct.findIndex(x => x.id === id);
    customerProduct.splice(arrayIndex, 1);
    this.forceUpdate();
    this.enableAddProduct();
  };

  enableAddProduct = () => {
    totalEmptyField = 0;
    const { customerProduct } = this.state;
    if (
      customerProduct[0].commodityCategory === 'NONE' ||
      customerProduct[0].commodityType === 'NONE'
    ) {
      totalEmptyField += 1;
    }
  };

  enableContinue = () => {
    totalEmptyFieldForContinue = 0;
    const { customerProduct, total } = this.state;
    for (let index = 0; index < customerProduct.length; index += 1) {
      if (
        customerProduct[index].commodityCategory === 'NONE' ||
        customerProduct[index].commodityType === 'NONE' ||
        customerProduct[index].model === '' ||
        customerProduct[index].price === '' ||
        total === ''
      ) {
        totalEmptyFieldForContinue += 1;
      }
    }
  };

  handlePopupClose = () => {
    this.setState({
      popupShown: false,
      popupInfo: '',
    });
  };

  handleBack = () => {
    const { removeValue } = this.context;
    removeValue(stepNumber);
    this.setState({
      isBack: true,
    });
  };

  triggerLoading = loadingShown => {
    const isShown = loadingShown;
    if (isShown) {
      this.setState({
        isLoading: true,
      });
    } else {
      this.setState({ isLoading: false });
    }
  };

  render() {
    const {
      customerProduct,
      commodityCategory,
      total,
      popupShown,
      popupInfo,
      isValid,
      isBack,
      isLoading,
    } = this.state;

    const { value } = this.context;

    if (
      Object.keys(value.stepOne).length === 0 &&
      value.stepOne.constructor === Object
    ) {
      totalEmptyField = 999;
      totalEmptyFieldForContinue = 999;
      return <Redirect to="/create-application/step-one" />;
    }

    if (isValid) {
      totalEmptyField = 999;
      totalEmptyFieldForContinue = 999;
      return <Redirect to="/create-application/step-three" />;
    }

    if (isBack) {
      totalEmptyField = 999;
      totalEmptyFieldForContinue = 999;
      return <Redirect to="/create-application/step-one" />;
    }

    return (
      <React.Fragment>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>
                    Data Pengajuan <br />& Kontrak
                  </div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Langkah 2</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Informasi Pengajuan</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>Masukan Informasi Barang yang Anda inginkan</p>
                </div>
                {customerProduct.map((data, index) => (
                  <div className={styles['textfield-container']} key={data.id}>
                    <div
                      className={
                        data.id === 1
                          ? styles['exit-picture-hidden']
                          : styles['exit-picture']
                      }
                      onClick={() => {
                        const { id } = data;
                        const arrayIndex = customerProduct.findIndex(
                          x => x.id === id,
                        );
                        customerProduct.splice(arrayIndex, 1);
                        this.forceUpdate();
                      }}
                      onKeyPress={() => {
                        const { id } = data;
                        const arrayIndex = customerProduct.findIndex(
                          x => x.id === id,
                        );
                        customerProduct.splice(arrayIndex, 1);
                        this.forceUpdate();
                      }}
                      role="button"
                      tabIndex="0"
                    >
                      <img src={Exit} alt="Exit" />
                    </div>
                    <div className={styles['first-description']}>
                      Data Produk
                    </div>
                    <div className={styles['first-field']}>
                      <MuiThemeProvider theme={theme}>
                        <TextField
                          id="commodityCategory"
                          select
                          value={data.commodityCategory}
                          onChange={this.handleChangeCommodityCategory(
                            'commodityCategory',
                            data.id,
                          )}
                          fullWidth
                        >
                          {commodityCategory.map(option => (
                            <MenuItem
                              key={option.code}
                              value={option.code}
                              disabled={option.code === 'NONE'}
                            >
                              {option.name.localizedString[0].text}
                            </MenuItem>
                          ))}
                        </TextField>
                      </MuiThemeProvider>
                    </div>
                    <div className={styles['first-description']} />
                    <div className={styles['first-field']}>
                      <MuiThemeProvider theme={theme}>
                        <TextField
                          id="commodityType"
                          select
                          value={data.commodityType}
                          onChange={this.handleChangeCommodityType(
                            'commodityType',
                            data.id,
                          )}
                          fullWidth
                          disabled={data.commodityCategory === 'NONE'}
                        >
                          {customerProduct[index].commodityTypeList.map(
                            option => (
                              <MenuItem
                                key={option.code}
                                value={option.code}
                                disabled={option.code === 'NONE'}
                              >
                                {option.name.localizedString[0].text}
                              </MenuItem>
                            ),
                          )}
                        </TextField>
                      </MuiThemeProvider>
                    </div>
                    <div className={styles['first-description']} />
                    <div className={styles['first-field']}>
                      <MuiThemeProvider theme={theme}>
                        <TextField
                          id="manufacturer"
                          select
                          value={data.manufacturer}
                          onChange={this.handleChangeManufacturer(
                            'manufacturer',
                            data.id,
                          )}
                          fullWidth
                        >
                          {customerProduct[index].manufacturerList.map(
                            option => (
                              <MenuItem
                                key={option.code}
                                value={option.manufacturer[0]}
                              >
                                {option.manufacturer[0]}
                              </MenuItem>
                            ),
                          )}
                        </TextField>
                      </MuiThemeProvider>
                    </div>
                    <div className={styles['model-description']} />
                    <div className={styles['second-field']}>
                      <MuiThemeProvider theme={theme}>
                        <InputBase
                          id="model"
                          placeholder="Isi Model Barang"
                          fullWidth
                          onChange={this.handleChangeModel('model', data.id)}
                          onKeyUp={this.handleChangeModel('model', data.id)}
                        />
                      </MuiThemeProvider>
                    </div>
                    <div className={styles['second-description']}>
                      Harga Barang
                    </div>
                    <div className={styles['second-field']}>
                      <MuiThemeProvider theme={theme}>
                        <NumberFormat
                          type="tel"
                          customInput={InputBase}
                          thousandSeparator
                          fullWidth
                          placeholder="Isi Harga Barang"
                          startAdornment={
                            <InputAdornment position="start">Rp</InputAdornment>
                          }
                          onValueChange={values => {
                            const { id } = data;
                            const idx = customerProduct.findIndex(
                              x => x.id === id,
                            );
                            customerProduct[idx].price = values.value;
                            this.forceUpdate();
                          }}
                          isNumericString
                          value={data.price}
                        />
                      </MuiThemeProvider>
                    </div>
                  </div>
                ))}
                <div
                  className={
                    totalEmptyField === 0
                      ? styles['add-item-button-container']
                      : styles['add-item-button-container-disabled']
                  }
                  onClick={
                    totalEmptyField === 0 ? this.addProduct : DevTools(() => {})
                  }
                  onKeyPress={
                    totalEmptyField === 0 ? this.addProduct : DevTools(() => {})
                  }
                  role="button"
                  tabIndex="0"
                >
                  <div className={styles['add-button-description']}>
                    <img
                      src={totalEmptyField === 0 ? PlusSignEnable : PlusSign}
                      alt="PlusSign"
                    />
                    <p>Tambah Barang</p>
                  </div>
                </div>
                <div className={styles['textfield-container']}>
                  <div className={styles['total-description']}>
                    Uang Muka + Biaya Admin
                  </div>
                  <div className={styles['total-field']}>
                    <MuiThemeProvider theme={theme}>
                      <NumberFormat
                        type="tel"
                        customInput={InputBase}
                        thousandSeparator
                        fullWidth
                        placeholder="Isi Total Pembayaran Tunai"
                        startAdornment={
                          <InputAdornment position="start">Rp</InputAdornment>
                        }
                        onValueChange={this.handleChangeTotal}
                        isNumericString
                        value={total}
                      />
                    </MuiThemeProvider>
                  </div>
                </div>
                <div
                  className={
                    totalEmptyFieldForContinue === 0
                      ? styles['submit-button-container']
                      : styles['submit-button-container-disabled']
                  }
                  onClick={
                    totalEmptyFieldForContinue === 0
                      ? this.priceValidation
                      : () => {}
                  }
                  onKeyPress={
                    totalEmptyFieldForContinue === 0
                      ? this.priceValidation
                      : () => {}
                  }
                  role="button"
                  tabIndex="0"
                >
                  <p>Lanjut</p>
                </div>
                <div
                  className={styles['back-button-container']}
                  onClick={this.handleBack}
                  onKeyPress={this.handleBack}
                  role="button"
                  tabIndex="0"
                >
                  <p>Kembali</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Dialog open={popupShown} onClose={this.handlePopupClose} fullWidth>
          <div className={styles['popup-container']}>
            <div>
              <img src={LoginFailed} alt="Login Failed" />
            </div>
            <div>
              <h2 className={styles['popup-title']}>GAGAL</h2>
            </div>
            <div>
              <p className={styles['popup-description']}>{popupInfo}</p>
            </div>
            <div
              className={styles['popup-button']}
              onClick={this.handlePopupClose}
              onKeyPress={this.handlePopupClose}
              role="button"
              tabIndex="0"
            >
              <p>Coba Lagi</p>
            </div>
          </div>
        </Dialog>
        <LoadingContainer open={isLoading} />
      </React.Fragment>
    );
  }
}

export default StepTwo;
