import React, { Component } from 'react';
import NumberFormat from 'react-number-format';
import { Redirect } from 'react-router-dom';
import styles from './StepFourContainer.module.css';
import MobileFooter from '../../Common/FooterComponent';
import CheckedBig from '../../../../assets/images/checked_big.svg';
import Money from '../../../../assets/images/money.svg';
import { CreateApplicationContext } from '../CreateApplicationContext';

class StepFour extends Component {
  static contextType = CreateApplicationContext;

  constructor(props, context) {
    super(props);
    const { value } = context;
    this.state = {
      chosenProduct: value.stepThree.product,
      isValid: false,
      isBack: false,
    };
  }

  handleContinue = () => {
    this.setState({
      isValid: true,
    });
  };

  handleBack = () => {
    this.setState({
      isBack: true,
    });
  };

  render() {
    const { chosenProduct, isValid, isBack } = this.state;

    const { value } = this.context;

    if (
      Object.keys(value.stepOne).length === 0 &&
      value.stepOne.constructor === Object
    )
      return <Redirect to="/create-application/step-one" />;

    if (isValid) return <Redirect to="/create-application/step-five" />;

    if (isBack) return <Redirect to="/create-application/step-three" />;

    return (
      <div>
        <div className={styles['layout-container']}>
          <div className={styles['background-first-layer']}>
            <div className={styles['background-second-layer']}>
              <div className={styles['layout-wrapper']}>
                <div className={styles['header-container']}>
                  <p className={styles['header-first-container']}>
                    <span className={styles['partner-style']}>PARTNER </span>
                    <span className={styles['portal-style']}>PORTAL</span>
                  </p>
                  <p className={styles['header-second-container']}>
                    <span className={styles['partner-style']}>By </span>
                    <span className={styles['portal-style']}>HOME CREDIT</span>
                  </p>
                </div>
                <div className={styles['title-container']}>
                  <div>
                    Data Pengajuan <br />& Kontrak
                  </div>
                </div>
                <div className={styles['step-number-container']}>
                  <p>Langkah 4</p>
                </div>
                <div className={styles['step-title-container']}>
                  <p>Rangkuman Pengajuan</p>
                </div>
                <div className={styles['step-detail-container']}>
                  <p>Pastikan Informasi Transaksi Anda Sudah Benar</p>
                </div>
                <div className={styles['summary-outer-container']}>
                  <div className={styles['summary-inner-container']}>
                    <div className={styles['summary-checked-container']}>
                      <img src={CheckedBig} alt="CheckedBig" />
                    </div>
                    <div className={styles['summary-detail-container']}>
                      <div className={styles['summary-title']}>
                        {chosenProduct.commodities[0].model}
                      </div>
                      <div className={styles['summary-subtitle']}>
                        Detail Pembiayaan
                      </div>
                    </div>
                  </div>
                  <div className={styles['summary-second-container']}>
                    <div className={styles['option-detail']}>
                      <div className={styles['option-detail-wrapper-first']}>
                        <div className={styles['option-detail-title']}>
                          Model Barang
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>{chosenProduct.commodities[0].model}</p>
                        </div>
                      </div>
                      <div className={styles['option-detail-wrapper-first']}>
                        <div className={styles['option-detail-title']}>
                          Harga Barang
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>
                            Rp{' '}
                            <NumberFormat
                              value={chosenProduct.totalPrice}
                              thousandSeparator
                              displayType="text"
                            />
                            ,-
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className={styles['option-detail']}>
                      <div className={styles['option-detail-wrapper-second']}>
                        <div className={styles['option-detail-title']}>
                          Tenor
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>{chosenProduct.terms} Bulan</p>
                        </div>
                      </div>
                      <div className={styles['option-detail-wrapper-second']}>
                        <div className={styles['option-detail-title']}>
                          Cicilan per Bulan
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>
                            Rp{' '}
                            <NumberFormat
                              value={chosenProduct.totalInstallment}
                              thousandSeparator
                              displayType="text"
                            />
                            ,-
                          </p>
                        </div>
                      </div>
                      <div className={styles['option-detail-wrapper-second']}>
                        <div className={styles['option-detail-title']}>
                          Suku Bunga
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>
                            {(chosenProduct.presentedInterestRate1 * 100)
                              .toFixed(2)
                              .replace(/\d(?=(\d{3})+\.)/g, '$&,')}
                            %
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className={styles['option-detail']}>
                      <div className={styles['option-detail-wrapper']}>
                        <div className={styles['option-detail-title']}>
                          Perlindungan Tambahan
                        </div>
                        <div className={styles['option-detail-value']}>
                          <p>-</p>
                        </div>
                      </div>
                    </div>
                    <div className={styles['option-payment']}>
                      <div className={styles['option-payment-title']}>
                        Total Pembayaran Tunai
                      </div>
                      <div className={styles['option-payment-detail']}>
                        <div className={styles['option-payment-logo']}>
                          <img src={Money} alt="Money" />
                        </div>
                        <div className={styles['option-payment-description']}>
                          <p className={styles['option-payment-value']}>
                            Rp{' '}
                            <NumberFormat
                              value={chosenProduct.cashPayment}
                              thousandSeparator
                              displayType="text"
                            />
                            ,-
                          </p>
                          <p className={styles['option-payment-subtitle']}>
                            (Uang Muka + Biaya Admin)
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  className={styles['submit-button-container']}
                  onClick={this.handleContinue}
                  onKeyPress={this.handleContinue}
                  role="button"
                  tabIndex="0"
                >
                  <p>Lanjut</p>
                  <div
                    className={styles['back-button-container']}
                    onClick={this.handleBack}
                    onKeyPress={this.handleBack}
                    role="button"
                    tabIndex="0"
                  >
                    <p>Kembali</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <MobileFooter />
      </div>
    );
  }
}

export default StepFour;
