import React, { useContext } from 'react';
import styles from './FaqContainer.module.css';
import { AuthContext } from '../../AuthContext';
import appConfig from '../../../config/application';
import FAQ from '../../../assets/images/faq1x.png';

// const CardContainer

const MobileFaq = () => {
  window.scrollTo(0, 0);
  const authContext = useContext(AuthContext);
  console.log(authContext);
  return (
    <React.Fragment>
      <div className={styles['layout-container']}>
        <div className={styles['background-first-layer']}>
          <div className={styles['background-second-layer']}>
            <div className={styles['layout-wrapper']}>
              <div className={styles['header-container']}>
                <p className={styles['header-first-container']}>
                  <span className={styles['partner-style']}>PARTNER </span>
                  <span className={styles['portal-style']}>PORTAL</span>
                </p>
                <p className={styles['header-second-container']}>
                  <span className={styles['partner-style']}>By </span>
                  <span className={styles['portal-style']}>HOME CREDIT</span>
                </p>
              </div>
              <div className={styles['title-container']}>
                <div>FAQ</div>
              </div>
              <hr />
              <div className={styles['faq-wrapper']}>
                <div className={styles.faq}>
                  <img src={FAQ} alt="This website is under construction" />
                </div>
                <div className={styles['step-detail-container']}>
                  <div>
                    Halaman ini sedang dalam proses pengembangan. Tapi kamu
                    sudah bisa menggunakan kalkulator canggih kami.
                    <br /> Silahkan kunjungi{' '}
                    <a href={`${appConfig.endpoint.url}/partnerportal`}>
                      Partner Portal
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default MobileFaq;
