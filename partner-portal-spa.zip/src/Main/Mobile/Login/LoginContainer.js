import React, { Component } from 'react';
import axios from 'axios';
import InputBase from '@material-ui/core/InputBase';
import Dialog from '@material-ui/core/Dialog';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import styles from './LoginContainer.module.css';
import { DevTools } from '../../../Utils/SharedFunctions';
import { AuthContext } from '../../AuthContext';
import { PostAxios } from '../../../Utils/Services';
import LoginFailed from '../../../assets/images/login_failed.png';

const overrides = theme => ({
  margin: {
    margin: theme.spacing.unit,
  },
});

const theme = createMuiTheme({
  typography: {
    useNextVariants: true,
    htmlFontSize: 15,
  },
});

class MobileLogin extends Component {
  static contextType = AuthContext;

  signal = axios.CancelToken.source();

  state = {
    username: '',
    password: '',
    disabled: true,
    popupshown: false,
    innerHeight: window.innerHeight,
  };

  componentWillUnmount() {
    this.signal.cancel('Login Api has been canceled');
  }

  submitLogin = (payload, login) => async e => {
    e.preventDefault();

    const { disabled } = this.state;

    if (!disabled) {
      try {
        const { data } = await PostAxios(
          'MAIN',
          '/user-management/login',
          payload,
          this.signal.token,
        );
        await login(data);
        if (data.auth === null) {
          this.setState({
            popupshown: true,
          });
        }
      } catch (error) {
        if (axios.isCancel(error)) {
          DevTools(() => console.log('Error: ', error.message));
        }
      }
    }
  };

  handleChange = str => event => {
    this.setState(
      {
        [str]: event.target.value,
      },
      () => this.checkValidInput(),
    );
  };

  checkValidInput = () => {
    const { username, password } = this.state;
    if (username && password) {
      this.setState({ disabled: false });
    } else {
      this.setState({ disabled: true });
    }
  };

  handleClose = () => {
    this.setState({
      popupshown: false,
    });
  };

  render() {
    const { username, password, innerHeight } = this.state;
    const { disabled, popupshown } = this.state;
    const { login } = this.context;

    const layoutWrapper = {
      padding: '10px 20px',
      minHeight: innerHeight,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
    };

    return (
      <React.Fragment>
        <div className={styles['background-first-layer']}>
          <div className={styles['background-second-layer']}>
            <div className={styles['background-third-layer']}>
              <div style={layoutWrapper}>
                <div className={styles['top-wrapper']}>
                  <div className={styles['header-container']}>
                    <p className={styles['header-first-container']}>
                      <span className={styles['partner-style']}>PARTNER </span>
                      <span className={styles['portal-style']}>PORTAL</span>
                    </p>
                    <p className={styles['header-second-container']}>
                      <span className={styles['partner-style']}>By </span>
                      <span className={styles['portal-style']}>
                        HOME CREDIT
                      </span>
                    </p>
                  </div>
                  <div className={styles['step-title-container']}>
                    <p>Selamat Datang!</p>
                  </div>
                  <div className={styles['step-detail-container']}>
                    <p>
                      Permudah transaksi kontrak anda <br />
                      dengan Partner Portal Mobile
                    </p>
                  </div>
                  <div className={styles['textfield-container']}>
                    <div className={styles['first-description']}>
                      Username / Email
                    </div>
                    <div className={styles['first-field']}>
                      <MuiThemeProvider theme={theme}>
                        <InputBase
                          className={overrides.margin}
                          fullWidth
                          type="text"
                          onChange={this.handleChange('username')}
                          value={username}
                          autoComplete="username"
                        />
                      </MuiThemeProvider>
                    </div>
                    <div className={styles['second-description']}>Password</div>
                    <div className={styles['second-field']}>
                      <MuiThemeProvider theme={theme}>
                        <InputBase
                          className={overrides.margin}
                          fullWidth
                          type="password"
                          onChange={this.handleChange('password')}
                          value={password}
                        />
                      </MuiThemeProvider>
                    </div>
                  </div>
                </div>
                <div className={styles['bottom-wrapper']}>
                  <div
                    className={
                      !disabled
                        ? styles['login-button-container']
                        : styles['login-button-container-disabled']
                    }
                    role="button"
                    tabIndex="0"
                    onClick={this.submitLogin({ username, password }, login)}
                    onKeyDown={this.submitLogin({ username, password }, login)}
                  >
                    <p>Masuk</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Dialog open={popupshown} onClose={this.handleClose}>
          <div className={styles['popup-container']}>
            <Grid
              container
              direction="column"
              justify="center"
              alignItems="center"
            >
              <Grid item md={8}>
                <img src={LoginFailed} alt="Login Failed" />
              </Grid>
              <Grid item md={8}>
                <h2 className={styles['popup-title']}>LOGIN GAGAL</h2>
              </Grid>
              <Grid item md={8}>
                <p className={styles['popup-description']}>
                  Email/telepon atau password yang anda masukkan salah
                </p>
              </Grid>
              <Grid item md={8}>
                <Button
                  className={styles['popup-button']}
                  onClick={this.handleClose}
                >
                  Coba Lagi
                </Button>
              </Grid>
            </Grid>
          </div>
        </Dialog>
      </React.Fragment>
    );
  }
}

export default MobileLogin;
