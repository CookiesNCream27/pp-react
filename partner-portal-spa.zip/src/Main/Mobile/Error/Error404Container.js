import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';

class MobileError404 extends Component {
  render() {
    const divStyle = {
      margin: '40px',
      border: '5px solid #e11931',
      textAlign: 'center',
    };

    return (
      <React.Fragment>
        <div style={divStyle}>
          <h1>Error 404 Not Found Mobile</h1>
        </div>
        <NavLink to="/home" exact activeClassName="active">
          <div style={divStyle}>Back to Home</div>
        </NavLink>
      </React.Fragment>
    );
  }
}

export default MobileError404;
