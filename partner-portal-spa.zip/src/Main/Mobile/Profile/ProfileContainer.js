import React, { useContext, useState } from 'react';
import PropTypes from 'prop-types';
import { Redirect } from 'react-router-dom';
import ChevronIcon from '@material-ui/icons/ChevronRight';
import styles from './ProfileContainer.module.css';
import UserIcon from '../../../assets/images/circle-profile.svg';
import { AuthContext } from '../../AuthContext';

const CardComponent = props => {
  const { children, title } = props;
  return (
    <div className={styles['profile-card-container']}>
      <div className={styles['profile-card-inner']}>
        <div className={styles['profile-card-title']}>{title}</div>
        <hr />
        <div className={styles['profile-card-section']}>{children}</div>
      </div>
    </div>
  );
};

CardComponent.propTypes = {
  children: PropTypes.node.isRequired,
  title: PropTypes.string.isRequired,
};

const CardDetailsComponent = props => {
  const { heading, subHeading, withArrow } = props;
  if (withArrow) {
    return (
      <div className={styles['profile-card-innards-arrow']}>
        <div>
          <div className={styles['profile-card-innards-heads']}>{heading}</div>
          <div className={styles['profile-card-innards-tails']}>
            {subHeading}
          </div>
        </div>
        <ChevronIcon className={styles['chevron-arrow']} />
      </div>
    );
  }
  return (
    <div className={styles['profile-card-innards']}>
      <div className={styles['profile-card-innards-heads']}>{heading}</div>
      <div className={styles['profile-card-innards-tails']}>{subHeading}</div>
    </div>
  );
};

CardDetailsComponent.defaultProps = {
  withArrow: false,
};

CardDetailsComponent.propTypes = {
  heading: PropTypes.string.isRequired,
  subHeading: PropTypes.string.isRequired,
  withArrow: PropTypes.bool,
};

const ButtonComponent = props => {
  const { text, onClick, onKeyPress } = props;
  return (
    <div
      className={styles['button-container']}
      onClick={onClick}
      onKeyPress={onKeyPress}
      role="button"
      tabIndex="0"
    >
      {text}
    </div>
  );
};

ButtonComponent.propTypes = {
  text: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
  onKeyPress: PropTypes.func.isRequired,
};

const ProfileContainer = () => {
  const authContext = useContext(AuthContext);
  const [navigate, setNavigate] = useState(false);

  const { logout } = authContext;

  const partnerPortalLoginObject = JSON.parse(
    localStorage.partnerPortalLoginObject,
  );
  const userName = partnerPortalLoginObject.object.username;

  const handleRedirect = () => {
    setNavigate(true);
  };

  if (navigate) {
    return <Redirect to="/faq" push />;
  }

  return (
    <React.Fragment>
      <div className={styles['layout-container']}>
        <div className={styles['background-first-layer']}>
          <div className={styles['background-second-layer']}>
            <div className={styles['layout-wrapper']}>
              <div className={styles['header-container']}>
                <p className={styles['header-first-container']}>
                  <span className={styles['partner-style']}>PARTNER </span>
                  <span className={styles['portal-style']}>PORTAL</span>
                </p>
                <p className={styles['header-second-container']}>
                  <span className={styles['partner-style']}>By </span>
                  <span className={styles['portal-style']}>HOME CREDIT</span>
                </p>
              </div>
              <div className={styles['title-container']}>
                <div>Profile</div>
              </div>
              <hr />
              <div className={styles['step-title-container']} />
              <React.Fragment>
                <div className={styles['profile-top-container']}>
                  <img src={UserIcon} alt="User Icon" />
                  <div className={styles['profile-top-text']}>
                    hi, {userName}!
                  </div>
                  <div className={styles['profile-top-circle-container']}>
                    Super Admin
                  </div>
                </div>
                <CardComponent title="Informasi Diri">
                  <CardDetailsComponent
                    heading="Nama Depan"
                    subHeading="Rich"
                  />
                  <CardDetailsComponent
                    heading="Nama Belakang"
                    subHeading="Chigga"
                  />
                  <CardDetailsComponent
                    heading="Nomor KTP"
                    subHeading="1231230101991234"
                  />
                  <CardDetailsComponent
                    heading="Employee Code"
                    subHeading="RA1231230101991234"
                  />
                </CardComponent>
                <CardComponent title="Kontak">
                  <CardDetailsComponent
                    heading="Email"
                    subHeading="rich@chigga.rap"
                    withArrow
                  />
                  <CardDetailsComponent
                    heading="Nomor Telepon"
                    subHeading="081298764567"
                  />
                </CardComponent>
                <CardComponent title="Informasi Partner">
                  <CardDetailsComponent
                    heading="Nama Mitra"
                    subHeading="88 Rising"
                  />
                  <CardDetailsComponent
                    heading="Nama Toko"
                    subHeading="Sadboi"
                  />
                  <CardDetailsComponent
                    heading="Alamat"
                    subHeading="〒106-0044東京都港区東麻布1-8-1 東麻布ISビル4F"
                  />
                </CardComponent>
                <CardComponent title="Informasi Partner">
                  <CardDetailsComponent
                    heading="Password"
                    subHeading="**********"
                    withArrow
                  />
                  <CardDetailsComponent
                    heading="Terakhir di ubah, 20 February 2019"
                    subHeading=""
                  />
                </CardComponent>
                <div
                  className={styles['button-black']}
                  onClick={handleRedirect}
                  onKeyPress={handleRedirect}
                  role="button"
                  tabIndex="0"
                >
                  FAQ
                </div>
                <ButtonComponent
                  text="Logout"
                  onClick={logout}
                  onKeyPress={logout}
                />
              </React.Fragment>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default ProfileContainer;
