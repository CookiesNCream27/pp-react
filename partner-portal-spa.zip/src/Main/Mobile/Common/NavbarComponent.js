import React, { useContext, useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './NavbarComponent.module.css';
import IconBeranda from '../../../assets/images/icon-beranda.png';
import IconKontrak from '../../../assets/images/contract.png';
import IconUserManagement from '../../../assets/images/user-management.png';
import IconPortfolio from '../../../assets/images/portfolio.png';
import IconProfil from '../../../assets/images/icon-profil.png';

import { AuthContext } from '../../AuthContext';

const MobileNavbar = () => {
  const [showMe, setShowMe] = useState('fixed');
  const [innerHeight] = useState(window.innerHeight);

  const context = useContext(AuthContext);
  const { isAuth } = context;

  useEffect(() => {
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  });

  const handleResize = () => {
    if (window.innerHeight < innerHeight) {
      return setShowMe('relative');
    }
    return setShowMe('fixed');
  };

  const ResolveNavbar = () => {
    const navbarContainer = {
      position: showMe,
      bottom: '0',
      width: '100%',
      fontFamily: 'Roboto',
      fontSize: '15px',
      textAlign: 'center',
      color: '#7b7b7b',
      display: 'flex',
      justifyContent: 'space-evenly',
      alignItems: 'center',
      alignContent: 'center',
      padding: '10px 0px 10px 0px',
      backgroundColor: '#f1f1f1',
      lineHeight: '5px',
    };
    if (isAuth) {
      return (
        <React.Fragment>
          <div style={navbarContainer}>
            <NavLink
              exact
              to="/home"
              className={styles['nav-button-container']}
              style={{ textDecoration: 'none' }}
              activeStyle={{
                fontWeight: 'bold',
                color: '#e11931',
              }}
            >
              <div className={styles['button-container']}>
                <img
                  src={IconBeranda}
                  alt="icon-beranda"
                  className={styles['icon-beranda']}
                />
                <br />
                <p>Beranda</p>
              </div>
            </NavLink>
            <NavLink
              to="/create-application"
              className={styles['nav-button-container']}
              style={{ textDecoration: 'none' }}
              activeStyle={{
                fontWeight: 'bold',
                color: '#e11931',
              }}
            >
              <div className={styles['button-container']}>
                <img
                  src={IconKontrak}
                  alt="icon-kontrak"
                  className={styles['icon-kontrak']}
                />
                <br />
                <p>Pengajuan</p>
              </div>
            </NavLink>
            <NavLink
              to="/user-management"
              className={styles['nav-button-container']}
              style={{ textDecoration: 'none' }}
              activeStyle={{
                fontWeight: 'bold',
                color: '#e11931',
              }}
            >
              <div className={styles['button-container']}>
                <img
                  src={IconUserManagement}
                  alt="icon-kontrak"
                  className={styles['icon-kontrak']}
                />
                <br />
                <p>Pengguna</p>
              </div>
            </NavLink>
            <NavLink
              to="/portfolio"
              className={styles['nav-button-container']}
              style={{ textDecoration: 'none' }}
              activeStyle={{
                fontWeight: 'bold',
                color: '#e11931',
              }}
            >
              <div className={styles['button-container']}>
                <img
                  src={IconPortfolio}
                  alt="icon-kontrak"
                  className={styles['icon-kontrak']}
                />
                <br />
                <p>Portfolio</p>
              </div>
            </NavLink>
            <NavLink
              exact
              to="/profile"
              className={styles['nav-button-container']}
              style={{ textDecoration: 'none' }}
              activeStyle={{
                fontWeight: 'bold',
                color: '#e11931',
              }}
            >
              <div className={styles['button-container']}>
                <img
                  src={IconProfil}
                  alt="icon-profil"
                  className={styles['icon-profil']}
                />
                <br />
                <p>Profil</p>
              </div>
            </NavLink>
          </div>
        </React.Fragment>
      );
    }
    return <React.Fragment />;
  };

  return <ResolveNavbar />;
};

export default MobileNavbar;
