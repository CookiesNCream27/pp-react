import React from 'react';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/styles';
import BottomNavigation from '@material-ui/core/BottomNavigation';
import BottomNavigationAction from '@material-ui/core/BottomNavigationAction';
import RestoreIcon from '@material-ui/icons/Restore';
import FavoriteIcon from '@material-ui/icons/Favorite';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import FolderIcon from '@material-ui/icons/Folder';

const theme = createMuiTheme({
  typography: {
    useNextVariants: true,
    htmlFontSize: '12px',
  },
});

const rootStyles = makeStyles({
  root: {
    position: 'fixed',
    bottom: 0,
    width: '100%',
  },
});

const childStyles = makeStyles({
  root: {
    label: {
      fontSize: '10px',
    },
  },
});

function SimpleBottomNavigation() {
  const bottomNavigationStyle = rootStyles();
  const bottomNavigationActionStyle = childStyles();
  const [value, setValue] = React.useState(0);

  return (
    <MuiThemeProvider theme={theme}>
      <BottomNavigation
        value={value}
        onChange={(event, newValue) => {
          setValue(newValue);
        }}
        showLabels
        className={bottomNavigationStyle.root}
      >
        <BottomNavigationAction
          label="Home"
          value="home"
          icon={<RestoreIcon />}
          className={bottomNavigationActionStyle.root}
        />
        <BottomNavigationAction
          label="Favorites"
          value="favorites"
          icon={<FavoriteIcon />}
        />
        <BottomNavigationAction
          label="Nearby"
          value="nearby"
          icon={<LocationOnIcon />}
        />
        <BottomNavigationAction
          label="Folder"
          value="folder"
          icon={<FolderIcon />}
        />
      </BottomNavigation>
    </MuiThemeProvider>
  );
}

export default SimpleBottomNavigation;
