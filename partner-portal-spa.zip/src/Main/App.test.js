import React from 'react';
import {
  render,
  fireEvent,
  cleanup,
  waitForElement,
} from 'react-testing-library';
import 'jest-dom/extend-expect';
import mockAxios, { loginObject } from 'axios';
import App from './App';

afterEach(cleanup);

describe('<App />', () => {
  it('renders successfully and display Login component as initial page', async () => {
    const { asFragment, getByPlaceholderText } = render(<App />);
    await waitForElement(() =>
      getByPlaceholderText('Isi Email atau Nomor Telepon'),
    );
    expect(asFragment()).toMatchSnapshot();
  });

  it('when user successfully logged-in it will redirect to Home component', async () => {
    mockAxios.post.mockImplementationOnce(() => Promise.resolve(loginObject));
    const { asFragment, getByText, getByPlaceholderText, getByTestId } = render(
      <App />,
    );
    await waitForElement(() =>
      getByPlaceholderText('Isi Email atau Nomor Telepon'),
    );
    expect(asFragment()).toMatchSnapshot();
    const usernameInput = getByPlaceholderText('Isi Email atau Nomor Telepon');
    fireEvent.change(usernameInput, { target: { value: 'alditntadmin' } });
    const passwordInput = getByPlaceholderText('Isi Kata Sandi');
    fireEvent.change(passwordInput, { target: { value: 'p@ssw0rd' } });
    const loginButton = getByTestId('submit-login');
    fireEvent.click(loginButton);
    expect(mockAxios.post).toHaveBeenCalledTimes(1);
    await waitForElement(() =>
      getByText(
        'Mohon maaf, aplikasi ini sedang dalam tahap pengembangan. Silahkan klik tautan dibawah untuk melanjutkan ke versi desktop.',
      ),
    );
    expect(asFragment()).toMatchSnapshot();
  });
});
