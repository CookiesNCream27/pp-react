import React, { Suspense } from 'react';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import blue from '@material-ui/core/colors/blue';
import { AuthProvider } from './AuthContext';
import { ApplicationProvider } from './ApplicationContext';
import appConfig from '../config/application';
import './App.css';

const theme = createMuiTheme({
  palette: {
    primary: {
      main: '#e11931',
    },
    secondary: blue,
  },
  typography: {
    useNextVariants: true,
    fontSize: 16,
    fontWeightMedium: 700,
  },
});

const DesktopRouter = React.lazy(() => import('./Desktop/DesktopRouter'));
const MobileRouter = React.lazy(() => import('./Mobile/MobileRouter'));
const LoadingContainer = () => <h1>Loading</h1>;

function detectmob(env) {
  if (env === 'development') {
    if (window.innerWidth < 481) {
      return true;
    }
    return false;
  }
  if (
    navigator.userAgent.match(/Android/i) ||
    navigator.userAgent.match(/webOS/i) ||
    navigator.userAgent.match(/iPhone/i) ||
    navigator.userAgent.match(/iPad/i) ||
    navigator.userAgent.match(/iPod/i) ||
    navigator.userAgent.match(/BlackBerry/i) ||
    navigator.userAgent.match(/Windows Phone/i)
  ) {
    return true;
  }
  return false;
}

const AppRouter = () => {
  if (detectmob(appConfig.environment)) {
    return (
      <Suspense fallback={<LoadingContainer />}>
        <MobileRouter />
      </Suspense>
    );
  }
  return (
    <Suspense fallback={<LoadingContainer />}>
      <DesktopRouter />
    </Suspense>
  );
};

const App = () => (
  <ApplicationProvider>
    <AuthProvider>
      <MuiThemeProvider theme={theme}>
        <Suspense fallback={<LoadingContainer />}>
          <AppRouter />
        </Suspense>
      </MuiThemeProvider>
    </AuthProvider>
  </ApplicationProvider>
);

export default App;
