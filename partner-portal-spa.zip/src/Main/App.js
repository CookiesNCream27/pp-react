import React, { Suspense } from 'react';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import blue from '@material-ui/core/colors/blue';
import { AuthProvider } from './AuthContext';
import appConfig from '../config/application';
import './App.css';

const theme = createMuiTheme({
  palette: {
    primary: {
      main: '#e11931',
    },
    secondary: blue,
  },
  typography: {
    useNextVariants: true,
    fontSize: 16,
    fontWeightMedium: 700,
  },
});

const DesktopRouter = React.lazy(() => import('./Desktop/DesktopRouter'));
const MobileRouter = React.lazy(() => import('./Mobile/MobileRouter'));
const LoadingContainer = () => {
  const divStyle = {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh',
  };
  return (
    <div style={divStyle}>
      <h1>Loading...</h1>
    </div>
  );
};
const LoadingContainerMobile = () => {
  document.body.style.backgroundColor = '#000000';
  const divStyle = {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh',
    backgroundColor: '#000000',
  };
  return (
    <div style={divStyle}>
      <h1>Loading...</h1>
    </div>
  );
};

const disablePinchZoomOnMobile = () => {
  document.getElementsByTagName('meta').viewport.content =
    'user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width';
};

function detectMobile(env) {
  if (env === 'development' || env === 'production') {
    if (window.innerWidth < 487) {
      return true;
    }
  } else if (
    navigator.userAgent.match(/Android/i) ||
    navigator.userAgent.match(/webOS/i) ||
    navigator.userAgent.match(/iPhone/i) ||
    navigator.userAgent.match(/iPad/i) ||
    navigator.userAgent.match(/iPod/i) ||
    navigator.userAgent.match(/BlackBerry/i) ||
    navigator.userAgent.match(/Windows Phone/i)
  ) {
    return true;
  }
  return false;
}

const AppRouter = () => {
  if (detectMobile(appConfig.environment)) {
    disablePinchZoomOnMobile();
    return (
      <Suspense fallback={<LoadingContainerMobile />}>
        <MobileRouter />
      </Suspense>
    );
  }
  return (
    <Suspense fallback={<LoadingContainer />}>
      <DesktopRouter />
    </Suspense>
  );
};

const App = () => (
  <AuthProvider>
    <MuiThemeProvider theme={theme}>
      <Suspense fallback={<LoadingContainer />}>
        <AppRouter />
      </Suspense>
    </MuiThemeProvider>
  </AuthProvider>
);

export default App;
